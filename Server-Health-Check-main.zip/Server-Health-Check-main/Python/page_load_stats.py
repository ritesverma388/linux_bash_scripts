# one and only param is path to read in uwsgi.log or access.log file (using out of box log fmt used by Alation)
# from which we can produce statistics about page load times (mean avg, 95h percentile, etc.) as CSV to stdout, e.g.
#   python3 page_load_stats.py /data/site_data/logs/uwsgi.log >pageload_summary.csv
import sys
import re
import numpy

filepath = sys.argv[1]
f = open(filepath, "r")
lines = f.readlines()
pages = {}
isUWSGI_Log = -1 != filepath.lower().find("uwsgi.log")

for l in lines:
    method = None
    uri = None
    status = None
    msecs = None

    # parse as uwsgi.log
    if isUWSGI_Log:
        # drop lines that don't look like HTTP status msgs
        if not l[0:1] == "[":
            continue

        req_pos = l.find("HTTP/1.1")
        if -1 == req_pos:
            continue

        # trim line down to just HTTP/1.1 ...
        l = l[req_pos:]

        # logs are space delimited, get the method, status by splitting
        fields = l.split(" ")
        if len(fields) < 5:
            continue
        method = fields[1]
        uri = fields[2]
        status = fields[3]
        msecs = fields[4]
        try:
            status = int(status)
            msecs = int(msecs)
        except:
            continue

    # parse as nginx access.log
    else:
        fields = l.split("\t")
        request = fields[4][1:-1]  # drop quotes
        status = fields[5].strip()
        secs = fields[9].strip()

        # subparse request since it has method, path, proto
        request_parts = request.split(" ")
        if len(request_parts) < 3:
            continue
        method = request_parts[0].strip()
        uri = request_parts[1]

        try:
            status = int(status)
            msecs = int(round(float(secs) * 1000))
        except:
            continue

    # drop qs parameters, we are interested in page level metrics
    path = uri.split("?")[0].lower()

    # remove monitors, and focus on real users
    # if path[0:9] == "/monitor/":
    #    continue

    # normalize the path by stripping out integers and guid IDs
    path = re.sub(r"\/\d+\/", "/###/", path)
    path = re.sub(r"[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}", "#GUID#", path)

    # drop the specific article name, other pages only have an ID so easier to normalize
    if path[0:13] == "/article/###/":
        path = "/article/###/##NAME##"

    # don't need exact media file names
    if path[0:18] == "/media/image_bank/":
        path = "/media/image_bank/##NAME##"

    # add the page to our dict if needed, else append to the array of page load time values
    key = f'"{status}","{method}","{path}"'
    if key not in pages:
        pages[key] = [msecs]
    else:
        pages[key].append(msecs)

# now we can compute min, max, avg, percentiles by page using the array of all collected samples
print("status,method,path,min,max,mean,median,95th_percentile,sample_size")
for k in pages.keys():
    a = numpy.array(pages[k])
    pct = numpy.percentile(a, [50, 90])
    mean = numpy.mean(a)
    min = numpy.min(a)
    max = numpy.max(a)
    ss = len(pages[k])
    print(f"{k},{min},{max},{round(mean)},{round(pct[0])},{round(pct[1])},{ss}")
