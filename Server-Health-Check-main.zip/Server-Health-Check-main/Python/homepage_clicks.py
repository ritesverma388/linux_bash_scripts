# CAUTION: due to browser caching this method may not work reliably but leaving intact as sample
# metrics table in rosemeta gets us better data, but that too has gaps.
# Ref: https://alationcorp.atlassian.net/wiki/spaces/ProServ/pages/12759924773/Auditing+with+Metrics+Metric+Table#Homepage-Clicks
# given an Alation nginx access.log file (1st and only param) output CSV with paths,clicks
# code assumes '/' (homepage) in referer is solid indicator the page load came from click on home
import sys

f = open(sys.argv[1], "r")
lines = f.readlines()
pages = {}
for l in lines:
    try:
        # logs are tab delimited, get the method, status by splitting
        fields = l.split("\t")
        request = fields[4][1:-1]  # drop quotes
        status = fields[5]
        referer = fields[7][1:-1]  # drop quotes

        # subparse request since it has method, path, proto
        uri_parts = request.split(" ")
        method = uri_parts[0]  # strip off leading quote
        path = uri_parts[1]  # strip off trailer quote

        # focus calls where homepage is the referer
        if not referer.split("/")[4] == "":
            continue  # homepage not the referer

        # only GET calls make sense pretty sure
        if not method == "GET":
            continue
        # skip some of the internal calls from homepage
        if path[0:5] in ["/api/", "/ajax", "/stat", "/metr", "/vers"]:
            continue

        # populate the dict
        if path not in pages:
            pages[path] = 1
        else:
            pages[path] += 1

    except:
        continue
print("path,clicks")
for k in pages:
    print(f"{k},{pages[k]}")
