# GENERATE PYC FOR THIS FILE IN ALATION SHELL WITH CORRECT TARGET PYTHON RUNTIME
# THIS SOURCE PY IS EXCLUDED FROM THE OUTPUT PACKAGE
import bootstrap_rosemeta  # This will load the Django Framework
import alation_util.pgsql_util as pgsql_util
import alation_conf
from alation_conf import conf
import sys
import subprocess


def psql_getaav2():
    psqlcmd = f'PGPASSWORD=\'{conf.get_decrypted("alation_analytics-v2.pgsql.password")}\' psql \'postgresql://{conf["alation_analytics-v2.pgsql.config.host"]}:{conf["alation_analytics-v2.pgsql.config.port"]}'
    psqlcmd = f'{psqlcmd}/{conf["alation_analytics-v2.pgsql.config.dbname"]}'
    psqlcmd = f'{psqlcmd}?user={conf["alation_analytics-v2.pgsql.user"]}\''
    return psqlcmd


psql = psql_getaav2() if sys.argv[1] == "aav2" else pgsql_util.get_psql(sys.argv[1])
cmdline = f"{psql} -a -f {sys.argv[2]} -o {sys.argv[3]}"
subprocess.run(cmdline, shell=True)
