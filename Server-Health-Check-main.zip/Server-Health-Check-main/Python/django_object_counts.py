import bootstrap_rosemeta
from rosemeta.models.models_data import Attribute, DataSource, Schema, Table
from filesystems.models import File
from bi_metadata.models.bi_objects import BIReport, BIReportColumn
from rosemeta.models.models_text import Article
from django_celery_beat.models import PeriodicTask
from domains.models import Domain
from glossary.models.models_glossary import Glossary
from glossary.models.models_term import Term
from policy.models.models import BusinessPolicy, Policy, PolicyGroup
from workflows.models.workflow import Workflow
from rosemeta.models.models_task import ScheduledQueryRun
from api_resource.models import APIResource

otypes = [
    "Article",
    "PeriodicTask",
    "Domain",
    "Glossary",
    "BusinessPolicy",
    "Policy",
    "PolicyGroup",
    "Workflow",
    "ScheduledQueryRun",
    "APIResource",
    "Attribute",
    "Table",
    "Schema",
    "DataSource",
    "BIReport",
    "BIReportColumn",
    "File",
]

print("\n**raw counts**\n")
for o in otypes:
    obj = eval(o)
    print(f"{o} count = {obj.objects.count()}")


print("\n**computed counts**\n")
# compute APIResources that acually have input schemas
APIwSchema = APIResource.objects.count() - len(
    APIResource.objects.filter(input_schema=None)
)
print(f"APIResource with input_schema count = {APIwSchema}")
