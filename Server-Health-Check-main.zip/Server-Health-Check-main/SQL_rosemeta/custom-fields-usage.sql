    SELECT rc.id AS "Custom Field Id",
        rc.ts_created AS "Custom Field Created At",
        rc.ts_updated AS "Custom Field Updated At",
        rc.name_singular AS "Custom Field Name (Singular)",
        rc.name_plural AS "Custom Field Name (Plural)",
        rc.tooltip_text AS "Custom Field Tooltip Text",
        rc.backref_name AS "Custom Field Backref Name",
        rc.backref_tooltip_text AS "Custom Field Backref Tooltip Text",
        count(rcv.id) AS "Used Custom Field Values"
    FROM public.rosemeta_customfield rc
    LEFT JOIN public.rosemeta_customfieldvalue rcv ON (rc.id = rcv.field_id)
    GROUP BY rc.id,
            rc.ts_created,
            rc.ts_updated,
            rc.name_singular,
            rc.name_plural,
            rc.tooltip_text,
            rc.backref_name,
            rc.backref_tooltip_text