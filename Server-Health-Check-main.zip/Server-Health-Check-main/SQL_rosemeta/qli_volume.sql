SELECT date_trunc('day', ts_finished) as job_day, external_service_aid as ds_id, sum(substring(state_message, '\s(\d+)\snew events ingested')::int) as msgcount
FROM public.jobs_job
WHERE job_type=1 
AND status<>2
AND state_message like 'Query Ingestion Succeeded%'
AND extract(day FROM now() - ts_finished) < 30
GROUP BY job_day, ds_id
ORDER by msgcount DESC