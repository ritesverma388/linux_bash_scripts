select d.id as ds_id, d.title, j.*
from public.rosemeta_datasource d
join public.rosemeta_jdbcdriver j
on d.jdbc_driver_id = j.id and d.dbtype='customdb' and d.deleted = False