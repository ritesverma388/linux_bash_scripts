SELECT rq.id AS "Query Id",
       rq.ts_created AS "Query Created At",
       rq.ts_updated AS "Query Updated At",
       rq.title AS "Query Title",
       rq.description AS "Query Description",
       rq.published AS "Query Is Published?",
       rq.autosave_content AS "Query Autosave SQL",
       rq.published_content AS "Query Published SQL",
       rq.execution_tally AS "Query Compose Executions",
       rq.author_id AS "Query Author Id",
       rq.ds_id AS "Query Data Source Id",
       rq.schema_id AS "Query Schema Id"
FROM public.rosemeta_query rq
WHERE rq.deleted IS FALSE