SELECT count(1) as tpm, date_trunc('minute', ts_created) as timeslice, q.username, r.name as refresh_token_name, q.method, q.path
FROM
(SELECT m.ts_created,
          u.username,
          name,
          properties,
          (properties::JSON->>'method')::text AS METHOD,
          (properties::JSON->>'URL')::text AS PATH,
          (properties::JSON->>'api_access_token_id')::int AS TOKEN
   FROM public.metrics_metric m
   JOIN public.auth_user u ON u.id = m.user_id
   AND m.properties ~ 'api_access_token_id' 
   AND extract(DAY
               FROM now() - m.ts_created) < 30) q
LEFT JOIN public.api_authentication_apiaccesstoken t on q.token=t.id
LEFT JOIN public.api_authentication_refreshtoken r on r.id=t.refresh_token_id 
GROUP BY q.username, r.name, timeslice, method, path
ORDER BY tpm desc