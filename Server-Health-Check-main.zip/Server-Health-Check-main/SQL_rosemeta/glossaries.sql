SELECT rc.id AS "Glossary Id",
       lmg."text" AS "Glossary Name",
       rc.ts_created AS "Glossary Created At",
       rc.ts_updated AS "Glossary Updated At"
FROM public.rosemeta_customglossary rc
LEFT JOIN public.logical_metadata_genericfieldvalue lmg ON (rc.id::text = regexp_replace(lmg.oid::text, '^[0\-]+', ''))
WHERE rc.deleted IS FALSE
  AND lmg.field_id = 3
  AND lmg.otype = 5