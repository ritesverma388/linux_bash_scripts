SELECT rd.id AS "Data Source Id",
       rd.ts_created AS "Data Source Created At",
       rd.ts_updated AS "Data Source Updated At",
       rd.last_query_import AS "Data Source Last QLI",
       rd.title AS "Data Source Title",
       rd.description AS "Data Source Description",
       rd.dbtype AS "Database Type",
       rd.dbname AS "Database Name",
       rd.uri AS "Database Connection String",
       CASE
           WHEN rd.disable_auto_extraction IS FALSE THEN rd.cron_extraction
           ELSE NULL
       END AS "Data Source MDE Schedule",
       CASE
           WHEN rd.disable_auto_profiling IS FALSE THEN rd.cron_profiling
           ELSE NULL
       END AS "Data Source Data Sampling Schedule",
       CASE
           WHEN rd.disable_auto_query_import IS FALSE THEN rd.cron_query_import
           ELSE NULL
       END AS "Data Source QLI Schedule",
       rd.creator_id AS "Data Source Creator Id"
FROM public.rosemeta_datasource rd
WHERE rd.deleted IS FALSE