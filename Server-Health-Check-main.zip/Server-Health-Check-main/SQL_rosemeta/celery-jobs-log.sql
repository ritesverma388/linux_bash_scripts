SELECT cjmc.id AS "Job Id",
       cjmc.task_id AS "Task Uuid",
       cjmc.task_name AS "Task Name",
       cjmc.queue AS "Job Queue",
       cjmc.ts_sent_to_broker AS "Job Sent to Queue",
       cjmc.ts_prerun AS "Job Start Time",
       cjmc.ts_postrun AS "Job Finish Time",
       cjmc.status AS "Job Status Code"
FROM public.celery_job_monitor_celeryjoblog cjmc
WHERE cjmc.ts_sent_to_broker > (CURRENT_DATE - interval '90' DAY)
ORDER BY cjmc.ts_sent_to_broker,
         cjmc.id