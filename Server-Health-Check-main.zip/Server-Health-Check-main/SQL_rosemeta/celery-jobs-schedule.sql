SELECT s.minute,
          s.hour,
          s.day_of_week,
          s.day_of_month,
          s.month_of_year,
          s.timezone,
          t.task,
          t.last_run_at
   FROM public.django_celery_beat_crontabschedule s
   FULL JOIN public.django_celery_beat_periodictask t ON s.id = t.crontab_id
   AND enabled=TRUE
ORDER by hour asc, minute asc