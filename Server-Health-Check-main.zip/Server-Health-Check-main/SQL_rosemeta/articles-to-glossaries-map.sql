SELECT rag.id AS "Map Id",
       rag.article_id AS "Article Id",
       rag.customglossary_id AS "Glossary Id"
FROM public.rosemeta_article_glossaries rag