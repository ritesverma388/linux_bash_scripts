SELECT rs.id AS "Schema Id",
       rs.ts_created AS "Schema Created At",
       rs.ts_updated AS "Schema Updated At",
       rs.title AS "Schema Title",
       rs.description AS "Schema Description",
       rs."name" AS "Schema Name",
       rs.original_name AS "Schema Original Name",
       rs.owner_id AS "Schema Owner Id",
       rs.ds_id AS "Schema Data Source Id",
       rs.num_tables AS "Number of Tables in Schema"
FROM public.rosemeta_schema rs
WHERE rs.deleted IS FALSE