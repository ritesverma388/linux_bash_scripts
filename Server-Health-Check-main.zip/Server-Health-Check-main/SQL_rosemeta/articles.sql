SELECT ra.id AS "Article Id",
       ra.ts_created AS "Article Created At",
       ra.ts_updated AS "Article Updated At",
       ra.title AS "Article Title",
       ra.description AS "Article Description",
       rp.author_id AS "Article Author",
       rp.last_edited_by_id AS "Article Last Edited By"
FROM public.rosemeta_article ra
LEFT JOIN public.rosemeta_post rp ON (ra.post_id = rp.id)
WHERE ra.deleted IS FALSE