SELECT aug.id AS "Map Id",
       aug.user_id AS "User Id",
       aug.group_id AS "Group Id",
       ag."name" AS "Group Name"
FROM public.auth_user_groups aug
LEFT JOIN public.auth_group ag ON (aug.group_id = ag.id)