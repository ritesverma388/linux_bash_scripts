SELECT au.id AS "User Id",
       au.last_login AS "User Last Login At",
       au.date_joined AS "User Joined At",
       au.username AS "Username",
       ru.display_name AS "User Display Name",
       au.first_name AS "User First Name",
       au.last_name AS "User Last Name",
       sha256(au.email::bytea) AS "User Email SHA256 Hashed",
       ru.is_admin AS "User is Admin?",
       au.is_superuser AS "User Is Superuser?",
       au.is_staff AS "User is Staff?",
       au.is_active AS "User is Active?"
FROM public.auth_user au
LEFT JOIN public.rosemeta_userprofile ru ON (au.id = ru.user_id)