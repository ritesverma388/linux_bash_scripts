SELECT dd.id AS "Domain Id",
       dd.created_at AS "Domain Created At",
       dd.updated_at AS "Domain Updated At",
       lmg."text" AS "Domain Name",
       dd.parent_id AS "Domain Parent Id",
       dd.creator_id AS "Domain Creator Id"
FROM public.domains_domain dd
LEFT JOIN public.logical_metadata_genericfieldvalue lmg ON (dd.id::text = regexp_replace(lmg.oid::text, '^[0\-]+', ''))
WHERE dd.deleted_at IS NULL
  AND lmg.field_id = 3
  AND lmg.otype = 89