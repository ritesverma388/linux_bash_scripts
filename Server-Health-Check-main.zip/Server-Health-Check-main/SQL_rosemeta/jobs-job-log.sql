SELECT id AS "Job Id",
       CASE
           WHEN job_type = 0 THEN 'METADATA_SYNCING'
           WHEN job_type = 1 THEN 'QUERY_LOG_INGESTION'
           WHEN job_type = 2 THEN 'PROFILING'
           WHEN job_type = 3 THEN 'BACKUP'
           WHEN job_type = 4 THEN 'FILE_SYSTEM_SYNCING'
           WHEN job_type = 5 THEN 'BI_METADATA_SYNCING'
           WHEN job_type = 6 THEN 'CATALOG_METADATA_SYNCING'
           WHEN job_type = 7 THEN 'CATALOG_SET_MASTER_SYNCING'
           WHEN job_type = 8 THEN 'ALATION_ANALYTICS_ETL_SYNCING'
           WHEN job_type = 9 THEN 'LEXICON_COMPUTING'
           WHEN job_type = 10 THEN 'CURATION_PROGRESS_INGESTION'
           WHEN job_type = 11 THEN 'API_LINEAGE_UPLOAD'
           WHEN job_type = 12 THEN 'API_LINEAGE_DELETE'
           WHEN job_type = 13 THEN 'BI_METADATA_SYNCING_FOLDER'
           WHEN job_type = 14 THEN 'NOSQL_METADATA_SYNCING'
           WHEN job_type = 15 THEN 'BULK_ROSEMETA_DELETE'
           WHEN job_type = 16 THEN 'USER_DOWNLOAD'
           WHEN job_type = 17 THEN 'AUTO_LINEAGE_UPDATE'
           WHEN job_type = 18 THEN 'BI_V2_API_SYNCING'
           WHEN job_type = 19 THEN 'AVRO_METADATA_SYNCING'
           WHEN job_type = 20 THEN 'DATA_RE_KEY'
           WHEN job_type = 21 THEN 'API_DATAFLOW_UPLOAD'
           WHEN job_type = 22 THEN 'API_DATAFLOW_DELETE'
           ELSE NULL
       END AS "Job Name",
       external_service_aid AS "Alation Object Id",
              CASE
           WHEN external_service_otype = 7 THEN 'DATA'
           ELSE 'OTHER/UNKNOWN'
       END AS otype,
       ts_started AS "Job Start Time",
       ts_updated AS "Job Update Time",
       ts_updated AS "Job Finish Time",
       status AS "Job Status Code"
FROM public.jobs_job
WHERE ts_started > (CURRENT_DATE - interval '90' DAY)
ORDER BY ts_started,
         id