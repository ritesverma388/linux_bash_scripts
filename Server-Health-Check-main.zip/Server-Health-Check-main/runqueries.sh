tmpsqlfile="tmp_healthcheck.sql"
for file in $sqlpath ;
do
    sqlfile=$(basename $file)
    echo "    - Starting on $sqlfile" | tee -a $LOGFILE;
    echo "COPY(" >$jailhome/$relativeoneoffdir/$tmpsqlfile
    cat $file >>$jailhome/$relativeoneoffdir/$tmpsqlfile
    echo ") TO STDOUT WITH CSV HEADER" >>$jailhome/$relativeoneoffdir/$tmpsqlfile
    chown alation:alation $jailhome/$relativeoneoffdir/$tmpsqlfile
    query_start=`date +%s`
    chroot $jailhome /bin/su - alation -c "cd /$relativeoneoffdir && python3 $psqlscript $sqldb $tmpsqlfile /$relativeoutputdir/$sqlfile"
    query_end=`date +%s`
    query_rows=$(wc -l < $jailhome/$relativeoutputdir/$sqlfile | xargs)
    mv "$jailhome/$relativeoutputdir/$sqlfile" "$results_dir_name/$sqldb/${sqlfile%.sql}.csv"
    rm $jailhome/$relativeoneoffdir/$tmpsqlfile
    echo "    - Query Runtime: $((query_end-query_start)) seconds. Rows Returned: $query_rows" | tee -a $LOGFILE;
done