### Requirements:
1) Root access to Alation server
2) Ideally, Alation Analytics V2 is up and running. Does NOT need to be on same server

### Instructions:

1) Log into Alation server, but NOT in the Alation shell
2) `sudo cd /tmp` or any appropriate 'temp' directory that is not mounted with noexec
3) Copy server-health-check.tar.gz into that directory
4) Extract the files, e.g. `sudo tar -xvf server-health-check.tar.gz`
5) `sudo cd Server-Health-Check` to hop into the extracted directory
6) Change permissions to allow execution of the scripts (`sudo chmod +x *.sh`)
7) If not using Alation 2023.3.1 or higher, copy exec_psql_v1.pyc over exec_psql.pyc in Python folder
8) Execute the script: `sudo ./environment_scan.sh` or failing that try `sudo sh ./environment_scan.sh`
9) The script should complete in a few minutes, possibly longer
10) The output folder will be named `alation_environment_scan_<date_time>` and compressed to tar.gz
11) Send the compresed results file back to Alation Point of contact.

### Directory Output Structure:

* **alation_environment_scan_<date_time>**/
  * **alation/**
      * alation_conf.txt - *Alation Server Configurations*
      * alation-backup-filesizes.txt - *Alation Backup Directory Sizes*
      * alation-postgres-filesizes.txt - *Alation Postgres Directory Sizes*
      * alation-status.txt - *Alation Server and Processes Status*
      * django_object_counts.txt - *Django python code returning counts of various objects*
      * es-cluster-health.txt - *Elasticsearch Cluster Health*
      * ec-count.txt - *Elasticsearch Documents and Shards Count*
      * es-index-health.txt - *Elasticsearch Index Health*
      * es-shard-health.txt - *Elasticsearch Shard Health*
      * ls-rosemeta-one-off-scripts.txt - *Rosemeta One-Off Django Python Scripts*
      * ls-custom-drivers.txt - *Driver files found in /data1/site_data/custom_drivers*
      * opt-alation.txt - *Alation Chroot Information*
      * page_load_stats.csv - *stats from uwsgi logs*

  * **alation_environment_scan_<date_time>.tar.gz** - *File to be shared with Alation Point of Contact*
  * **environment/**
      * cpu.txt - *Backend Server CPU Cores and Specs: `lscpu` output*
      * disks.txt - *Backend Server Disks/Volume & Mount Details: `lsblk` output*
      * file-systems.txt - *Backend Server File System Details: `df -h` output*
      * memory.txt - *Backend Server Memory (RAM) Details: `free -g` output*
      * mounts.txt - *Backend Server Mount Information: Copy of `/etc/fstab` file*
      * os-release.txt - *Backend Server Operating System Information: Copy of `/etc/os-release` file*
      * process-snapshot.txt - *Backend Server Running Processes: `ps -ef` output*
      * sar_cpu.txt - *Longer term cpu from sar, if avail: `sar -u` output*
      * sar_memory.txt - *Longer term memory from sar, if avail: `sar -r` output*
      * sar_paging.txt - *Longer term paging stats from sar, if avail: `sar -B` output*
      * sar_io.txt - *Longer term IO stats, if avail: `sar -b` output*
  
  * **logs/**
    * environment_scan_<date_time>.log - *Copy of environment_scan.sh Log*
  
  * **rosemeta/**
    * csv results from each sql query found in /SQL_rosemeta, plus SQL_common

  * **lineage/**
    * csv results from each sql query found in /SQL_lineage, plus SQL_common

  * **aav2/**
    * csv results from each sql query found in /SQL_aav2, plus SQL_common