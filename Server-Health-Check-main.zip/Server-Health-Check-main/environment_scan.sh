#!/bin/bash

# Get Startime of Script
CURRENTDATE=`date +"%Y-%m-%d_%H-%M-%S"`

# Create Directory Structure for Script Output
hc_homedir=$(pwd)
results_dir_name=$hc_homedir/alation_environment_scan_$CURRENTDATE
mkdir $results_dir_name
for results_subdir in "environment" "alation" "rosemeta" "aav2" "lineage" "logs"
do
    mkdir $results_dir_name/$results_subdir
done

# Jail home
jailhome=/opt/alation/alation

# Create Log File
LOGFILE=$results_dir_name/logs/environment_scan_$CURRENTDATE.log

echo "" | tee -a $LOGFILE
echo "#################################" | tee -a $LOGFILE
echo "#                               #" | tee -a $LOGFILE
echo "#  ALATION SERVER HEALTH CHECK  #" | tee -a $LOGFILE
echo "#                               #" | tee -a $LOGFILE
echo "#################################" | tee -a $LOGFILE
echo "" | tee -a $LOGFILE
echo "    Date: $CURRENTDATE" | tee -a $LOGFILE
echo "" | tee -a $LOGFILE
echo "By: Alation Professional Services" | tee -a $LOGFILE
echo "" | tee -a $LOGFILE
echo "#################################" | tee -a $LOGFILE

# Gather Server and Application Stats
echo "" | tee -a $LOGFILE
echo "[SERVER & APPLICATION STATS]" | tee -a $LOGFILE

echo "Gathering OS Release Information" | tee -a $LOGFILE
cat /etc/os-release &> $results_dir_name/environment/os-release.txt

echo "Gathering CPU Core Count" | tee -a $LOGFILE
lscpu &> $results_dir_name/environment/cpu.txt

echo "Gathering Memory (RAM) Details" | tee -a $LOGFILE
free -g &> $results_dir_name/environment/memory.txt

echo "Gathering Disks/Volume Details"| tee -a $LOGFILE
lsblk &> $results_dir_name/environment/disks.txt

echo "Gathering Mount Details" | tee -a $LOGFILE
cat /etc/fstab &> $results_dir_name/environment/mounts.txt

echo "Gather File System Size" | tee -a $LOGFILE
df -h &> $results_dir_name/environment/file-systems.txt

echo "Gather List of Running Processes" | tee -a $LOGFILE
ps -ef &> $results_dir_name/environment/process-snapshot.txt

echo "Get history of CPU since midnight" | tee -a $LOGFILE
sar -u &> $results_dir_name/environment/sar_cpu.txt

echo "Get history of Memory since midnight" | tee -a $LOGFILE
sar -r &> $results_dir_name/environment/sar_memory.txt

echo "Get history of Paging since midnight" | tee -a $LOGFILE
sar -B &> $results_dir_name/environment/sar_paging.txt

echo "Get history of IO since midnight" | tee -a $LOGFILE
sar -b &> $results_dir_name/environment/sar_io.txt

# echo "Gathering Docker Container Health" | tee -a $LOGFILE
docker ps &> $results_dir_name/environment/docker-containers.txt

echo "Gathering Directory Structure for /opt/alation" | tee -a $LOGFILE
ls -ltr /opt/alation &> $results_dir_name/alation/opt-alation.txt

echo "Checking Alation Application Status" | tee -a $LOGFILE
/etc/init.d/alation status &> $results_dir_name/alation/alation-status.txt

echo "Gathering Alation Application Configurations" | tee -a $LOGFILE
chroot $jailhome /bin/su - alationadmin -c "alation_conf" &> $results_dir_name/alation/alation_conf.txt

chroot $jailhome /bin/su - alation -c "alation_ypireti list" &> $results_dir_name/alation/alation-ypireti-list.txt

echo "Gathering List of Django One Off Scripts" | tee -a $LOGFILE
chroot $jailhome /bin/su - alation -c "ls -ltra /opt/alation/django/rosemeta/one_off_scripts" &> $results_dir_name/alation/ls-rosemeta-one-off-scripts.txt

echo "Gathering List of Custom Driver Files" | tee -a $LOGFILE
chroot $jailhome /bin/su - alation -c "ls -ltra /data1/site_data/custom_drivers" &> $results_dir_name/alation/ls-custom-drivers.txt

echo "Gathering Size of Postgres Database Directories and Files" | tee -a $LOGFILE
chroot $jailhome /bin/su - root -c "du -h /data1/pgsql -d 3" &> $results_dir_name/alation/alation-postgres-filesizes.txt

echo "Gathering Size of Backup Directories and Files" | tee -a $LOGFILE
chroot $jailhome /bin/su - root -c "du -h /data2/backup -d 3" &> $results_dir_name/alation/alation-backup-filesizes.txt

echo "Gathering Elastic Analysis" | tee -a $LOGFILE 
chroot $jailhome /bin/su - alation -c "python /opt/alation/django/rosemeta/one_off_scripts/search_status_analysis.pyc"  &> $results_dir_name/alation/es-analysis.txt

echo "Gathering Count of Elastic Search Documents and Shards" | tee -a $LOGFILE 
chroot $jailhome /bin/su - alationadmin -c "curl http://0.0.0.0:9200/live,live_large/_count" &> $results_dir_name/alation/es-count.txt

echo "Checking Elastic Search Cluster Health" | tee -a $LOGFILE
chroot $jailhome /bin/su - alationadmin -c "curl -XGET http://0.0.0.0:9200/_cluster/health?pretty" &> $results_dir_name/alation/es-cluster-health.txt

echo "Checking Elastic Search Index Health" | tee -a $LOGFILE
chroot $jailhome /bin/su - alationadmin -c "curl -XGET http://0.0.0.0:9200/_cluster/health?level=indices\&pretty" &> $results_dir_name/alation/es-index-health.txt

echo "Checking Elastic Search Shard Health" | tee -a $LOGFILE
chroot $jailhome /bin/su - alationadmin -c "curl -XGET http://0.0.0.0:9200/_cluster/health?level=shards\&pretty" &> $results_dir_name/alation/es-shard-health.txt

# Aggregate page load stats
relativelogdir=data1/site_data/logs
pyscriptprefix=page_load_stats
cp $hc_homedir/Python/$pyscriptprefix.py $jailhome/$relativelogdir
chown alation:alation $jailhome/$relativelogdir/$pyscriptprefix.py
chmod +rwx $jailhome/$relativelogdir/$pyscriptprefix.py
chroot $jailhome /bin/su - alation -c "python /$relativelogdir/$pyscriptprefix.py /$relativelogdir/uwsgi.log"  &> $results_dir_name/alation/$pyscriptprefix.csv

# Prep for running Postgres Queries vs. Rosemeta, Lineage, AAv2
chmod +rx $hc_homedir/runqueries.sh
relativeoneoffdir=opt/alation/django/rosemeta/one_off_scripts
relativeoutputdir=$relativeoneoffdir/tmp_healthcheck_output
mkdir $jailhome/$relativeoutputdir
psqlscript=exec_psql.pyc
cp $hc_homedir/Python/$psqlscript $jailhome/$relativeoneoffdir
chown alation:alation $jailhome/$relativeoneoffdir/$psqlscript
chmod +rwx $jailhome/$relativeoneoffdir/$psqlscript
chown alation:alation $jailhome/$relativeoutputdir

# Run comnmon queries vs. all DBs
echo "[COMMON SQL QUERIES]" | tee -a $LOGFILE
sqlpath=$hc_homedir/SQL_common/*.sql
for sqldb in "rosemeta" "lineage" "aav2"
do
    source $hc_homedir/runqueries.sh
done

# Run Rosemeta queries
echo "" | tee -a $LOGFILE
echo "[ROSEMETA SQL QUERIES]" | tee -a $LOGFILE
sqlpath=$hc_homedir/SQL_rosemeta/*.sql
sqldb="rosemeta"
source $hc_homedir/runqueries.sh

# Run Lineage queries
echo "" | tee -a $LOGFILE
echo "[LINEAGE SQL QUERIES]" | tee -a $LOGFILE
sqlpath=$hc_homedir/SQL_lineage/*.sql
sqldb="lineage"
source $hc_homedir/runqueries.sh

# Run AAv2 queries
echo "" | tee -a $LOGFILE
echo "[AAV2 SQL QUERIES]" | tee -a $LOGFILE
sqlpath="$hc_homedir/SQL_aav2/*.sql"
sqldb="aav2"
source $hc_homedir/runqueries.sh

# Run Django Based Object Counts
echo "Running Django Script to Count Objects" | tee -a $LOGFILE
django_count_script=django_object_counts.py
cp $hc_homedir/Python/$django_count_script $jailhome/$relativeoneoffdir
chown alation:alation $jailhome/$relativeoneoffdir/$django_count_script
chroot $jailhome /bin/su - alation -c "cd /$relativeoneoffdir && python3 $django_count_script"  &> $results_dir_name/alation/django_object_counts.txt

# Cleanup
rm $jailhome/$relativeoneoffdir/$psqlscript
rm $jailhome/$relativelogdir/$pyscriptprefix.*
rm $jailhome/$relativelogdir/$django_count_script
rmdir $jailhome/$relativeoutputdir

# Package Output
echo "" | tee -a $LOGFILE
echo "[PACKAGE OUTPUT]" | tee -a $LOGFILE
echo "Creating TAR of Script Outputs" | tee -a $LOGFILE
tar -cvzf alation_environment_scan_$CURRENTDATE.tar.gz -C $results_dir_name $results_dir_name/ >/dev/null 2>&1
echo "TAR File can be found at: $hc_homedir/alation_environment_scan_$CURRENTDATE.tar.gz" | tee -a $LOGFILE

echo "" | tee -a $LOGFILE
echo "Done!" | tee -a $LOGFILE
echo "" | tee -a $LOGFILE