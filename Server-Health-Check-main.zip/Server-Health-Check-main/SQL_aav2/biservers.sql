SELECT *
FROM public.bi_server