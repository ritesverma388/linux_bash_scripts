--Alation Analytics V2 Query
SELECT pv.ts_created AS "Timestamp",
       pv.user_id AS "User Id",
       pv.object_id AS "Alation Object Id",
       pv.object_type AS "Alation Object Type"
FROM public.visits pv
WHERE pv.ts_created > (CURRENT_DATE - interval '30' DAY)