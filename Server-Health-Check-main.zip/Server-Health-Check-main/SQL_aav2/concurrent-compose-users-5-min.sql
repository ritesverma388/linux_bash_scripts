--Alation Analytics V2 Query
SELECT date_trunc('hour', qr.executed_at) + (((date_part('minute', qr.executed_at)::integer / 5::integer) * 5::integer) || 'minutes')::interval AS "Timestamp",
       count(DISTINCT qr.user_id) AS "Concurrent Users",
       count(qr.id) AS "Total Queries Executed"
FROM public.execution_event qr
WHERE qr.executed_at > (CURRENT_DATE - interval '90' DAY)
GROUP BY "Timestamp"