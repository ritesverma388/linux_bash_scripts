SELECT *
FROM public.filesystems