SELECT *
FROM public.rdbms_datasources