--Alation Analytics V2 Query
SELECT date_trunc('hour', pv.ts_created) + (((date_part('minute', pv.ts_created)::integer / 5::integer) * 5::integer) || 'minutes')::interval AS "Timestamp",
       count(DISTINCT pv.user_id) AS "Concurrent Users",
       count(pv.*) AS "Total Page Visits"
FROM public.visits pv
WHERE pv.ts_created > (CURRENT_DATE - interval '90' DAY)
GROUP BY "Timestamp"