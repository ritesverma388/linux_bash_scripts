--Alation Analytics V2 Query
SELECT date_trunc('month', pv.ts_created)::date AS "Timestamp",
       count(DISTINCT pv.user_id) AS "Concurrent Users",
       count(pv.*) AS "Total Page Visits"
FROM public.visits pv
WHERE pv.ts_created > (CURRENT_DATE - interval '12' MONTH)
GROUP BY "Timestamp"