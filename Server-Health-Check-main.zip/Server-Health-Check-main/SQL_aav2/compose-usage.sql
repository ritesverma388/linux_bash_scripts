--Alation Analytics V2 Query
SELECT qr.executed_at AS "Timestamp",
       qr.user_id AS "User Id",
       qr.db_account AS "Database Account",
       qr.ds_id AS "Data Source Id",
       qr.query_id AS "Query Id",
       qr.canceled AS "Query Cancelled?",
       qr.finished AS "Query Finished?",
       qr.seconds_taken AS "Query Execution Time",
       qr.execution_error AS "Query Error",
       qr.result_row_count AS "Result Rown Count",
       qr.result_byte_count AS "Result Byte Count",
       qr.result_expired AS "Result Expired?",
       qr.result_ts_expiration AS "Result Expiration Timestamp"
FROM public.execution_event qr
WHERE qr.executed_at > (CURRENT_DATE - interval '30' DAY)