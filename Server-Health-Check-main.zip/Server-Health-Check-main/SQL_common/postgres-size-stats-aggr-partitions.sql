SELECT tbl_name AS "Normalized Table Name",
       pg_size_pretty(size) AS "Total Table Size",
       round(size/all_tables_size*100, 2) AS "As Percent of Total",
       pg_size_pretty(all_tables_size) AS "Size of All Tables Combined"
FROM
  (SELECT *,
          sum(size) OVER () AS all_tables_size
   FROM
     (SELECT tbl_name,
             sum(size) AS size
      FROM
        (SELECT regexp_replace(tbl_name, '_[[:digit:]]+', '_nnn', 'g') AS tbl_name,
                pg_total_relation_size(tbl_name) AS size
         FROM
           (SELECT ('"' || table_schema || '"."' || TABLE_NAME || '"') AS tbl_name
            FROM information_schema.tables) AS all_tables) AS all_tables_sizes
      GROUP BY tbl_name
      ORDER BY size DESC) AS order_by_size) AS with_total