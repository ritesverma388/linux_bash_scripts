SELECT TABLE_NAME AS "Qualified Table Name",
                     pg_size_pretty(pg_table_size(TABLE_NAME)) AS "Table Size",
                     pg_size_pretty(pg_indexes_size(TABLE_NAME)) AS "Indexes Size",
                     pg_size_pretty(pg_total_relation_size(TABLE_NAME)) AS "Total Retention Size"
FROM
  (SELECT ('"' || table_schema || '"."' || TABLE_NAME || '"') AS TABLE_NAME
   FROM information_schema.tables) AS all_tables
ORDER BY pg_total_relation_size(TABLE_NAME) DESC