cd ../
tar --exclude '.git' --exclude '.gitignore' --exclude 'tarme.sh' --exclude 'exec_psql.py' -czvf server-health-check.tar.gz ./Server-Health-Check