SELECT
  source_otype
  , target_otype
  , COUNT(*) AS cnt
FROM edge
GROUP by source_otype, target_otype
ORDER by cnt desc