## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | ~> 0.13.6 |
| <a name="requirement_datadog"></a> [datadog](#requirement\_datadog) | ~> 3.7.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_datadog"></a> [datadog](#provider\_datadog) | ~> 3.7.0 |
| <a name="provider_template"></a> [template](#provider\_template) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_filter-tags"></a> [filter-tags](#module\_filter-tags) | ../../../common/filter-tags |  |

## Resources

| Name | Type |
|------|------|
| [datadog_dashboard_json.dashboard_apigateway](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/dashboard_json) | resource |
| [datadog_monitor.apigateway_4xxerror](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.apigateway_5xxerror](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.apigateway_count](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.apigateway_latency](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [template_file.apigateway_dashboard](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |
| [template_file.apigateway_widgets](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_apigateway_4xxerror_aggregator"></a> [apigateway\_4xxerror\_aggregator](#input\_apigateway\_4xxerror\_aggregator) | Monitor aggregator for APIGateway 4xxerror [available values: min, max or avg] | `string` | `"sum"` | no |
| <a name="input_apigateway_4xxerror_enabled"></a> [apigateway\_4xxerror\_enabled](#input\_apigateway\_4xxerror\_enabled) | Flag to enable APIGateway 4xxerror monitor | `string` | `"true"` | no |
| <a name="input_apigateway_4xxerror_extra_tags"></a> [apigateway\_4xxerror\_extra\_tags](#input\_apigateway\_4xxerror\_extra\_tags) | Extra tags for APIGateway 4xxerror monitor | `list(string)` | `[]` | no |
| <a name="input_apigateway_4xxerror_message"></a> [apigateway\_4xxerror\_message](#input\_apigateway\_4xxerror\_message) | Custom message for APIGateway 4xxerror | `string` | `""` | no |
| <a name="input_apigateway_4xxerror_no_data_timeframe"></a> [apigateway\_4xxerror\_no\_data\_timeframe](#input\_apigateway\_4xxerror\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_apigateway_4xxerror_notify_no_data"></a> [apigateway\_4xxerror\_notify\_no\_data](#input\_apigateway\_4xxerror\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_apigateway_4xxerror_threshold_critical"></a> [apigateway\_4xxerror\_threshold\_critical](#input\_apigateway\_4xxerror\_threshold\_critical) | APIGateway 4xxerror critical threshold | `number` | `80` | no |
| <a name="input_apigateway_4xxerror_threshold_warning"></a> [apigateway\_4xxerror\_threshold\_warning](#input\_apigateway\_4xxerror\_threshold\_warning) | APIGateway 4xxerror warning threshold | `number` | `60` | no |
| <a name="input_apigateway_4xxerror_timeframe"></a> [apigateway\_4xxerror\_timeframe](#input\_apigateway\_4xxerror\_timeframe) | Monitor timeframe for APIGateway 4xxerror [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_apigateway_5xxerror_aggregator"></a> [apigateway\_5xxerror\_aggregator](#input\_apigateway\_5xxerror\_aggregator) | Monitor aggregator for APIGateway 5xxerror [available values: min, max or avg] | `string` | `"sum"` | no |
| <a name="input_apigateway_5xxerror_enabled"></a> [apigateway\_5xxerror\_enabled](#input\_apigateway\_5xxerror\_enabled) | Flag to enable APIGateway 5xxerror monitor | `string` | `"true"` | no |
| <a name="input_apigateway_5xxerror_extra_tags"></a> [apigateway\_5xxerror\_extra\_tags](#input\_apigateway\_5xxerror\_extra\_tags) | Extra tags for APIGateway 5xxerror monitor | `list(string)` | `[]` | no |
| <a name="input_apigateway_5xxerror_message"></a> [apigateway\_5xxerror\_message](#input\_apigateway\_5xxerror\_message) | Custom message for APIGateway 5xxerror | `string` | `""` | no |
| <a name="input_apigateway_5xxerror_no_data_timeframe"></a> [apigateway\_5xxerror\_no\_data\_timeframe](#input\_apigateway\_5xxerror\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_apigateway_5xxerror_notify_no_data"></a> [apigateway\_5xxerror\_notify\_no\_data](#input\_apigateway\_5xxerror\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_apigateway_5xxerror_threshold_critical"></a> [apigateway\_5xxerror\_threshold\_critical](#input\_apigateway\_5xxerror\_threshold\_critical) | APIGateway 5xxerror critical threshold | `number` | `80` | no |
| <a name="input_apigateway_5xxerror_threshold_warning"></a> [apigateway\_5xxerror\_threshold\_warning](#input\_apigateway\_5xxerror\_threshold\_warning) | APIGateway 5xxerror warning threshold | `number` | `60` | no |
| <a name="input_apigateway_5xxerror_timeframe"></a> [apigateway\_5xxerror\_timeframe](#input\_apigateway\_5xxerror\_timeframe) | Monitor timeframe for APIGateway 5xxerror [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_apigateway_count_aggregator"></a> [apigateway\_count\_aggregator](#input\_apigateway\_count\_aggregator) | Monitor aggregator for APIGateway Count [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_apigateway_count_enabled"></a> [apigateway\_count\_enabled](#input\_apigateway\_count\_enabled) | Flag to enable APIGateway Count monitor | `string` | `"true"` | no |
| <a name="input_apigateway_count_extra_tags"></a> [apigateway\_count\_extra\_tags](#input\_apigateway\_count\_extra\_tags) | Extra tags for APIGateway Count monitor | `list(string)` | `[]` | no |
| <a name="input_apigateway_count_message"></a> [apigateway\_count\_message](#input\_apigateway\_count\_message) | Custom message for APIGateway Count | `string` | `""` | no |
| <a name="input_apigateway_count_no_data_timeframe"></a> [apigateway\_count\_no\_data\_timeframe](#input\_apigateway\_count\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_apigateway_count_notify_no_data"></a> [apigateway\_count\_notify\_no\_data](#input\_apigateway\_count\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_apigateway_count_threshold_critical"></a> [apigateway\_count\_threshold\_critical](#input\_apigateway\_count\_threshold\_critical) | APIGateway Count critical threshold | `number` | `30` | no |
| <a name="input_apigateway_count_threshold_warning"></a> [apigateway\_count\_threshold\_warning](#input\_apigateway\_count\_threshold\_warning) | APIGateway Count warning threshold | `number` | `20` | no |
| <a name="input_apigateway_count_timeframe"></a> [apigateway\_count\_timeframe](#input\_apigateway\_count\_timeframe) | Monitor timeframe for APIGateway Count [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_apigateway_dashboard_tags"></a> [apigateway\_dashboard\_tags](#input\_apigateway\_dashboard\_tags) | Dashboard Tags | `list(string)` | `[]` | no |
| <a name="input_apigateway_latency_aggregator"></a> [apigateway\_latency\_aggregator](#input\_apigateway\_latency\_aggregator) | Monitor aggregator for APIGateway Latency [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_apigateway_latency_enabled"></a> [apigateway\_latency\_enabled](#input\_apigateway\_latency\_enabled) | Flag to enable APIGateway Latency monitor | `string` | `"true"` | no |
| <a name="input_apigateway_latency_extra_tags"></a> [apigateway\_latency\_extra\_tags](#input\_apigateway\_latency\_extra\_tags) | Extra tags for APIGateway Latency monitor | `list(string)` | `[]` | no |
| <a name="input_apigateway_latency_message"></a> [apigateway\_latency\_message](#input\_apigateway\_latency\_message) | Custom message for APIGateway Latency | `string` | `""` | no |
| <a name="input_apigateway_latency_no_data_timeframe"></a> [apigateway\_latency\_no\_data\_timeframe](#input\_apigateway\_latency\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_apigateway_latency_notify_no_data"></a> [apigateway\_latency\_notify\_no\_data](#input\_apigateway\_latency\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_apigateway_latency_threshold_critical"></a> [apigateway\_latency\_threshold\_critical](#input\_apigateway\_latency\_threshold\_critical) | APIGateway Latency critical threshold | `number` | `50000` | no |
| <a name="input_apigateway_latency_threshold_warning"></a> [apigateway\_latency\_threshold\_warning](#input\_apigateway\_latency\_threshold\_warning) | APIGateway Latency warning threshold | `number` | `40000` | no |
| <a name="input_apigateway_latency_timeframe"></a> [apigateway\_latency\_timeframe](#input\_apigateway\_latency\_timeframe) | Monitor timeframe for APIGateway Latency [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_apigateway_metrics_panel_height"></a> [apigateway\_metrics\_panel\_height](#input\_apigateway\_metrics\_panel\_height) | Height of the panel | `number` | `21` | no |
| <a name="input_apigateway_metrics_panel_width"></a> [apigateway\_metrics\_panel\_width](#input\_apigateway\_metrics\_panel\_width) | Width of the panel | `number` | `33` | no |
| <a name="input_apigateway_monitor_tags"></a> [apigateway\_monitor\_tags](#input\_apigateway\_monitor\_tags) | Monitor Tags | `list(string)` | `[]` | no |
| <a name="input_apigateway_resource_panel_height"></a> [apigateway\_resource\_panel\_height](#input\_apigateway\_resource\_panel\_height) | Height of the panel | `number` | `7` | no |
| <a name="input_apigateway_resource_panel_width"></a> [apigateway\_resource\_panel\_width](#input\_apigateway\_resource\_panel\_width) | Width Of the Panel | `number` | `68` | no |
| <a name="input_apigateway_resource_tags"></a> [apigateway\_resource\_tags](#input\_apigateway\_resource\_tags) | Resource Tags | `list(string)` | `[]` | no |
| <a name="input_apigateway_x_axis_intial_value"></a> [apigateway\_x\_axis\_intial\_value](#input\_apigateway\_x\_axis\_intial\_value) | Intial value of X-axis | `number` | `0` | no |
| <a name="input_apigateway_x_even"></a> [apigateway\_x\_even](#input\_apigateway\_x\_even) | Values of X-axis For Even Number Column | `list(number)` | <pre>[<br>  48,<br>  117,<br>  186,<br>  255,<br>  324,<br>  393,<br>  462,<br>  531,<br>  600,<br>  669<br>]</pre> | no |
| <a name="input_apigateway_x_odd"></a> [apigateway\_x\_odd](#input\_apigateway\_x\_odd) | Values of X-axis For Odd Number Column | `list(number)` | <pre>[<br>  14,<br>  83,<br>  152,<br>  221,<br>  290,<br>  359,<br>  428,<br>  497,<br>  566,<br>  635<br>]</pre> | no |
| <a name="input_apigateway_y"></a> [apigateway\_y](#input\_apigateway\_y) | Values of Y-axis | `list(number)` | <pre>[<br>  9,<br>  32,<br>  55,<br>  78,<br>  101,<br>  124,<br>  147,<br>  170,<br>  193,<br>  216<br>]</pre> | no |
| <a name="input_apigateway_y_axis_intial_value"></a> [apigateway\_y\_axis\_intial\_value](#input\_apigateway\_y\_axis\_intial\_value) | Intial value of Y-axis | `number` | `0` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | Architecture environment | `string` | n/a | yes |
| <a name="input_evaluation_delay"></a> [evaluation\_delay](#input\_evaluation\_delay) | Delay in seconds for the metric evaluation | `number` | `900` | no |
| <a name="input_filter_tags_custom"></a> [filter\_tags\_custom](#input\_filter\_tags\_custom) | Tags used for custom filtering when filter\_tags\_use\_defaults is false | `string` | `"*"` | no |
| <a name="input_filter_tags_custom_excluded"></a> [filter\_tags\_custom\_excluded](#input\_filter\_tags\_custom\_excluded) | Tags excluded for custom filtering when filter\_tags\_use\_defaults is false | `string` | `""` | no |
| <a name="input_filter_tags_use_defaults"></a> [filter\_tags\_use\_defaults](#input\_filter\_tags\_use\_defaults) | Use default filter tags convention | `string` | `"true"` | no |
| <a name="input_message"></a> [message](#input\_message) | Message sent when a monitor is triggered | `any` | n/a | yes |
| <a name="input_new_host_delay"></a> [new\_host\_delay](#input\_new\_host\_delay) | Delay in seconds before monitor new resource | `number` | `300` | no |
| <a name="input_prefix_slug"></a> [prefix\_slug](#input\_prefix\_slug) | Prefix string to prepend between brackets on every monitors names | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_apigateway_4xxerror"></a> [apigateway\_4xxerror](#output\_apigateway\_4xxerror) | id for monitor APIGateway 4xxError |
| <a name="output_apigateway_5xxerror"></a> [apigateway\_5xxerror](#output\_apigateway\_5xxerror) | id for monitor APIGateway 5xxError |
| <a name="output_apigateway_count"></a> [apigateway\_count](#output\_apigateway\_count) | id for monitor APIGateway Count |
| <a name="output_apigateway_latency_id"></a> [apigateway\_latency\_id](#output\_apigateway\_latency\_id) | id for monitor APIGateway Latency |
