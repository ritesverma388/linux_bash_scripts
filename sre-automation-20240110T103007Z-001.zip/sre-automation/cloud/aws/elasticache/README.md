# CLOUD AWS ELASTICACHE COMMON DataDog monitors

## How to use this module

```hcl
module "datadog-monitors-cloud-aws-elasticache-common" {
  source      = "../../cloud/aws/elasticache/common"
  environment = var.environment
  message     = module.datadog-message-alerting.alerting-message
}

```

## Purpose

Creates DataDog monitors with the following checks:

- Elasticache connections
- Elasticache eviction
- Elasticache evictions is growing
- Elasticache free memory
- Elasticache max connections reached
- Elasticache swap

## Requirements

| Name | Version |
|------|---------|
| terraform | >= 0.12.26 |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| elasticache\_max\_connection\_no\_data\_timeframe | Number of minutes before reporting no data | `string` | `10` | no |
| environment | Infrastructure Environment | `string` | n/a | yes |
| evaluation\_delay | Delay in seconds for the metric evaluation | `number` | `900` | no |
| eviction\_enabled | Flag to enable Elasticache eviction monitor | `string` | `"true"` | no |
| eviction\_extra\_tags | Extra tags for Elasticache eviction monitor | `list(string)` | `[]` | no |
| eviction\_growing\_condition\_timeframe | Monitor condition timeframe for Elasticache eviction growing [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_5m"` | no |
| eviction\_growing\_enabled | Flag to enable Elasticache eviction growing monitor | `string` | `"true"` | no |
| eviction\_growing\_extra\_tags | Extra tags for Elasticache eviction growing monitor | `list(string)` | `[]` | no |
| eviction\_growing\_message | Custom message for Elasticache eviction growing monitor | `string` | `""` | no |
| eviction\_growing\_threshold\_critical | Elasticache eviction growing critical threshold in percentage | `string` | `30` | no |
| eviction\_growing\_threshold\_warning | Elasticache eviction growing warning threshold in percentage | `string` | `10` | no |
| eviction\_growing\_timeframe | Monitor timeframe for Elasticache eviction growing [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_5m"` | no |
| eviction\_message | Custom message for Elasticache eviction monitor | `string` | `""` | no |
| eviction\_threshold\_critical | Elasticache free memory critical threshold in percentage | `string` | `30` | no |
| eviction\_threshold\_warning | Elasticache free memory warning threshold in percentage | `string` | `0` | no |
| eviction\_timeframe | Monitor timeframe for Elasticache eviction [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_15m"` | no |
| filter\_tags\_custom | Tags used for custom filtering when filter\_tags\_use\_defaults is false | `string` | `"*"` | no |
| filter\_tags\_custom\_excluded | Tags excluded for custom filtering when filter\_tags\_use\_defaults is false | `string` | `""` | no |
| filter\_tags\_use\_defaults | Use default filter tags convention | `string` | `"true"` | no |
| free\_memory\_condition\_timeframe | Monitor condition timeframe for Elasticache free memory [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_15m"` | no |
| free\_memory\_enabled | Flag to enable Elasticache free memory monitor | `string` | `"true"` | no |
| free\_memory\_extra\_tags | Extra tags for Elasticache free memory monitor | `list(string)` | `[]` | no |
| free\_memory\_message | Custom message for Elasticache free memory monitor | `string` | `""` | no |
| free\_memory\_threshold\_critical | Elasticache free memory critical threshold in percentage | `string` | `-70` | no |
| free\_memory\_threshold\_warning | Elasticache free memory warning threshold in percentage | `string` | `-50` | no |
| free\_memory\_timeframe | Monitor timeframe for Elasticache free memory [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_15m"` | no |
| max\_connection\_enabled | Flag to enable Elasticache max connection monitor | `string` | `"true"` | no |
| max\_connection\_extra\_tags | Extra tags for Elasticache max connection monitor | `list(string)` | `[]` | no |
| max\_connection\_message | Custom message for Elasticache max connection monitor | `string` | `""` | no |
| max\_connection\_time\_aggregator | Monitor aggregator for Elasticache max connection [available values: min, max or avg] | `string` | `"max"` | no |
| max\_connection\_timeframe | Monitor timeframe for Elasticache max connection [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_5m"` | no |
| message | Message sent when an alert is triggered | `any` | n/a | yes |
| new\_host\_delay | Delay in seconds before monitor new resource | `number` | `300` | no |
| no\_connection\_enabled | Flag to enable Elasticache no connection monitor | `string` | `"true"` | no |
| no\_connection\_extra\_tags | Extra tags for Elasticache no connection monitor | `list(string)` | `[]` | no |
| no\_connection\_message | Custom message for Elasticache no connection monitor | `string` | `""` | no |
| no\_connection\_time\_aggregator | Monitor aggregator for Elasticache no connection [available values: min, max or avg] | `string` | `"min"` | no |
| no\_connection\_timeframe | Monitor timeframe for Elasticache no connection [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_5m"` | no |
| notify\_no\_data | Will raise no data alert if set to true | `bool` | `true` | no |
| prefix\_slug | Prefix string to prepend between brackets on every monitors names | `string` | `""` | no |
| swap\_enabled | Flag to enable Elasticache swap monitor | `string` | `"true"` | no |
| swap\_extra\_tags | Extra tags for Elasticache swap monitor | `list(string)` | `[]` | no |
| swap\_message | Custom message for Elasticache swap monitor | `string` | `""` | no |
| swap\_threshold\_critical | Elasticache swap critical threshold in bytes | `string` | `50000000` | no |
| swap\_threshold\_warning | Elasticache swap warning threshold in bytes | `string` | `0` | no |
| swap\_time\_aggregator | Monitor aggregator for Elasticache memcached swap [available values: min, max or avg] | `string` | `"min"` | no |
| swap\_timeframe | Monitor timeframe for Elasticache swap [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_5m"` | no |

## Outputs

| Name | Description |
|------|-------------|
| elasticache\_eviction\_growing\_id | id for monitor elasticache\_eviction\_growing |
| elasticache\_eviction\_id | id for monitor elasticache\_eviction |
| elasticache\_free\_memory\_id | id for monitor elasticache\_free\_memory |
| elasticache\_max\_connection\_id | id for monitor elasticache\_max\_connection |
| elasticache\_no\_connection\_id | id for monitor elasticache\_no\_connection |
| elasticache\_swap\_id | id for monitor elasticache\_swap |

## Related documentation

DataDog documentation: [https://docs.datadoghq.com/integrations/amazon_elasticache/](https://docs.datadoghq.com/integrations/amazon_elasticache/)
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | ~> 0.13.6 |
| <a name="requirement_datadog"></a> [datadog](#requirement\_datadog) | ~> 3.7.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_datadog"></a> [datadog](#provider\_datadog) | ~> 3.7.0 |
| <a name="provider_template"></a> [template](#provider\_template) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_filter-tags"></a> [filter-tags](#module\_filter-tags) | ../../../common/filter-tags |  |

## Resources

| Name | Type |
|------|------|
| [datadog_dashboard_json.dashboard_elasticache](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/dashboard_json) | resource |
| [datadog_monitor.elasticache_cpuutilization](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.elasticache_evictions](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.elasticache_freeable_memory](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.elasticache_misses](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [template_file.elasticache_dashboard](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |
| [template_file.elasticache_widgets](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_elasticache_cpuutilization_aggregator"></a> [elasticache\_cpuutilization\_aggregator](#input\_elasticache\_cpuutilization\_aggregator) | Monitor aggregator for elasticache CPU Utilization [available values: min, max or avg] | `string` | `"sum"` | no |
| <a name="input_elasticache_cpuutilization_enabled"></a> [elasticache\_cpuutilization\_enabled](#input\_elasticache\_cpuutilization\_enabled) | Flag to enable elasticache CPU Utilization monitor | `string` | `"true"` | no |
| <a name="input_elasticache_cpuutilization_extra_tags"></a> [elasticache\_cpuutilization\_extra\_tags](#input\_elasticache\_cpuutilization\_extra\_tags) | Extra tags for elasticache CPU Utilization monitor | `list(string)` | `[]` | no |
| <a name="input_elasticache_cpuutilization_message"></a> [elasticache\_cpuutilization\_message](#input\_elasticache\_cpuutilization\_message) | Custom message for elasticache CPU Utilization | `string` | `""` | no |
| <a name="input_elasticache_cpuutilization_no_data_timeframe"></a> [elasticache\_cpuutilization\_no\_data\_timeframe](#input\_elasticache\_cpuutilization\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_elasticache_cpuutilization_notify_no_data"></a> [elasticache\_cpuutilization\_notify\_no\_data](#input\_elasticache\_cpuutilization\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_elasticache_cpuutilization_threshold_critical"></a> [elasticache\_cpuutilization\_threshold\_critical](#input\_elasticache\_cpuutilization\_threshold\_critical) | elasticache CPU Utilization critical threshold | `number` | `80` | no |
| <a name="input_elasticache_cpuutilization_threshold_warning"></a> [elasticache\_cpuutilization\_threshold\_warning](#input\_elasticache\_cpuutilization\_threshold\_warning) | elasticache CPU Utilization warning threshold | `number` | `60` | no |
| <a name="input_elasticache_cpuutilization_timeframe"></a> [elasticache\_cpuutilization\_timeframe](#input\_elasticache\_cpuutilization\_timeframe) | Monitor timeframe for elasticache CPU Utilization [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_elasticache_dashboard_tags"></a> [elasticache\_dashboard\_tags](#input\_elasticache\_dashboard\_tags) | Dashboard Tags | `list(string)` | `[]` | no |
| <a name="input_elasticache_evictions_aggregator"></a> [elasticache\_evictions\_aggregator](#input\_elasticache\_evictions\_aggregator) | Monitor aggregator for elasticache Evictions [available values: min, max or avg] | `string` | `"sum"` | no |
| <a name="input_elasticache_evictions_enabled"></a> [elasticache\_evictions\_enabled](#input\_elasticache\_evictions\_enabled) | Flag to enable elasticache Evictions monitor | `string` | `"true"` | no |
| <a name="input_elasticache_evictions_extra_tags"></a> [elasticache\_evictions\_extra\_tags](#input\_elasticache\_evictions\_extra\_tags) | Extra tags for elasticache Evictions monitor | `list(string)` | `[]` | no |
| <a name="input_elasticache_evictions_message"></a> [elasticache\_evictions\_message](#input\_elasticache\_evictions\_message) | Custom message for elasticache Evictions | `string` | `""` | no |
| <a name="input_elasticache_evictions_no_data_timeframe"></a> [elasticache\_evictions\_no\_data\_timeframe](#input\_elasticache\_evictions\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_elasticache_evictions_notify_no_data"></a> [elasticache\_evictions\_notify\_no\_data](#input\_elasticache\_evictions\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_elasticache_evictions_threshold_critical"></a> [elasticache\_evictions\_threshold\_critical](#input\_elasticache\_evictions\_threshold\_critical) | elasticache Evictions critical threshold | `number` | `80` | no |
| <a name="input_elasticache_evictions_threshold_warning"></a> [elasticache\_evictions\_threshold\_warning](#input\_elasticache\_evictions\_threshold\_warning) | elasticache Evictions warning threshold | `number` | `50` | no |
| <a name="input_elasticache_evictions_timeframe"></a> [elasticache\_evictions\_timeframe](#input\_elasticache\_evictions\_timeframe) | Monitor timeframe for elasticache Evictions [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_elasticache_freeable_memory_aggregator"></a> [elasticache\_freeable\_memory\_aggregator](#input\_elasticache\_freeable\_memory\_aggregator) | Monitor aggregator for elasticache Freeable Memory [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_elasticache_freeable_memory_enabled"></a> [elasticache\_freeable\_memory\_enabled](#input\_elasticache\_freeable\_memory\_enabled) | Flag to enable elasticache Freeable Memory monitor | `string` | `"true"` | no |
| <a name="input_elasticache_freeable_memory_extra_tags"></a> [elasticache\_freeable\_memory\_extra\_tags](#input\_elasticache\_freeable\_memory\_extra\_tags) | Extra tags for elasticache Freeable Memory monitor | `list(string)` | `[]` | no |
| <a name="input_elasticache_freeable_memory_message"></a> [elasticache\_freeable\_memory\_message](#input\_elasticache\_freeable\_memory\_message) | Custom message for elasticache Freeable Memory | `string` | `""` | no |
| <a name="input_elasticache_freeable_memory_no_data_timeframe"></a> [elasticache\_freeable\_memory\_no\_data\_timeframe](#input\_elasticache\_freeable\_memory\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_elasticache_freeable_memory_notify_no_data"></a> [elasticache\_freeable\_memory\_notify\_no\_data](#input\_elasticache\_freeable\_memory\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_elasticache_freeable_memory_threshold_critical"></a> [elasticache\_freeable\_memory\_threshold\_critical](#input\_elasticache\_freeable\_memory\_threshold\_critical) | elasticache Freeable Memory critical threshold | `number` | `20000000000` | no |
| <a name="input_elasticache_freeable_memory_threshold_warning"></a> [elasticache\_freeable\_memory\_threshold\_warning](#input\_elasticache\_freeable\_memory\_threshold\_warning) | elasticache Freeable Memory warning threshold | `number` | `22000000000` | no |
| <a name="input_elasticache_freeable_memory_timeframe"></a> [elasticache\_freeable\_memory\_timeframe](#input\_elasticache\_freeable\_memory\_timeframe) | Monitor timeframe for elasticache Freeable Memory [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_elasticache_metrics_panel_height"></a> [elasticache\_metrics\_panel\_height](#input\_elasticache\_metrics\_panel\_height) | Height of the panel | `number` | `21` | no |
| <a name="input_elasticache_metrics_panel_width"></a> [elasticache\_metrics\_panel\_width](#input\_elasticache\_metrics\_panel\_width) | Width of the panel | `number` | `33` | no |
| <a name="input_elasticache_misses_aggregator"></a> [elasticache\_misses\_aggregator](#input\_elasticache\_misses\_aggregator) | Monitor aggregator for elasticache Misses [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_elasticache_misses_enabled"></a> [elasticache\_misses\_enabled](#input\_elasticache\_misses\_enabled) | Flag to enable elasticache Misses monitor | `string` | `"true"` | no |
| <a name="input_elasticache_misses_extra_tags"></a> [elasticache\_misses\_extra\_tags](#input\_elasticache\_misses\_extra\_tags) | Extra tags for elasticache Misses monitor | `list(string)` | `[]` | no |
| <a name="input_elasticache_misses_message"></a> [elasticache\_misses\_message](#input\_elasticache\_misses\_message) | Custom message for elasticache Misses | `string` | `""` | no |
| <a name="input_elasticache_misses_no_data_timeframe"></a> [elasticache\_misses\_no\_data\_timeframe](#input\_elasticache\_misses\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_elasticache_misses_notify_no_data"></a> [elasticache\_misses\_notify\_no\_data](#input\_elasticache\_misses\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_elasticache_misses_threshold_critical"></a> [elasticache\_misses\_threshold\_critical](#input\_elasticache\_misses\_threshold\_critical) | elasticache Misses critical threshold | `number` | `200` | no |
| <a name="input_elasticache_misses_threshold_warning"></a> [elasticache\_misses\_threshold\_warning](#input\_elasticache\_misses\_threshold\_warning) | elasticache Misses warning threshold | `number` | `150` | no |
| <a name="input_elasticache_misses_timeframe"></a> [elasticache\_misses\_timeframe](#input\_elasticache\_misses\_timeframe) | Monitor timeframe for elasticache Misses [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_15m"` | no |
| <a name="input_elasticache_monitor_tags"></a> [elasticache\_monitor\_tags](#input\_elasticache\_monitor\_tags) | Monitor Tags | `list(string)` | `[]` | no |
| <a name="input_elasticache_resource_panel_height"></a> [elasticache\_resource\_panel\_height](#input\_elasticache\_resource\_panel\_height) | Height of the panel | `number` | `7` | no |
| <a name="input_elasticache_resource_panel_width"></a> [elasticache\_resource\_panel\_width](#input\_elasticache\_resource\_panel\_width) | Width Of the Panel | `number` | `33` | no |
| <a name="input_elasticache_x"></a> [elasticache\_x](#input\_elasticache\_x) | Values of X-axis | `list(number)` | <pre>[<br>  14,<br>  49,<br>  84,<br>  119,<br>  154,<br>  189,<br>  224,<br>  259,<br>  294,<br>  329<br>]</pre> | no |
| <a name="input_elasticache_x_axis_intial_value"></a> [elasticache\_x\_axis\_intial\_value](#input\_elasticache\_x\_axis\_intial\_value) | Intial value of X-axis | `number` | `0` | no |
| <a name="input_elasticache_y"></a> [elasticache\_y](#input\_elasticache\_y) | Values of Y-axis | `list(number)` | <pre>[<br>  9,<br>  32,<br>  55,<br>  78,<br>  101,<br>  124,<br>  147,<br>  170,<br>  193,<br>  216<br>]</pre> | no |
| <a name="input_elasticache_y_axis_intial_value"></a> [elasticache\_y\_axis\_intial\_value](#input\_elasticache\_y\_axis\_intial\_value) | Intial value of Y-axis | `number` | `0` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | Architecture environment | `string` | n/a | yes |
| <a name="input_evaluation_delay"></a> [evaluation\_delay](#input\_evaluation\_delay) | Delay in seconds for the metric evaluation | `number` | `900` | no |
| <a name="input_filter_tags_custom"></a> [filter\_tags\_custom](#input\_filter\_tags\_custom) | Tags used for custom filtering when filter\_tags\_use\_defaults is false | `string` | `"*"` | no |
| <a name="input_filter_tags_custom_excluded"></a> [filter\_tags\_custom\_excluded](#input\_filter\_tags\_custom\_excluded) | Tags excluded for custom filtering when filter\_tags\_use\_defaults is false | `string` | `""` | no |
| <a name="input_filter_tags_use_defaults"></a> [filter\_tags\_use\_defaults](#input\_filter\_tags\_use\_defaults) | Use default filter tags convention | `string` | `"true"` | no |
| <a name="input_message"></a> [message](#input\_message) | Message sent when a monitor is triggered | `any` | n/a | yes |
| <a name="input_new_host_delay"></a> [new\_host\_delay](#input\_new\_host\_delay) | Delay in seconds before monitor new resource | `number` | `300` | no |
| <a name="input_notify_no_data"></a> [notify\_no\_data](#input\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_prefix_slug"></a> [prefix\_slug](#input\_prefix\_slug) | Prefix string to prepend between brackets on every monitors names | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_elasticache_cpuutilization_id"></a> [elasticache\_cpuutilization\_id](#output\_elasticache\_cpuutilization\_id) | id for monitor Elasticache CPU Utilization |
| <a name="output_elasticache_evictions_id"></a> [elasticache\_evictions\_id](#output\_elasticache\_evictions\_id) | id for monitor Elasticache Evictions |
| <a name="output_elasticache_freeable_memory_id"></a> [elasticache\_freeable\_memory\_id](#output\_elasticache\_freeable\_memory\_id) | id for monitor Elasticache Freeable Memory |
| <a name="output_elasticache_misses_id"></a> [elasticache\_misses\_id](#output\_elasticache\_misses\_id) | id for monitor Elasticache Misses |
