## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | ~> 0.13.6 |
| <a name="requirement_datadog"></a> [datadog](#requirement\_datadog) | ~> 3.7.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_datadog"></a> [datadog](#provider\_datadog) | ~> 3.7.0 |
| <a name="provider_template"></a> [template](#provider\_template) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_filter-tags"></a> [filter-tags](#module\_filter-tags) | ../../../common/filter-tags |  |

## Resources

| Name | Type |
|------|------|
| [datadog_dashboard_json.dashboard_lambda](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/dashboard_json) | resource |
| [datadog_monitor.lambda_duration](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.lambda_errors](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.lambda_invocations](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.lambda_iterator_age](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.lambda_throttles](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [template_file.lambda_dashboard](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |
| [template_file.lambda_widgets](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_environment"></a> [environment](#input\_environment) | Architecture environment | `string` | n/a | yes |
| <a name="input_evaluation_delay"></a> [evaluation\_delay](#input\_evaluation\_delay) | Delay in seconds for the metric evaluation | `number` | `900` | no |
| <a name="input_filter_tags_custom"></a> [filter\_tags\_custom](#input\_filter\_tags\_custom) | Tags used for custom filtering when filter\_tags\_use\_defaults is false | `string` | `"*"` | no |
| <a name="input_filter_tags_custom_excluded"></a> [filter\_tags\_custom\_excluded](#input\_filter\_tags\_custom\_excluded) | Tags excluded for custom filtering when filter\_tags\_use\_defaults is false | `string` | `""` | no |
| <a name="input_filter_tags_use_defaults"></a> [filter\_tags\_use\_defaults](#input\_filter\_tags\_use\_defaults) | Use default filter tags convention | `string` | `"true"` | no |
| <a name="input_lambda_dashboard_tags"></a> [lambda\_dashboard\_tags](#input\_lambda\_dashboard\_tags) | Dashboard Tags | `list(string)` | `[]` | no |
| <a name="input_lambda_duration_aggregator"></a> [lambda\_duration\_aggregator](#input\_lambda\_duration\_aggregator) | Monitor aggregator for Lambda Function Duration [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_lambda_duration_enabled"></a> [lambda\_duration\_enabled](#input\_lambda\_duration\_enabled) | Flag to enable Lambda Function Duration monitor | `string` | `"true"` | no |
| <a name="input_lambda_duration_extra_tags"></a> [lambda\_duration\_extra\_tags](#input\_lambda\_duration\_extra\_tags) | Extra tags for Lambda Function Duration monitor | `list(string)` | `[]` | no |
| <a name="input_lambda_duration_message"></a> [lambda\_duration\_message](#input\_lambda\_duration\_message) | Custom message for Lambda Function Duration | `string` | `""` | no |
| <a name="input_lambda_duration_no_data_timeframe"></a> [lambda\_duration\_no\_data\_timeframe](#input\_lambda\_duration\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_lambda_duration_notify_no_data"></a> [lambda\_duration\_notify\_no\_data](#input\_lambda\_duration\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_lambda_duration_threshold_critical"></a> [lambda\_duration\_threshold\_critical](#input\_lambda\_duration\_threshold\_critical) | Lambda Function Duration critical threshold | `number` | `30` | no |
| <a name="input_lambda_duration_threshold_warning"></a> [lambda\_duration\_threshold\_warning](#input\_lambda\_duration\_threshold\_warning) | Lambda Function Duration warning threshold | `number` | `15` | no |
| <a name="input_lambda_duration_timeframe"></a> [lambda\_duration\_timeframe](#input\_lambda\_duration\_timeframe) | Monitor timeframe for Lambda Function Duration [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_lambda_errors_aggregator"></a> [lambda\_errors\_aggregator](#input\_lambda\_errors\_aggregator) | Monitor aggregator for Lambda Function Errors [available values: min, max or avg] | `string` | `"sum"` | no |
| <a name="input_lambda_errors_enabled"></a> [lambda\_errors\_enabled](#input\_lambda\_errors\_enabled) | Flag to enable Lambda Function Errors monitor | `string` | `"true"` | no |
| <a name="input_lambda_errors_extra_tags"></a> [lambda\_errors\_extra\_tags](#input\_lambda\_errors\_extra\_tags) | Extra tags for Lambda Function Errors monitor | `list(string)` | `[]` | no |
| <a name="input_lambda_errors_message"></a> [lambda\_errors\_message](#input\_lambda\_errors\_message) | Custom message for Lambda Function Errors | `string` | `""` | no |
| <a name="input_lambda_errors_no_data_timeframe"></a> [lambda\_errors\_no\_data\_timeframe](#input\_lambda\_errors\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_lambda_errors_notify_no_data"></a> [lambda\_errors\_notify\_no\_data](#input\_lambda\_errors\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_lambda_errors_threshold_critical"></a> [lambda\_errors\_threshold\_critical](#input\_lambda\_errors\_threshold\_critical) | Lambda Function Errors critical threshold | `number` | `25` | no |
| <a name="input_lambda_errors_threshold_warning"></a> [lambda\_errors\_threshold\_warning](#input\_lambda\_errors\_threshold\_warning) | Lambda Function Errors warning threshold | `number` | `20` | no |
| <a name="input_lambda_errors_timeframe"></a> [lambda\_errors\_timeframe](#input\_lambda\_errors\_timeframe) | Monitor timeframe for Lambda Function Errors [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_lambda_invocations_aggregator"></a> [lambda\_invocations\_aggregator](#input\_lambda\_invocations\_aggregator) | Monitor aggregator for Lambda Function Invocations [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_lambda_invocations_enabled"></a> [lambda\_invocations\_enabled](#input\_lambda\_invocations\_enabled) | Flag to enable Lambda Function Invocations monitor | `string` | `"true"` | no |
| <a name="input_lambda_invocations_extra_tags"></a> [lambda\_invocations\_extra\_tags](#input\_lambda\_invocations\_extra\_tags) | Extra tags for Lambda Function Invocations monitor | `list(string)` | `[]` | no |
| <a name="input_lambda_invocations_message"></a> [lambda\_invocations\_message](#input\_lambda\_invocations\_message) | Custom message for Lambda Function Invocations | `string` | `""` | no |
| <a name="input_lambda_invocations_no_data_timeframe"></a> [lambda\_invocations\_no\_data\_timeframe](#input\_lambda\_invocations\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_lambda_invocations_notify_no_data"></a> [lambda\_invocations\_notify\_no\_data](#input\_lambda\_invocations\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_lambda_invocations_threshold_critical"></a> [lambda\_invocations\_threshold\_critical](#input\_lambda\_invocations\_threshold\_critical) | Lambda Function Invocations critical threshold | `number` | `50` | no |
| <a name="input_lambda_invocations_threshold_warning"></a> [lambda\_invocations\_threshold\_warning](#input\_lambda\_invocations\_threshold\_warning) | Lambda Function Invocations warning threshold | `number` | `40` | no |
| <a name="input_lambda_invocations_timeframe"></a> [lambda\_invocations\_timeframe](#input\_lambda\_invocations\_timeframe) | Monitor timeframe for Lambda Function Invocations [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_lambda_iterator_age_aggregator"></a> [lambda\_iterator\_age\_aggregator](#input\_lambda\_iterator\_age\_aggregator) | Monitor aggregator for Lambda Function Iterator Age [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_lambda_iterator_age_enabled"></a> [lambda\_iterator\_age\_enabled](#input\_lambda\_iterator\_age\_enabled) | Flag to enable Lambda Function Iterator Age monitor | `string` | `"true"` | no |
| <a name="input_lambda_iterator_age_extra_tags"></a> [lambda\_iterator\_age\_extra\_tags](#input\_lambda\_iterator\_age\_extra\_tags) | Extra tags for Lambda Function Iterator Age monitor | `list(string)` | `[]` | no |
| <a name="input_lambda_iterator_age_message"></a> [lambda\_iterator\_age\_message](#input\_lambda\_iterator\_age\_message) | Custom message for Lambda Function Iterator Age | `string` | `""` | no |
| <a name="input_lambda_iterator_age_no_data_timeframe"></a> [lambda\_iterator\_age\_no\_data\_timeframe](#input\_lambda\_iterator\_age\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_lambda_iterator_age_notify_no_data"></a> [lambda\_iterator\_age\_notify\_no\_data](#input\_lambda\_iterator\_age\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_lambda_iterator_age_threshold_critical"></a> [lambda\_iterator\_age\_threshold\_critical](#input\_lambda\_iterator\_age\_threshold\_critical) | Lambda Function Iterator Age critical threshold | `number` | `60` | no |
| <a name="input_lambda_iterator_age_threshold_warning"></a> [lambda\_iterator\_age\_threshold\_warning](#input\_lambda\_iterator\_age\_threshold\_warning) | Lambda Function Iterator Age warning threshold | `number` | `50` | no |
| <a name="input_lambda_iterator_age_timeframe"></a> [lambda\_iterator\_age\_timeframe](#input\_lambda\_iterator\_age\_timeframe) | Monitor timeframe for Lambda Function Iterator Age [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_lambda_metrics_panel_height"></a> [lambda\_metrics\_panel\_height](#input\_lambda\_metrics\_panel\_height) | Height of the panel | `number` | `21` | no |
| <a name="input_lambda_metrics_panel_width"></a> [lambda\_metrics\_panel\_width](#input\_lambda\_metrics\_panel\_width) | Width of the panel | `number` | `33` | no |
| <a name="input_lambda_monitor_tags"></a> [lambda\_monitor\_tags](#input\_lambda\_monitor\_tags) | Monitor Tags | `list(string)` | `[]` | no |
| <a name="input_lambda_resource_panel_height"></a> [lambda\_resource\_panel\_height](#input\_lambda\_resource\_panel\_height) | Height of the panel | `number` | `7` | no |
| <a name="input_lambda_resource_panel_width"></a> [lambda\_resource\_panel\_width](#input\_lambda\_resource\_panel\_width) | Width Of the Panel | `number` | `33` | no |
| <a name="input_lambda_throttles_aggregator"></a> [lambda\_throttles\_aggregator](#input\_lambda\_throttles\_aggregator) | Monitor aggregator for Lambda Function Throttles [available values: min, max or avg] | `string` | `"sum"` | no |
| <a name="input_lambda_throttles_enabled"></a> [lambda\_throttles\_enabled](#input\_lambda\_throttles\_enabled) | Flag to enable Lambda Function Throttles monitor | `string` | `"true"` | no |
| <a name="input_lambda_throttles_extra_tags"></a> [lambda\_throttles\_extra\_tags](#input\_lambda\_throttles\_extra\_tags) | Extra tags for Lambda Function Throttles monitor | `list(string)` | `[]` | no |
| <a name="input_lambda_throttles_message"></a> [lambda\_throttles\_message](#input\_lambda\_throttles\_message) | Custom message for Lambda Function Throttles | `string` | `""` | no |
| <a name="input_lambda_throttles_no_data_timeframe"></a> [lambda\_throttles\_no\_data\_timeframe](#input\_lambda\_throttles\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_lambda_throttles_notify_no_data"></a> [lambda\_throttles\_notify\_no\_data](#input\_lambda\_throttles\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_lambda_throttles_threshold_critical"></a> [lambda\_throttles\_threshold\_critical](#input\_lambda\_throttles\_threshold\_critical) | Lambda Function Throttles critical threshold | `number` | `5000` | no |
| <a name="input_lambda_throttles_threshold_warning"></a> [lambda\_throttles\_threshold\_warning](#input\_lambda\_throttles\_threshold\_warning) | Lambda Function Throttles warning threshold | `number` | `4000` | no |
| <a name="input_lambda_throttles_timeframe"></a> [lambda\_throttles\_timeframe](#input\_lambda\_throttles\_timeframe) | Monitor timeframe for Lambda Function Throttles [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_lambda_x"></a> [lambda\_x](#input\_lambda\_x) | Values of X-axis | `list(number)` | <pre>[<br>  14,<br>  49,<br>  84,<br>  119,<br>  154,<br>  189,<br>  224,<br>  259,<br>  294,<br>  329<br>]</pre> | no |
| <a name="input_lambda_x_axis_intial_value"></a> [lambda\_x\_axis\_intial\_value](#input\_lambda\_x\_axis\_intial\_value) | Intial value of X-axis | `number` | `0` | no |
| <a name="input_lambda_y"></a> [lambda\_y](#input\_lambda\_y) | Values of Y-axis | `list(number)` | <pre>[<br>  9,<br>  32,<br>  55,<br>  78,<br>  101,<br>  124,<br>  147,<br>  170,<br>  193,<br>  216<br>]</pre> | no |
| <a name="input_lambda_y_axis_intial_value"></a> [lambda\_y\_axis\_intial\_value](#input\_lambda\_y\_axis\_intial\_value) | Intial value of Y-axis | `number` | `0` | no |
| <a name="input_message"></a> [message](#input\_message) | Message sent when a monitor is triggered | `any` | n/a | yes |
| <a name="input_new_host_delay"></a> [new\_host\_delay](#input\_new\_host\_delay) | Delay in seconds before monitor new resource | `number` | `300` | no |
| <a name="input_prefix_slug"></a> [prefix\_slug](#input\_prefix\_slug) | Prefix string to prepend between brackets on every monitors names | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_lambda_duration_id"></a> [lambda\_duration\_id](#output\_lambda\_duration\_id) | id for monitor lambda Duration |
| <a name="output_lambda_errors_id"></a> [lambda\_errors\_id](#output\_lambda\_errors\_id) | id for monitor lambda function errors |
| <a name="output_lambda_invocations_id"></a> [lambda\_invocations\_id](#output\_lambda\_invocations\_id) | id for monitor lambda function invocations |
| <a name="output_lambda_iterator_age_id"></a> [lambda\_iterator\_age\_id](#output\_lambda\_iterator\_age\_id) | id for monitor lambda function iterator age |
| <a name="output_lambda_throttles_id"></a> [lambda\_throttles\_id](#output\_lambda\_throttles\_id) | id for monitor lambda functions throttles |
