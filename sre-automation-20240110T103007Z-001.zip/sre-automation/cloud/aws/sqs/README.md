## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | ~> 0.13.6 |
| <a name="requirement_datadog"></a> [datadog](#requirement\_datadog) | ~> 3.7.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_datadog"></a> [datadog](#provider\_datadog) | ~> 3.7.0 |
| <a name="provider_template"></a> [template](#provider\_template) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_filter-tags"></a> [filter-tags](#module\_filter-tags) | ../../../common/filter-tags |  |
| <a name="module_filter-tags-with-az"></a> [filter-tags-with-az](#module\_filter-tags-with-az) | ../../../common/filter-tags |  |

## Resources

| Name | Type |
|------|------|
| [datadog_dashboard_json.dashboard_sqs](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/dashboard_json) | resource |
| [datadog_monitor.SQS_delayed_messages_count](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.SQS_oldest_messages_age](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.SQS_recieved_messages_count](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.SQS_sent_messages_count](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [template_file.sqs_dashboard](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |
| [template_file.sqs_widgets](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_environment"></a> [environment](#input\_environment) | Architecture environment | `string` | n/a | yes |
| <a name="input_evaluation_delay"></a> [evaluation\_delay](#input\_evaluation\_delay) | Delay in seconds for the metric evaluation | `number` | `900` | no |
| <a name="input_filter_tags_custom"></a> [filter\_tags\_custom](#input\_filter\_tags\_custom) | Tags used for custom filtering when filter\_tags\_use\_defaults is false | `string` | `"*"` | no |
| <a name="input_filter_tags_custom_excluded"></a> [filter\_tags\_custom\_excluded](#input\_filter\_tags\_custom\_excluded) | Tags excluded for custom filtering when filter\_tags\_use\_defaults is false | `string` | `""` | no |
| <a name="input_filter_tags_use_defaults"></a> [filter\_tags\_use\_defaults](#input\_filter\_tags\_use\_defaults) | Use default filter tags convention | `string` | `"true"` | no |
| <a name="input_message"></a> [message](#input\_message) | Message sent when a monitor is triggered | `any` | n/a | yes |
| <a name="input_new_host_delay"></a> [new\_host\_delay](#input\_new\_host\_delay) | Delay in seconds before monitor new resource | `number` | `300` | no |
| <a name="input_notify_no_data"></a> [notify\_no\_data](#input\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_prefix_slug"></a> [prefix\_slug](#input\_prefix\_slug) | Prefix string to prepend between brackets on every monitors names | `string` | `""` | no |
| <a name="input_sqs_dashboard_tags"></a> [sqs\_dashboard\_tags](#input\_sqs\_dashboard\_tags) | Dashboard Tags | `list(string)` | `[]` | no |
| <a name="input_sqs_delayed_messages_count_aggregator"></a> [sqs\_delayed\_messages\_count\_aggregator](#input\_sqs\_delayed\_messages\_count\_aggregator) | Monitor aggregator for SQS Delayed Messages Count [available values: min, max or avg] | `string` | `"sum"` | no |
| <a name="input_sqs_delayed_messages_count_enabled"></a> [sqs\_delayed\_messages\_count\_enabled](#input\_sqs\_delayed\_messages\_count\_enabled) | Flag to enable SQS Delayed Messages Count monitor | `string` | `"true"` | no |
| <a name="input_sqs_delayed_messages_count_extra_tags"></a> [sqs\_delayed\_messages\_count\_extra\_tags](#input\_sqs\_delayed\_messages\_count\_extra\_tags) | Extra tags for SQS Delayed Messages Count monitor | `list(string)` | `[]` | no |
| <a name="input_sqs_delayed_messages_count_message"></a> [sqs\_delayed\_messages\_count\_message](#input\_sqs\_delayed\_messages\_count\_message) | Custom message for SQS Delayed Messages Count | `string` | `""` | no |
| <a name="input_sqs_delayed_messages_count_no_data_timeframe"></a> [sqs\_delayed\_messages\_count\_no\_data\_timeframe](#input\_sqs\_delayed\_messages\_count\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_sqs_delayed_messages_count_threshold_critical"></a> [sqs\_delayed\_messages\_count\_threshold\_critical](#input\_sqs\_delayed\_messages\_count\_threshold\_critical) | SQS Delayed Messages Count critical threshold | `number` | `28800` | no |
| <a name="input_sqs_delayed_messages_count_threshold_warning"></a> [sqs\_delayed\_messages\_count\_threshold\_warning](#input\_sqs\_delayed\_messages\_count\_threshold\_warning) | SQS Delayed Messages Count warning threshold | `number` | `25200` | no |
| <a name="input_sqs_delayed_messages_count_timeframe"></a> [sqs\_delayed\_messages\_count\_timeframe](#input\_sqs\_delayed\_messages\_count\_timeframe) | Monitor timeframe for SQS Delayed Messages Count [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_sqs_metrics_panel_height"></a> [sqs\_metrics\_panel\_height](#input\_sqs\_metrics\_panel\_height) | Height of the panel | `number` | `21` | no |
| <a name="input_sqs_metrics_panel_width"></a> [sqs\_metrics\_panel\_width](#input\_sqs\_metrics\_panel\_width) | Width of the panel | `number` | `33` | no |
| <a name="input_sqs_monitor_tags"></a> [sqs\_monitor\_tags](#input\_sqs\_monitor\_tags) | Monitor Tags | `list(string)` | `[]` | no |
| <a name="input_sqs_oldest_messages_age_aggregator"></a> [sqs\_oldest\_messages\_age\_aggregator](#input\_sqs\_oldest\_messages\_age\_aggregator) | Monitor aggregator for SQS Oldest Messages Age [available values: min, max or avg] | `string` | `"sum"` | no |
| <a name="input_sqs_oldest_messages_age_enabled"></a> [sqs\_oldest\_messages\_age\_enabled](#input\_sqs\_oldest\_messages\_age\_enabled) | Flag to enable SQS Oldest Messages Age monitor | `string` | `"true"` | no |
| <a name="input_sqs_oldest_messages_age_extra_tags"></a> [sqs\_oldest\_messages\_age\_extra\_tags](#input\_sqs\_oldest\_messages\_age\_extra\_tags) | Extra tags for SQS Oldest Messages Age monitor | `list(string)` | `[]` | no |
| <a name="input_sqs_oldest_messages_age_message"></a> [sqs\_oldest\_messages\_age\_message](#input\_sqs\_oldest\_messages\_age\_message) | Custom message for SQS Oldest Messages Age | `string` | `""` | no |
| <a name="input_sqs_oldest_messages_age_no_data_timeframe"></a> [sqs\_oldest\_messages\_age\_no\_data\_timeframe](#input\_sqs\_oldest\_messages\_age\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_sqs_oldest_messages_age_threshold_critical"></a> [sqs\_oldest\_messages\_age\_threshold\_critical](#input\_sqs\_oldest\_messages\_age\_threshold\_critical) | SQS Oldest Messages Age critical threshold | `number` | `28800` | no |
| <a name="input_sqs_oldest_messages_age_threshold_warning"></a> [sqs\_oldest\_messages\_age\_threshold\_warning](#input\_sqs\_oldest\_messages\_age\_threshold\_warning) | SQS Oldest Messages Age warning threshold | `number` | `25200` | no |
| <a name="input_sqs_oldest_messages_age_timeframe"></a> [sqs\_oldest\_messages\_age\_timeframe](#input\_sqs\_oldest\_messages\_age\_timeframe) | Monitor timeframe for SQS Oldest Messages Age [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_sqs_recieved_messages_count_aggregator"></a> [sqs\_recieved\_messages\_count\_aggregator](#input\_sqs\_recieved\_messages\_count\_aggregator) | Monitor aggregator for SQS recieved Messages Count [available values: min, max or avg] | `string` | `"sum"` | no |
| <a name="input_sqs_recieved_messages_count_enabled"></a> [sqs\_recieved\_messages\_count\_enabled](#input\_sqs\_recieved\_messages\_count\_enabled) | Flag to enable SQS recieved Messages Count monitor | `string` | `"true"` | no |
| <a name="input_sqs_recieved_messages_count_extra_tags"></a> [sqs\_recieved\_messages\_count\_extra\_tags](#input\_sqs\_recieved\_messages\_count\_extra\_tags) | Extra tags for SQS recieved Messages Count monitor | `list(string)` | `[]` | no |
| <a name="input_sqs_recieved_messages_count_message"></a> [sqs\_recieved\_messages\_count\_message](#input\_sqs\_recieved\_messages\_count\_message) | Custom message for SQS recieved Messages Count | `string` | `""` | no |
| <a name="input_sqs_recieved_messages_count_no_data_timeframe"></a> [sqs\_recieved\_messages\_count\_no\_data\_timeframe](#input\_sqs\_recieved\_messages\_count\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_sqs_recieved_messages_count_threshold_critical"></a> [sqs\_recieved\_messages\_count\_threshold\_critical](#input\_sqs\_recieved\_messages\_count\_threshold\_critical) | SQS recieved Messages Count critical threshold | `number` | `28800` | no |
| <a name="input_sqs_recieved_messages_count_threshold_warning"></a> [sqs\_recieved\_messages\_count\_threshold\_warning](#input\_sqs\_recieved\_messages\_count\_threshold\_warning) | SQS recieved Messages Count warning threshold | `number` | `25200` | no |
| <a name="input_sqs_recieved_messages_count_timeframe"></a> [sqs\_recieved\_messages\_count\_timeframe](#input\_sqs\_recieved\_messages\_count\_timeframe) | Monitor timeframe for SQS recieved Messages Count [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_sqs_resource_panel_height"></a> [sqs\_resource\_panel\_height](#input\_sqs\_resource\_panel\_height) | Height of the panel | `number` | `7` | no |
| <a name="input_sqs_resource_panel_width"></a> [sqs\_resource\_panel\_width](#input\_sqs\_resource\_panel\_width) | Width Of the Panel | `number` | `33` | no |
| <a name="input_sqs_sent_messages_count_aggregator"></a> [sqs\_sent\_messages\_count\_aggregator](#input\_sqs\_sent\_messages\_count\_aggregator) | Monitor aggregator for SQS Sent Messages Count [available values: min, max or avg] | `string` | `"sum"` | no |
| <a name="input_sqs_sent_messages_count_enabled"></a> [sqs\_sent\_messages\_count\_enabled](#input\_sqs\_sent\_messages\_count\_enabled) | Flag to enable SQS Sent Messages Count monitor | `string` | `"true"` | no |
| <a name="input_sqs_sent_messages_count_extra_tags"></a> [sqs\_sent\_messages\_count\_extra\_tags](#input\_sqs\_sent\_messages\_count\_extra\_tags) | Extra tags for SQS Sent Messages Count monitor | `list(string)` | `[]` | no |
| <a name="input_sqs_sent_messages_count_message"></a> [sqs\_sent\_messages\_count\_message](#input\_sqs\_sent\_messages\_count\_message) | Custom message for SQS Sent Messages Count | `string` | `""` | no |
| <a name="input_sqs_sent_messages_count_no_data_timeframe"></a> [sqs\_sent\_messages\_count\_no\_data\_timeframe](#input\_sqs\_sent\_messages\_count\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_sqs_sent_messages_count_threshold_critical"></a> [sqs\_sent\_messages\_count\_threshold\_critical](#input\_sqs\_sent\_messages\_count\_threshold\_critical) | SQS Sent Messages Count critical threshold | `number` | `28800` | no |
| <a name="input_sqs_sent_messages_count_threshold_warning"></a> [sqs\_sent\_messages\_count\_threshold\_warning](#input\_sqs\_sent\_messages\_count\_threshold\_warning) | SQS Sent Messages Count warning threshold | `number` | `25200` | no |
| <a name="input_sqs_sent_messages_count_timeframe"></a> [sqs\_sent\_messages\_count\_timeframe](#input\_sqs\_sent\_messages\_count\_timeframe) | Monitor timeframe for SQS Sent Messages Count [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_sqs_x"></a> [sqs\_x](#input\_sqs\_x) | Values of X-axis | `list(number)` | <pre>[<br>  14,<br>  49,<br>  84,<br>  119,<br>  154,<br>  189,<br>  224,<br>  259,<br>  294,<br>  329<br>]</pre> | no |
| <a name="input_sqs_x_axis_intial_value"></a> [sqs\_x\_axis\_intial\_value](#input\_sqs\_x\_axis\_intial\_value) | Intial value of X-axis | `number` | `0` | no |
| <a name="input_sqs_y"></a> [sqs\_y](#input\_sqs\_y) | Values of Y-axis | `list(number)` | <pre>[<br>  9,<br>  32,<br>  55,<br>  78,<br>  101,<br>  124,<br>  147,<br>  170,<br>  193,<br>  216<br>]</pre> | no |
| <a name="input_sqs_y_axis_intial_value"></a> [sqs\_y\_axis\_intial\_value](#input\_sqs\_y\_axis\_intial\_value) | Intial value of Y-axis | `number` | `0` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_SQS_delayed_messages_count_id"></a> [SQS\_delayed\_messages\_count\_id](#output\_SQS\_delayed\_messages\_count\_id) | id for monitor SQS Delayed Messages Count |
| <a name="output_SQS_oldest_messages_age_id"></a> [SQS\_oldest\_messages\_age\_id](#output\_SQS\_oldest\_messages\_age\_id) | id for monitor SQS Age Of Oldest Messages |
| <a name="output_SQS_recieved_messages_count_id"></a> [SQS\_recieved\_messages\_count\_id](#output\_SQS\_recieved\_messages\_count\_id) | id for monitor SQS Recieved Messages Count |
| <a name="output_SQS_sent_messages_count_id"></a> [SQS\_sent\_messages\_count\_id](#output\_SQS\_sent\_messages\_count\_id) | id for monitor SQS Sent Messages Count |
