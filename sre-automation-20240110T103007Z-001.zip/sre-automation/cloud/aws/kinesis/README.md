## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | ~> 0.13.6 |
| <a name="requirement_datadog"></a> [datadog](#requirement\_datadog) | ~> 3.7.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_datadog"></a> [datadog](#provider\_datadog) | ~> 3.7.0 |
| <a name="provider_template"></a> [template](#provider\_template) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_filter-tags"></a> [filter-tags](#module\_filter-tags) | ../../../common/filter-tags |  |

## Resources

| Name | Type |
|------|------|
| [datadog_dashboard_json.dashboard_kinesis](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/dashboard_json) | resource |
| [datadog_monitor.kinesis_get_record_latency](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.kinesis_incoming_records](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.kinesis_iterator_age](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.kinesis_outgoing_records](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.kinesis_put_record_latency](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.kinesis_read_provisioned_throughput](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.kinesis_write_provisioned_throughput](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [template_file.kinesis_dashboard](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |
| [template_file.kinesis_widgets](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_environment"></a> [environment](#input\_environment) | Architecture environment | `string` | n/a | yes |
| <a name="input_evaluation_delay"></a> [evaluation\_delay](#input\_evaluation\_delay) | Delay in seconds for the metric evaluation | `number` | `900` | no |
| <a name="input_filter_tags_custom"></a> [filter\_tags\_custom](#input\_filter\_tags\_custom) | Tags used for custom filtering when filter\_tags\_use\_defaults is false | `string` | `"*"` | no |
| <a name="input_filter_tags_custom_excluded"></a> [filter\_tags\_custom\_excluded](#input\_filter\_tags\_custom\_excluded) | Tags excluded for custom filtering when filter\_tags\_use\_defaults is false | `string` | `""` | no |
| <a name="input_filter_tags_use_defaults"></a> [filter\_tags\_use\_defaults](#input\_filter\_tags\_use\_defaults) | Use default filter tags convention | `string` | `"true"` | no |
| <a name="input_kinesis_dashboard_tags"></a> [kinesis\_dashboard\_tags](#input\_kinesis\_dashboard\_tags) | Dashboard Tags | `list(string)` | `[]` | no |
| <a name="input_kinesis_get_record_latency_aggregator"></a> [kinesis\_get\_record\_latency\_aggregator](#input\_kinesis\_get\_record\_latency\_aggregator) | Monitor aggregator for Kinesis get Record Latency [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_kinesis_get_record_latency_enabled"></a> [kinesis\_get\_record\_latency\_enabled](#input\_kinesis\_get\_record\_latency\_enabled) | Flag to enable Kinesis get Record Latency monitor | `string` | `"true"` | no |
| <a name="input_kinesis_get_record_latency_extra_tags"></a> [kinesis\_get\_record\_latency\_extra\_tags](#input\_kinesis\_get\_record\_latency\_extra\_tags) | Extra tags for Kinesis get Record Latency monitor | `list(string)` | `[]` | no |
| <a name="input_kinesis_get_record_latency_message"></a> [kinesis\_get\_record\_latency\_message](#input\_kinesis\_get\_record\_latency\_message) | Custom message for Kinesis get Record Latency | `string` | `""` | no |
| <a name="input_kinesis_get_record_latency_no_data_timeframe"></a> [kinesis\_get\_record\_latency\_no\_data\_timeframe](#input\_kinesis\_get\_record\_latency\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_kinesis_get_record_latency_notify_no_data"></a> [kinesis\_get\_record\_latency\_notify\_no\_data](#input\_kinesis\_get\_record\_latency\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_kinesis_get_record_latency_threshold_critical"></a> [kinesis\_get\_record\_latency\_threshold\_critical](#input\_kinesis\_get\_record\_latency\_threshold\_critical) | Kinesis get Record Latency critical threshold | `number` | `25` | no |
| <a name="input_kinesis_get_record_latency_threshold_warning"></a> [kinesis\_get\_record\_latency\_threshold\_warning](#input\_kinesis\_get\_record\_latency\_threshold\_warning) | Kinesis get Record Latency warning threshold | `number` | `20` | no |
| <a name="input_kinesis_get_record_latency_timeframe"></a> [kinesis\_get\_record\_latency\_timeframe](#input\_kinesis\_get\_record\_latency\_timeframe) | Monitor timeframe for Kinesis get Record Latency [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_kinesis_incoming_records_aggregator"></a> [kinesis\_incoming\_records\_aggregator](#input\_kinesis\_incoming\_records\_aggregator) | Monitor aggregator for Kinesis Incoming Rrecords [available values: min, max or avg] | `string` | `"sum"` | no |
| <a name="input_kinesis_incoming_records_enabled"></a> [kinesis\_incoming\_records\_enabled](#input\_kinesis\_incoming\_records\_enabled) | Flag to enable Kinesis Incoming Rrecords monitor | `string` | `"true"` | no |
| <a name="input_kinesis_incoming_records_extra_tags"></a> [kinesis\_incoming\_records\_extra\_tags](#input\_kinesis\_incoming\_records\_extra\_tags) | Extra tags for Kinesis Incoming Rrecords monitor | `list(string)` | `[]` | no |
| <a name="input_kinesis_incoming_records_message"></a> [kinesis\_incoming\_records\_message](#input\_kinesis\_incoming\_records\_message) | Custom message for Kinesis Incoming Rrecords | `string` | `""` | no |
| <a name="input_kinesis_incoming_records_no_data_timeframe"></a> [kinesis\_incoming\_records\_no\_data\_timeframe](#input\_kinesis\_incoming\_records\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_kinesis_incoming_records_notify_no_data"></a> [kinesis\_incoming\_records\_notify\_no\_data](#input\_kinesis\_incoming\_records\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_kinesis_incoming_records_threshold_critical"></a> [kinesis\_incoming\_records\_threshold\_critical](#input\_kinesis\_incoming\_records\_threshold\_critical) | Kinesis Incoming Rrecords critical threshold | `number` | `50000` | no |
| <a name="input_kinesis_incoming_records_threshold_warning"></a> [kinesis\_incoming\_records\_threshold\_warning](#input\_kinesis\_incoming\_records\_threshold\_warning) | Kinesis Incoming Rrecords warning threshold | `number` | `45000` | no |
| <a name="input_kinesis_incoming_records_timeframe"></a> [kinesis\_incoming\_records\_timeframe](#input\_kinesis\_incoming\_records\_timeframe) | Monitor timeframe for Kinesis Incoming Rrecords [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_kinesis_iterator_age_aggregator"></a> [kinesis\_iterator\_age\_aggregator](#input\_kinesis\_iterator\_age\_aggregator) | Monitor aggregator for Kinesis Iterator Age [available values: min, max or avg] | `string` | `"sum"` | no |
| <a name="input_kinesis_iterator_age_enabled"></a> [kinesis\_iterator\_age\_enabled](#input\_kinesis\_iterator\_age\_enabled) | Flag to enable Kinesis Iterator Age monitor | `string` | `"true"` | no |
| <a name="input_kinesis_iterator_age_extra_tags"></a> [kinesis\_iterator\_age\_extra\_tags](#input\_kinesis\_iterator\_age\_extra\_tags) | Extra tags for Kinesis Iterator Age monitor | `list(string)` | `[]` | no |
| <a name="input_kinesis_iterator_age_message"></a> [kinesis\_iterator\_age\_message](#input\_kinesis\_iterator\_age\_message) | Custom message for Kinesis Iterator Age | `string` | `""` | no |
| <a name="input_kinesis_iterator_age_no_data_timeframe"></a> [kinesis\_iterator\_age\_no\_data\_timeframe](#input\_kinesis\_iterator\_age\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_kinesis_iterator_age_notify_no_data"></a> [kinesis\_iterator\_age\_notify\_no\_data](#input\_kinesis\_iterator\_age\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_kinesis_iterator_age_threshold_critical"></a> [kinesis\_iterator\_age\_threshold\_critical](#input\_kinesis\_iterator\_age\_threshold\_critical) | Kinesis Iterator Age critical threshold | `number` | `60` | no |
| <a name="input_kinesis_iterator_age_threshold_warning"></a> [kinesis\_iterator\_age\_threshold\_warning](#input\_kinesis\_iterator\_age\_threshold\_warning) | Kinesis Iterator Age warning threshold | `number` | `50` | no |
| <a name="input_kinesis_iterator_age_timeframe"></a> [kinesis\_iterator\_age\_timeframe](#input\_kinesis\_iterator\_age\_timeframe) | Monitor timeframe for Kinesis Iterator Age [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_kinesis_metrics_panel_height"></a> [kinesis\_metrics\_panel\_height](#input\_kinesis\_metrics\_panel\_height) | Height of the panel | `number` | `21` | no |
| <a name="input_kinesis_metrics_panel_width"></a> [kinesis\_metrics\_panel\_width](#input\_kinesis\_metrics\_panel\_width) | Width of the panel | `number` | `33` | no |
| <a name="input_kinesis_monitor_tags"></a> [kinesis\_monitor\_tags](#input\_kinesis\_monitor\_tags) | Monitor Tags | `list(string)` | `[]` | no |
| <a name="input_kinesis_outgoing_records_aggregator"></a> [kinesis\_outgoing\_records\_aggregator](#input\_kinesis\_outgoing\_records\_aggregator) | Monitor aggregator for Kinesis Outgoing Rrecords [available values: min, max or avg] | `string` | `"sum"` | no |
| <a name="input_kinesis_outgoing_records_enabled"></a> [kinesis\_outgoing\_records\_enabled](#input\_kinesis\_outgoing\_records\_enabled) | Flag to enable Kinesis Outgoing Rrecords monitor | `string` | `"true"` | no |
| <a name="input_kinesis_outgoing_records_extra_tags"></a> [kinesis\_outgoing\_records\_extra\_tags](#input\_kinesis\_outgoing\_records\_extra\_tags) | Extra tags for Kinesis Outgoing Rrecords monitor | `list(string)` | `[]` | no |
| <a name="input_kinesis_outgoing_records_message"></a> [kinesis\_outgoing\_records\_message](#input\_kinesis\_outgoing\_records\_message) | Custom message for Kinesis Outgoing Rrecords | `string` | `""` | no |
| <a name="input_kinesis_outgoing_records_no_data_timeframe"></a> [kinesis\_outgoing\_records\_no\_data\_timeframe](#input\_kinesis\_outgoing\_records\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_kinesis_outgoing_records_notify_no_data"></a> [kinesis\_outgoing\_records\_notify\_no\_data](#input\_kinesis\_outgoing\_records\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_kinesis_outgoing_records_threshold_critical"></a> [kinesis\_outgoing\_records\_threshold\_critical](#input\_kinesis\_outgoing\_records\_threshold\_critical) | Kinesis Outgoing Rrecords critical threshold | `number` | `50000` | no |
| <a name="input_kinesis_outgoing_records_threshold_warning"></a> [kinesis\_outgoing\_records\_threshold\_warning](#input\_kinesis\_outgoing\_records\_threshold\_warning) | Kinesis Outgoing Rrecords warning threshold | `number` | `45000` | no |
| <a name="input_kinesis_outgoing_records_timeframe"></a> [kinesis\_outgoing\_records\_timeframe](#input\_kinesis\_outgoing\_records\_timeframe) | Monitor timeframe for Kinesis Outgoing Rrecords [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_kinesis_put_record_latency_aggregator"></a> [kinesis\_put\_record\_latency\_aggregator](#input\_kinesis\_put\_record\_latency\_aggregator) | Monitor aggregator for Kinesis Put Record Latency [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_kinesis_put_record_latency_enabled"></a> [kinesis\_put\_record\_latency\_enabled](#input\_kinesis\_put\_record\_latency\_enabled) | Flag to enable Kinesis Put Record Latency monitor | `string` | `"true"` | no |
| <a name="input_kinesis_put_record_latency_extra_tags"></a> [kinesis\_put\_record\_latency\_extra\_tags](#input\_kinesis\_put\_record\_latency\_extra\_tags) | Extra tags for Kinesis Put Record Latency monitor | `list(string)` | `[]` | no |
| <a name="input_kinesis_put_record_latency_message"></a> [kinesis\_put\_record\_latency\_message](#input\_kinesis\_put\_record\_latency\_message) | Custom message for Kinesis Put Record Latency | `string` | `""` | no |
| <a name="input_kinesis_put_record_latency_no_data_timeframe"></a> [kinesis\_put\_record\_latency\_no\_data\_timeframe](#input\_kinesis\_put\_record\_latency\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_kinesis_put_record_latency_notify_no_data"></a> [kinesis\_put\_record\_latency\_notify\_no\_data](#input\_kinesis\_put\_record\_latency\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_kinesis_put_record_latency_threshold_critical"></a> [kinesis\_put\_record\_latency\_threshold\_critical](#input\_kinesis\_put\_record\_latency\_threshold\_critical) | Kinesis Put Record Latency critical threshold | `number` | `25` | no |
| <a name="input_kinesis_put_record_latency_threshold_warning"></a> [kinesis\_put\_record\_latency\_threshold\_warning](#input\_kinesis\_put\_record\_latency\_threshold\_warning) | Kinesis Put Record Latency warning threshold | `number` | `20` | no |
| <a name="input_kinesis_put_record_latency_timeframe"></a> [kinesis\_put\_record\_latency\_timeframe](#input\_kinesis\_put\_record\_latency\_timeframe) | Monitor timeframe for Kinesis Put Record Latency [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_kinesis_read_provisioned_throughput_aggregator"></a> [kinesis\_read\_provisioned\_throughput\_aggregator](#input\_kinesis\_read\_provisioned\_throughput\_aggregator) | Monitor aggregator for Kinesis Read Provisioned Throughput Rrecords [available values: min, max or avg] | `string` | `"sum"` | no |
| <a name="input_kinesis_read_provisioned_throughput_enabled"></a> [kinesis\_read\_provisioned\_throughput\_enabled](#input\_kinesis\_read\_provisioned\_throughput\_enabled) | Flag to enable Kinesis Read Provisioned Throughput Rrecords monitor | `string` | `"true"` | no |
| <a name="input_kinesis_read_provisioned_throughput_extra_tags"></a> [kinesis\_read\_provisioned\_throughput\_extra\_tags](#input\_kinesis\_read\_provisioned\_throughput\_extra\_tags) | Extra tags for Kinesis Read Provisioned Throughput Rrecords monitor | `list(string)` | `[]` | no |
| <a name="input_kinesis_read_provisioned_throughput_message"></a> [kinesis\_read\_provisioned\_throughput\_message](#input\_kinesis\_read\_provisioned\_throughput\_message) | Custom message for Kinesis Read Provisioned Throughput Rrecords | `string` | `""` | no |
| <a name="input_kinesis_read_provisioned_throughput_no_data_timeframe"></a> [kinesis\_read\_provisioned\_throughput\_no\_data\_timeframe](#input\_kinesis\_read\_provisioned\_throughput\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_kinesis_read_provisioned_throughput_notify_no_data"></a> [kinesis\_read\_provisioned\_throughput\_notify\_no\_data](#input\_kinesis\_read\_provisioned\_throughput\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_kinesis_read_provisioned_throughput_threshold_critical"></a> [kinesis\_read\_provisioned\_throughput\_threshold\_critical](#input\_kinesis\_read\_provisioned\_throughput\_threshold\_critical) | Kinesis Read Provisioned Throughput Rrecords critical threshold | `number` | `50000` | no |
| <a name="input_kinesis_read_provisioned_throughput_threshold_warning"></a> [kinesis\_read\_provisioned\_throughput\_threshold\_warning](#input\_kinesis\_read\_provisioned\_throughput\_threshold\_warning) | Kinesis Read Provisioned Throughput Rrecords warning threshold | `number` | `45000` | no |
| <a name="input_kinesis_read_provisioned_throughput_timeframe"></a> [kinesis\_read\_provisioned\_throughput\_timeframe](#input\_kinesis\_read\_provisioned\_throughput\_timeframe) | Monitor timeframe for Kinesis Read Provisioned Throughput Rrecords [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_kinesis_resource_panel_height"></a> [kinesis\_resource\_panel\_height](#input\_kinesis\_resource\_panel\_height) | Height of the panel | `number` | `7` | no |
| <a name="input_kinesis_resource_panel_width"></a> [kinesis\_resource\_panel\_width](#input\_kinesis\_resource\_panel\_width) | Width Of the Panel | `number` | `33` | no |
| <a name="input_kinesis_write_provisioned_throughput_aggregator"></a> [kinesis\_write\_provisioned\_throughput\_aggregator](#input\_kinesis\_write\_provisioned\_throughput\_aggregator) | Monitor aggregator for Kinesis Write Provisioned Throughput Rrecords [available values: min, max or avg] | `string` | `"sum"` | no |
| <a name="input_kinesis_write_provisioned_throughput_enabled"></a> [kinesis\_write\_provisioned\_throughput\_enabled](#input\_kinesis\_write\_provisioned\_throughput\_enabled) | Flag to enable Kinesis Write Provisioned Throughput Rrecords monitor | `string` | `"true"` | no |
| <a name="input_kinesis_write_provisioned_throughput_extra_tags"></a> [kinesis\_write\_provisioned\_throughput\_extra\_tags](#input\_kinesis\_write\_provisioned\_throughput\_extra\_tags) | Extra tags for Kinesis Write Provisioned Throughput Rrecords monitor | `list(string)` | `[]` | no |
| <a name="input_kinesis_write_provisioned_throughput_message"></a> [kinesis\_write\_provisioned\_throughput\_message](#input\_kinesis\_write\_provisioned\_throughput\_message) | Custom message for Kinesis Write Provisioned Throughput Rrecords | `string` | `""` | no |
| <a name="input_kinesis_write_provisioned_throughput_no_data_timeframe"></a> [kinesis\_write\_provisioned\_throughput\_no\_data\_timeframe](#input\_kinesis\_write\_provisioned\_throughput\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_kinesis_write_provisioned_throughput_notify_no_data"></a> [kinesis\_write\_provisioned\_throughput\_notify\_no\_data](#input\_kinesis\_write\_provisioned\_throughput\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_kinesis_write_provisioned_throughput_threshold_critical"></a> [kinesis\_write\_provisioned\_throughput\_threshold\_critical](#input\_kinesis\_write\_provisioned\_throughput\_threshold\_critical) | Kinesis Write Provisioned Throughput Rrecords critical threshold | `number` | `50000` | no |
| <a name="input_kinesis_write_provisioned_throughput_threshold_warning"></a> [kinesis\_write\_provisioned\_throughput\_threshold\_warning](#input\_kinesis\_write\_provisioned\_throughput\_threshold\_warning) | Kinesis Write Provisioned Throughput Rrecords warning threshold | `number` | `45000` | no |
| <a name="input_kinesis_write_provisioned_throughput_timeframe"></a> [kinesis\_write\_provisioned\_throughput\_timeframe](#input\_kinesis\_write\_provisioned\_throughput\_timeframe) | Monitor timeframe for Kinesis Write Provisioned Throughput Rrecords [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_kinesis_x"></a> [kinesis\_x](#input\_kinesis\_x) | Values of X-axis | `list(number)` | <pre>[<br>  14,<br>  49,<br>  84,<br>  119,<br>  154,<br>  189,<br>  224,<br>  259,<br>  294,<br>  329<br>]</pre> | no |
| <a name="input_kinesis_x_axis_intial_value"></a> [kinesis\_x\_axis\_intial\_value](#input\_kinesis\_x\_axis\_intial\_value) | Intial value of X-axis | `number` | `0` | no |
| <a name="input_kinesis_y"></a> [kinesis\_y](#input\_kinesis\_y) | Values of Y-axis | `list(number)` | <pre>[<br>  9,<br>  32,<br>  55,<br>  78,<br>  101,<br>  124,<br>  147,<br>  170,<br>  193,<br>  216<br>]</pre> | no |
| <a name="input_kinesis_y_axis_intial_value"></a> [kinesis\_y\_axis\_intial\_value](#input\_kinesis\_y\_axis\_intial\_value) | Intial value of Y-axis | `number` | `0` | no |
| <a name="input_message"></a> [message](#input\_message) | Message sent when a monitor is triggered | `any` | n/a | yes |
| <a name="input_new_host_delay"></a> [new\_host\_delay](#input\_new\_host\_delay) | Delay in seconds before monitor new resource | `number` | `300` | no |
| <a name="input_prefix_slug"></a> [prefix\_slug](#input\_prefix\_slug) | Prefix string to prepend between brackets on every monitors names | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_kinesis_get_record_latency_id"></a> [kinesis\_get\_record\_latency\_id](#output\_kinesis\_get\_record\_latency\_id) | id for monitor kinesis stream get record latency |
| <a name="output_kinesis_incoming_records_id"></a> [kinesis\_incoming\_records\_id](#output\_kinesis\_incoming\_records\_id) | id for monitor kinesis stream incoming records |
| <a name="output_kinesis_iterator_age_id"></a> [kinesis\_iterator\_age\_id](#output\_kinesis\_iterator\_age\_id) | id for monitor kinesis stream iterator age |
| <a name="output_kinesis_outgoing_records_id"></a> [kinesis\_outgoing\_records\_id](#output\_kinesis\_outgoing\_records\_id) | id for monitor kinesis stream outgoing records |
| <a name="output_kinesis_put_record_latency_id"></a> [kinesis\_put\_record\_latency\_id](#output\_kinesis\_put\_record\_latency\_id) | id for monitor kinesis stream put record latency |
| <a name="output_kinesis_read_provisioned_throughput_id"></a> [kinesis\_read\_provisioned\_throughput\_id](#output\_kinesis\_read\_provisioned\_throughput\_id) | id for monitor kinesis stream read provisioned throughput |
| <a name="output_kinesis_write_provisioned_throughput_id"></a> [kinesis\_write\_provisioned\_throughput\_id](#output\_kinesis\_write\_provisioned\_throughput\_id) | id for monitor kinesis stream write provisioned throughput |
