# CLOUD AWS ALB DataDog monitors

## How to use this module

```hcl
module "datadog-monitors-cloud-aws-alb" {
  source      = "../../cloud/aws/alb"
  version     = "{revision}"

  environment = var.environment
  message     = module.datadog-message-alerting.alerting-message
}

```

## Purpose

Creates DataDog monitors with the following checks:

- ALB healthy instances
- ALB HTTP code 4xx
- ALB HTTP code 5xx
- ALB latency
- ALB target HTTP code 4xx
- ALB target HTTP code 5xx

## Requirements

| Name | Version |
|------|---------|
| terraform | >= 0.12.26 |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| alb\_no\_healthy\_instances\_enabled | Flag to enable ALB no healthy instances monitor | `string` | `"true"` | no |
| alb\_no\_healthy\_instances\_extra\_tags | Extra tags for ALB no healthy instances monitor | `list(string)` | `[]` | no |
| alb\_no\_healthy\_instances\_message | Custom message for ALB no healthy instances monitor | `string` | `""` | no |
| alb\_no\_healthy\_instances\_no\_data\_timeframe | Number of minutes before reporting no data | `string` | `10` | no |
| alb\_no\_healthy\_instances\_threshold\_warning | ALB no healthy instances warning threshold in percentage | `number` | `100` | no |
| alb\_no\_healthy\_instances\_time\_aggregator | Monitor aggregator for ALB no healthy instances [available values: min, max or avg] | `string` | `"min"` | no |
| alb\_no\_healthy\_instances\_timeframe | Monitor timeframe for ALB no healthy instances [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_5m"` | no |
| artificial\_requests\_count | Number of false requests used to mitigate false positive in case of low trafic | `number` | `5` | no |
| environment | Architecture environment | `string` | n/a | yes |
| evaluation\_delay | Delay in seconds for the metric evaluation | `number` | `900` | no |
| filter\_tags\_custom | Tags used for custom filtering when filter\_tags\_use\_defaults is false | `string` | `"*"` | no |
| filter\_tags\_custom\_excluded | Tags excluded for custom filtering when filter\_tags\_use\_defaults is false | `string` | `""` | no |
| filter\_tags\_use\_defaults | Use default filter tags convention | `string` | `"true"` | no |
| httpcode\_alb\_4xx\_enabled | Flag to enable ALB httpcode 4xx monitor | `string` | `"true"` | no |
| httpcode\_alb\_4xx\_extra\_tags | Extra tags for ALB httpcode 4xx monitor | `list(string)` | `[]` | no |
| httpcode\_alb\_4xx\_message | Custom message for ALB httpcode 4xx monitor | `string` | `""` | no |
| httpcode\_alb\_4xx\_threshold\_critical | loadbalancer 4xx critical threshold in percentage | `number` | `80` | no |
| httpcode\_alb\_4xx\_threshold\_warning | loadbalancer 4xx warning threshold in percentage | `number` | `60` | no |
| httpcode\_alb\_4xx\_time\_aggregator | Monitor aggregator for ALB httpcode 4xx [available values: min, max or avg] | `string` | `"min"` | no |
| httpcode\_alb\_4xx\_timeframe | Monitor timeframe for ALB httpcode 4xx [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_5m"` | no |
| httpcode\_alb\_5xx\_enabled | Flag to enable ALB httpcode 5xx monitor | `string` | `"true"` | no |
| httpcode\_alb\_5xx\_extra\_tags | Extra tags for ALB httpcode 5xx monitor | `list(string)` | `[]` | no |
| httpcode\_alb\_5xx\_message | Custom message for ALB httpcode 5xx monitor | `string` | `""` | no |
| httpcode\_alb\_5xx\_threshold\_critical | loadbalancer 5xx critical threshold in percentage | `number` | `80` | no |
| httpcode\_alb\_5xx\_threshold\_warning | loadbalancer 5xx warning threshold in percentage | `number` | `60` | no |
| httpcode\_alb\_5xx\_time\_aggregator | Monitor aggregator for ALB httpcode 5xx [available values: min, max or avg] | `string` | `"min"` | no |
| httpcode\_alb\_5xx\_timeframe | Monitor timeframe for ALB httpcode 5xx [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_5m"` | no |
| httpcode\_target\_4xx\_enabled | Flag to enable ALB target httpcode 4xx monitor | `string` | `"true"` | no |
| httpcode\_target\_4xx\_extra\_tags | Extra tags for ALB target httpcode 4xx monitor | `list(string)` | `[]` | no |
| httpcode\_target\_4xx\_message | Custom message for ALB target httpcode 4xx monitor | `string` | `""` | no |
| httpcode\_target\_4xx\_threshold\_critical | target 4xx critical threshold in percentage | `number` | `80` | no |
| httpcode\_target\_4xx\_threshold\_warning | target 4xx warning threshold in percentage | `number` | `60` | no |
| httpcode\_target\_4xx\_time\_aggregator | Monitor aggregator for ALB target httpcode 4xx [available values: min, max or avg] | `string` | `"min"` | no |
| httpcode\_target\_4xx\_timeframe | Monitor timeframe for ALB target httpcode 4xx [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_5m"` | no |
| httpcode\_target\_5xx\_enabled | Flag to enable ALB target httpcode 5xx monitor | `string` | `"true"` | no |
| httpcode\_target\_5xx\_extra\_tags | Extra tags for ALB target httpcode 5xx monitor | `list(string)` | `[]` | no |
| httpcode\_target\_5xx\_message | Custom message for ALB target httpcode 5xx monitor | `string` | `""` | no |
| httpcode\_target\_5xx\_threshold\_critical | target 5xx critical threshold in percentage | `number` | `80` | no |
| httpcode\_target\_5xx\_threshold\_warning | target 5xx warning threshold in percentage | `number` | `60` | no |
| httpcode\_target\_5xx\_time\_aggregator | Monitor aggregator for ALB target httpcode 5xx [available values: min, max or avg] | `string` | `"min"` | no |
| httpcode\_target\_5xx\_timeframe | Monitor timeframe for ALB target httpcode 5xx [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_5m"` | no |
| latency\_enabled | Flag to enable ALB latency monitor | `string` | `"true"` | no |
| latency\_extra\_tags | Extra tags for ALB latency monitor | `list(string)` | `[]` | no |
| latency\_message | Custom message for ALB latency monitor | `string` | `""` | no |
| latency\_threshold\_critical | latency critical threshold in seconds | `number` | `3` | no |
| latency\_threshold\_warning | latency warning threshold in seconds | `number` | `1` | no |
| latency\_time\_aggregator | Monitor aggregator for ALB latency [available values: min, max or avg] | `string` | `"min"` | no |
| latency\_timeframe | Monitor timeframe for ALB latency [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_5m"` | no |
| message | Message sent when a monitor is triggered | `any` | n/a | yes |
| new\_host\_delay | Delay in seconds before monitor new resource | `number` | `300` | no |
| notify\_no\_data | Will raise no data alert if set to true | `bool` | `true` | no |
| prefix\_slug | Prefix string to prepend between brackets on every monitors names | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| ALB\_httpcode\_4xx\_id | id for monitor ALB\_httpcode\_4xx |
| ALB\_httpcode\_5xx\_id | id for monitor ALB\_httpcode\_5xx |
| ALB\_httpcode\_target\_4xx\_id | id for monitor ALB\_httpcode\_target\_4xx |
| ALB\_httpcode\_target\_5xx\_id | id for monitor ALB\_httpcode\_target\_5xx |
| ALB\_latency\_id | id for monitor ALB\_latency |
| ALB\_no\_healthy\_instances\_id | id for monitor ALB\_no\_healthy\_instances |

## Related documentation

DataDog blog: [https://www.datadoghq.com/blog/monitor-application-load-balancer/](https://www.datadoghq.com/blog/monitor-application-load-balancer/)

AWS ALB metrics documentation: [https://docs.aws.amazon.com/elasticloadbalancing/latest/application/load-balancer-cloudwatch-metrics.html](https://docs.aws.amazon.com/elasticloadbalancing/latest/application/load-balancer-cloudwatch-metrics.html)
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | ~> 0.13.6 |
| <a name="requirement_datadog"></a> [datadog](#requirement\_datadog) | ~> 3.7.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_datadog"></a> [datadog](#provider\_datadog) | ~> 3.7.0 |
| <a name="provider_template"></a> [template](#provider\_template) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_filter-tags"></a> [filter-tags](#module\_filter-tags) | ../../../common/filter-tags |  |

## Resources

| Name | Type |
|------|------|
| [datadog_dashboard_json.dashboard_alb](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/dashboard_json) | resource |
| [datadog_monitor.ALB_httpcode_4xx](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.ALB_httpcode_5xx](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.ALB_httpcode_target_4xx](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.ALB_httpcode_target_5xx](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.ALB_latency](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.ALB_no_healthy_instances](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.ALB_p99_response_time](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.ALB_processed_bytes](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.ALB_request_count](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [template_file.alb_dashboard](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |
| [template_file.alb_widgets](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_alb_dashboard_tags"></a> [alb\_dashboard\_tags](#input\_alb\_dashboard\_tags) | Dashboard Tags | `list(string)` | `[]` | no |
| <a name="input_alb_metrics_panel_height"></a> [alb\_metrics\_panel\_height](#input\_alb\_metrics\_panel\_height) | Height of the panel | `number` | `21` | no |
| <a name="input_alb_metrics_panel_width"></a> [alb\_metrics\_panel\_width](#input\_alb\_metrics\_panel\_width) | Width of the panel | `number` | `33` | no |
| <a name="input_alb_monitor_tags"></a> [alb\_monitor\_tags](#input\_alb\_monitor\_tags) | Monitor Tags | `list(string)` | `[]` | no |
| <a name="input_alb_no_healthy_instances_enabled"></a> [alb\_no\_healthy\_instances\_enabled](#input\_alb\_no\_healthy\_instances\_enabled) | Flag to enable ALB no healthy instances monitor | `string` | `"true"` | no |
| <a name="input_alb_no_healthy_instances_extra_tags"></a> [alb\_no\_healthy\_instances\_extra\_tags](#input\_alb\_no\_healthy\_instances\_extra\_tags) | Extra tags for ALB no healthy instances monitor | `list(string)` | `[]` | no |
| <a name="input_alb_no_healthy_instances_message"></a> [alb\_no\_healthy\_instances\_message](#input\_alb\_no\_healthy\_instances\_message) | Custom message for ALB no healthy instances monitor | `string` | `""` | no |
| <a name="input_alb_no_healthy_instances_no_data_timeframe"></a> [alb\_no\_healthy\_instances\_no\_data\_timeframe](#input\_alb\_no\_healthy\_instances\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_alb_no_healthy_instances_notify_no_data"></a> [alb\_no\_healthy\_instances\_notify\_no\_data](#input\_alb\_no\_healthy\_instances\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_alb_no_healthy_instances_threshold_warning"></a> [alb\_no\_healthy\_instances\_threshold\_warning](#input\_alb\_no\_healthy\_instances\_threshold\_warning) | ALB no healthy instances warning threshold in percentage | `number` | `60` | no |
| <a name="input_alb_no_healthy_instances_time_aggregator"></a> [alb\_no\_healthy\_instances\_time\_aggregator](#input\_alb\_no\_healthy\_instances\_time\_aggregator) | Monitor aggregator for ALB no healthy instances [available values: min, max or avg] | `string` | `"sum"` | no |
| <a name="input_alb_no_healthy_instances_timeframe"></a> [alb\_no\_healthy\_instances\_timeframe](#input\_alb\_no\_healthy\_instances\_timeframe) | Monitor timeframe for ALB no healthy instances [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_alb_p99_response_time_enabled"></a> [alb\_p99\_response\_time\_enabled](#input\_alb\_p99\_response\_time\_enabled) | Flag to enable ALB P99 Response Time monitor | `string` | `"true"` | no |
| <a name="input_alb_p99_response_time_extra_tags"></a> [alb\_p99\_response\_time\_extra\_tags](#input\_alb\_p99\_response\_time\_extra\_tags) | Extra tags for ALB P99 Response Time monitor | `list(string)` | `[]` | no |
| <a name="input_alb_p99_response_time_message"></a> [alb\_p99\_response\_time\_message](#input\_alb\_p99\_response\_time\_message) | Custom message for ALB P99 Response Time | `string` | `""` | no |
| <a name="input_alb_p99_response_time_no_data_timeframe"></a> [alb\_p99\_response\_time\_no\_data\_timeframe](#input\_alb\_p99\_response\_time\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_alb_p99_response_time_notify_no_data"></a> [alb\_p99\_response\_time\_notify\_no\_data](#input\_alb\_p99\_response\_time\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_alb_p99_response_time_threshold_critical"></a> [alb\_p99\_response\_time\_threshold\_critical](#input\_alb\_p99\_response\_time\_threshold\_critical) | ALB P99 Response Time critical threshold in seconds | `number` | `32` | no |
| <a name="input_alb_p99_response_time_threshold_warning"></a> [alb\_p99\_response\_time\_threshold\_warning](#input\_alb\_p99\_response\_time\_threshold\_warning) | ALB P99 Response Time warning threshold in seconds | `number` | `30` | no |
| <a name="input_alb_p99_response_time_time_aggregator"></a> [alb\_p99\_response\_time\_time\_aggregator](#input\_alb\_p99\_response\_time\_time\_aggregator) | Monitor aggregator for ALB P99 Response Time [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_alb_p99_response_time_timeframe"></a> [alb\_p99\_response\_time\_timeframe](#input\_alb\_p99\_response\_time\_timeframe) | Monitor timeframe for ALB P99 Response Time [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_alb_processed_bytes_enabled"></a> [alb\_processed\_bytes\_enabled](#input\_alb\_processed\_bytes\_enabled) | Flag to enable ALB Processed Bytes monitor | `string` | `"true"` | no |
| <a name="input_alb_processed_bytes_extra_tags"></a> [alb\_processed\_bytes\_extra\_tags](#input\_alb\_processed\_bytes\_extra\_tags) | Extra tags for ALB Processed Bytes monitor | `list(string)` | `[]` | no |
| <a name="input_alb_processed_bytes_message"></a> [alb\_processed\_bytes\_message](#input\_alb\_processed\_bytes\_message) | Custom message for ALB Processed Bytes | `string` | `""` | no |
| <a name="input_alb_processed_bytes_no_data_timeframe"></a> [alb\_processed\_bytes\_no\_data\_timeframe](#input\_alb\_processed\_bytes\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_alb_processed_bytes_notify_no_data"></a> [alb\_processed\_bytes\_notify\_no\_data](#input\_alb\_processed\_bytes\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_alb_processed_bytes_threshold_critical"></a> [alb\_processed\_bytes\_threshold\_critical](#input\_alb\_processed\_bytes\_threshold\_critical) | ALB Processed Bytes critical threshold in seconds | `number` | `5` | no |
| <a name="input_alb_processed_bytes_threshold_warning"></a> [alb\_processed\_bytes\_threshold\_warning](#input\_alb\_processed\_bytes\_threshold\_warning) | ALB Processed Bytes warning threshold in seconds | `number` | `3` | no |
| <a name="input_alb_processed_bytes_time_aggregator"></a> [alb\_processed\_bytes\_time\_aggregator](#input\_alb\_processed\_bytes\_time\_aggregator) | Monitor aggregator for ALB Processed Bytes [available values: min, max or avg] | `string` | `"sum"` | no |
| <a name="input_alb_processed_bytes_timeframe"></a> [alb\_processed\_bytes\_timeframe](#input\_alb\_processed\_bytes\_timeframe) | Monitor timeframe for ALB Processed Bytes [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_alb_request_count_enabled"></a> [alb\_request\_count\_enabled](#input\_alb\_request\_count\_enabled) | Flag to enable ALB Request Count monitor | `string` | `"true"` | no |
| <a name="input_alb_request_count_extra_tags"></a> [alb\_request\_count\_extra\_tags](#input\_alb\_request\_count\_extra\_tags) | Extra tags for ALB Request Count monitor | `list(string)` | `[]` | no |
| <a name="input_alb_request_count_message"></a> [alb\_request\_count\_message](#input\_alb\_request\_count\_message) | Custom message for ALB Request Count | `string` | `""` | no |
| <a name="input_alb_request_count_no_data_timeframe"></a> [alb\_request\_count\_no\_data\_timeframe](#input\_alb\_request\_count\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_alb_request_count_notify_no_data"></a> [alb\_request\_count\_notify\_no\_data](#input\_alb\_request\_count\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_alb_request_count_threshold_critical"></a> [alb\_request\_count\_threshold\_critical](#input\_alb\_request\_count\_threshold\_critical) | ALB Request Count critical threshold in seconds | `number` | `100` | no |
| <a name="input_alb_request_count_threshold_warning"></a> [alb\_request\_count\_threshold\_warning](#input\_alb\_request\_count\_threshold\_warning) | ALB Request Count warning threshold in seconds | `number` | `80` | no |
| <a name="input_alb_request_count_time_aggregator"></a> [alb\_request\_count\_time\_aggregator](#input\_alb\_request\_count\_time\_aggregator) | Monitor aggregator for ALB Request Count [available values: min, max or avg] | `string` | `"sum"` | no |
| <a name="input_alb_request_count_timeframe"></a> [alb\_request\_count\_timeframe](#input\_alb\_request\_count\_timeframe) | Monitor timeframe for ALB Request Count [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_alb_resource_panel_height"></a> [alb\_resource\_panel\_height](#input\_alb\_resource\_panel\_height) | Height of the panel | `number` | `7` | no |
| <a name="input_alb_resource_panel_width"></a> [alb\_resource\_panel\_width](#input\_alb\_resource\_panel\_width) | Width Of the Panel | `number` | `68` | no |
| <a name="input_alb_x_axis_intial_value"></a> [alb\_x\_axis\_intial\_value](#input\_alb\_x\_axis\_intial\_value) | Intial value of X-axis | `number` | `0` | no |
| <a name="input_alb_x_even"></a> [alb\_x\_even](#input\_alb\_x\_even) | Values of X-axis For Even Number Column | `list(number)` | <pre>[<br>  48,<br>  117,<br>  186,<br>  255,<br>  324,<br>  393,<br>  462,<br>  531,<br>  600,<br>  669<br>]</pre> | no |
| <a name="input_alb_x_odd"></a> [alb\_x\_odd](#input\_alb\_x\_odd) | Values of X-axis For Odd Number Column | `list(number)` | <pre>[<br>  14,<br>  83,<br>  152,<br>  221,<br>  290,<br>  359,<br>  428,<br>  497,<br>  566,<br>  635<br>]</pre> | no |
| <a name="input_alb_y"></a> [alb\_y](#input\_alb\_y) | Values of Y-axis | `list(number)` | <pre>[<br>  9,<br>  32,<br>  55,<br>  78,<br>  101,<br>  124,<br>  147,<br>  170,<br>  193,<br>  216<br>]</pre> | no |
| <a name="input_alb_y_axis_intial_value"></a> [alb\_y\_axis\_intial\_value](#input\_alb\_y\_axis\_intial\_value) | Intial value of Y-axis | `number` | `0` | no |
| <a name="input_artificial_requests_count"></a> [artificial\_requests\_count](#input\_artificial\_requests\_count) | Number of false requests used to mitigate false positive in case of low trafic | `number` | `5` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | Architecture environment | `string` | n/a | yes |
| <a name="input_evaluation_delay"></a> [evaluation\_delay](#input\_evaluation\_delay) | Delay in seconds for the metric evaluation | `number` | `900` | no |
| <a name="input_filter_tags_custom"></a> [filter\_tags\_custom](#input\_filter\_tags\_custom) | Tags used for custom filtering when filter\_tags\_use\_defaults is false | `string` | `"*"` | no |
| <a name="input_filter_tags_custom_excluded"></a> [filter\_tags\_custom\_excluded](#input\_filter\_tags\_custom\_excluded) | Tags excluded for custom filtering when filter\_tags\_use\_defaults is false | `string` | `""` | no |
| <a name="input_filter_tags_use_defaults"></a> [filter\_tags\_use\_defaults](#input\_filter\_tags\_use\_defaults) | Use default filter tags convention | `string` | `"true"` | no |
| <a name="input_httpcode_alb_4xx_enabled"></a> [httpcode\_alb\_4xx\_enabled](#input\_httpcode\_alb\_4xx\_enabled) | Flag to enable ALB httpcode 4xx monitor | `string` | `"true"` | no |
| <a name="input_httpcode_alb_4xx_extra_tags"></a> [httpcode\_alb\_4xx\_extra\_tags](#input\_httpcode\_alb\_4xx\_extra\_tags) | Extra tags for ALB httpcode 4xx monitor | `list(string)` | `[]` | no |
| <a name="input_httpcode_alb_4xx_message"></a> [httpcode\_alb\_4xx\_message](#input\_httpcode\_alb\_4xx\_message) | Custom message for ALB httpcode 4xx monitor | `string` | `""` | no |
| <a name="input_httpcode_alb_4xx_threshold_critical"></a> [httpcode\_alb\_4xx\_threshold\_critical](#input\_httpcode\_alb\_4xx\_threshold\_critical) | loadbalancer 4xx critical threshold in percentage | `number` | `80` | no |
| <a name="input_httpcode_alb_4xx_threshold_warning"></a> [httpcode\_alb\_4xx\_threshold\_warning](#input\_httpcode\_alb\_4xx\_threshold\_warning) | loadbalancer 4xx warning threshold in percentage | `number` | `60` | no |
| <a name="input_httpcode_alb_4xx_time_aggregator"></a> [httpcode\_alb\_4xx\_time\_aggregator](#input\_httpcode\_alb\_4xx\_time\_aggregator) | Monitor aggregator for ALB httpcode 4xx [available values: min, max or avg] | `string` | `"min"` | no |
| <a name="input_httpcode_alb_4xx_timeframe"></a> [httpcode\_alb\_4xx\_timeframe](#input\_httpcode\_alb\_4xx\_timeframe) | Monitor timeframe for ALB httpcode 4xx [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_5m"` | no |
| <a name="input_httpcode_alb_5xx_enabled"></a> [httpcode\_alb\_5xx\_enabled](#input\_httpcode\_alb\_5xx\_enabled) | Flag to enable ALB httpcode 5xx monitor | `string` | `"true"` | no |
| <a name="input_httpcode_alb_5xx_extra_tags"></a> [httpcode\_alb\_5xx\_extra\_tags](#input\_httpcode\_alb\_5xx\_extra\_tags) | Extra tags for ALB httpcode 5xx monitor | `list(string)` | `[]` | no |
| <a name="input_httpcode_alb_5xx_message"></a> [httpcode\_alb\_5xx\_message](#input\_httpcode\_alb\_5xx\_message) | Custom message for ALB httpcode 5xx monitor | `string` | `""` | no |
| <a name="input_httpcode_alb_5xx_threshold_critical"></a> [httpcode\_alb\_5xx\_threshold\_critical](#input\_httpcode\_alb\_5xx\_threshold\_critical) | loadbalancer 5xx critical threshold in percentage | `number` | `80` | no |
| <a name="input_httpcode_alb_5xx_threshold_warning"></a> [httpcode\_alb\_5xx\_threshold\_warning](#input\_httpcode\_alb\_5xx\_threshold\_warning) | loadbalancer 5xx warning threshold in percentage | `number` | `60` | no |
| <a name="input_httpcode_alb_5xx_time_aggregator"></a> [httpcode\_alb\_5xx\_time\_aggregator](#input\_httpcode\_alb\_5xx\_time\_aggregator) | Monitor aggregator for ALB httpcode 5xx [available values: min, max or avg] | `string` | `"min"` | no |
| <a name="input_httpcode_alb_5xx_timeframe"></a> [httpcode\_alb\_5xx\_timeframe](#input\_httpcode\_alb\_5xx\_timeframe) | Monitor timeframe for ALB httpcode 5xx [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_5m"` | no |
| <a name="input_httpcode_target_4xx_enabled"></a> [httpcode\_target\_4xx\_enabled](#input\_httpcode\_target\_4xx\_enabled) | Flag to enable ALB target httpcode 4xx monitor | `string` | `"true"` | no |
| <a name="input_httpcode_target_4xx_extra_tags"></a> [httpcode\_target\_4xx\_extra\_tags](#input\_httpcode\_target\_4xx\_extra\_tags) | Extra tags for ALB target httpcode 4xx monitor | `list(string)` | `[]` | no |
| <a name="input_httpcode_target_4xx_message"></a> [httpcode\_target\_4xx\_message](#input\_httpcode\_target\_4xx\_message) | Custom message for ALB target httpcode 4xx monitor | `string` | `""` | no |
| <a name="input_httpcode_target_4xx_threshold_critical"></a> [httpcode\_target\_4xx\_threshold\_critical](#input\_httpcode\_target\_4xx\_threshold\_critical) | target 4xx critical threshold in percentage | `number` | `80` | no |
| <a name="input_httpcode_target_4xx_threshold_warning"></a> [httpcode\_target\_4xx\_threshold\_warning](#input\_httpcode\_target\_4xx\_threshold\_warning) | target 4xx warning threshold in percentage | `number` | `60` | no |
| <a name="input_httpcode_target_4xx_time_aggregator"></a> [httpcode\_target\_4xx\_time\_aggregator](#input\_httpcode\_target\_4xx\_time\_aggregator) | Monitor aggregator for ALB target httpcode 4xx [available values: min, max or avg] | `string` | `"min"` | no |
| <a name="input_httpcode_target_4xx_timeframe"></a> [httpcode\_target\_4xx\_timeframe](#input\_httpcode\_target\_4xx\_timeframe) | Monitor timeframe for ALB target httpcode 4xx [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_5m"` | no |
| <a name="input_httpcode_target_5xx_enabled"></a> [httpcode\_target\_5xx\_enabled](#input\_httpcode\_target\_5xx\_enabled) | Flag to enable ALB target httpcode 5xx monitor | `string` | `"true"` | no |
| <a name="input_httpcode_target_5xx_extra_tags"></a> [httpcode\_target\_5xx\_extra\_tags](#input\_httpcode\_target\_5xx\_extra\_tags) | Extra tags for ALB target httpcode 5xx monitor | `list(string)` | `[]` | no |
| <a name="input_httpcode_target_5xx_message"></a> [httpcode\_target\_5xx\_message](#input\_httpcode\_target\_5xx\_message) | Custom message for ALB target httpcode 5xx monitor | `string` | `""` | no |
| <a name="input_httpcode_target_5xx_threshold_critical"></a> [httpcode\_target\_5xx\_threshold\_critical](#input\_httpcode\_target\_5xx\_threshold\_critical) | target 5xx critical threshold in percentage | `number` | `80` | no |
| <a name="input_httpcode_target_5xx_threshold_warning"></a> [httpcode\_target\_5xx\_threshold\_warning](#input\_httpcode\_target\_5xx\_threshold\_warning) | target 5xx warning threshold in percentage | `number` | `60` | no |
| <a name="input_httpcode_target_5xx_time_aggregator"></a> [httpcode\_target\_5xx\_time\_aggregator](#input\_httpcode\_target\_5xx\_time\_aggregator) | Monitor aggregator for ALB target httpcode 5xx [available values: min, max or avg] | `string` | `"min"` | no |
| <a name="input_httpcode_target_5xx_timeframe"></a> [httpcode\_target\_5xx\_timeframe](#input\_httpcode\_target\_5xx\_timeframe) | Monitor timeframe for ALB target httpcode 5xx [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_5m"` | no |
| <a name="input_latency_enabled"></a> [latency\_enabled](#input\_latency\_enabled) | Flag to enable ALB latency monitor | `string` | `"true"` | no |
| <a name="input_latency_extra_tags"></a> [latency\_extra\_tags](#input\_latency\_extra\_tags) | Extra tags for ALB latency monitor | `list(string)` | `[]` | no |
| <a name="input_latency_message"></a> [latency\_message](#input\_latency\_message) | Custom message for ALB latency monitor | `string` | `""` | no |
| <a name="input_latency_threshold_critical"></a> [latency\_threshold\_critical](#input\_latency\_threshold\_critical) | latency critical threshold in seconds | `number` | `3` | no |
| <a name="input_latency_threshold_warning"></a> [latency\_threshold\_warning](#input\_latency\_threshold\_warning) | latency warning threshold in seconds | `number` | `1` | no |
| <a name="input_latency_time_aggregator"></a> [latency\_time\_aggregator](#input\_latency\_time\_aggregator) | Monitor aggregator for ALB latency [available values: min, max or avg] | `string` | `"min"` | no |
| <a name="input_latency_timeframe"></a> [latency\_timeframe](#input\_latency\_timeframe) | Monitor timeframe for ALB latency [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_5m"` | no |
| <a name="input_message"></a> [message](#input\_message) | Message sent when a monitor is triggered | `any` | n/a | yes |
| <a name="input_new_host_delay"></a> [new\_host\_delay](#input\_new\_host\_delay) | Delay in seconds before monitor new resource | `number` | `300` | no |
| <a name="input_prefix_slug"></a> [prefix\_slug](#input\_prefix\_slug) | Prefix string to prepend between brackets on every monitors names | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_ALB_httpcode_4xx_id"></a> [ALB\_httpcode\_4xx\_id](#output\_ALB\_httpcode\_4xx\_id) | id for monitor ALB\_httpcode\_4xx |
| <a name="output_ALB_httpcode_5xx_id"></a> [ALB\_httpcode\_5xx\_id](#output\_ALB\_httpcode\_5xx\_id) | id for monitor ALB\_httpcode\_5xx |
| <a name="output_ALB_httpcode_target_4xx_id"></a> [ALB\_httpcode\_target\_4xx\_id](#output\_ALB\_httpcode\_target\_4xx\_id) | id for monitor ALB\_httpcode\_target\_4xx |
| <a name="output_ALB_httpcode_target_5xx_id"></a> [ALB\_httpcode\_target\_5xx\_id](#output\_ALB\_httpcode\_target\_5xx\_id) | id for monitor ALB\_httpcode\_target\_5xx |
| <a name="output_ALB_latency_id"></a> [ALB\_latency\_id](#output\_ALB\_latency\_id) | id for monitor ALB\_latency |
| <a name="output_ALB_no_healthy_instances_id"></a> [ALB\_no\_healthy\_instances\_id](#output\_ALB\_no\_healthy\_instances\_id) | id for monitor ALB\_no\_healthy\_instances |
| <a name="output_ALB_p99_response_time_id"></a> [ALB\_p99\_response\_time\_id](#output\_ALB\_p99\_response\_time\_id) | id for monitor ALB\_p99\_response\_time |
| <a name="output_ALB_processed_bytes"></a> [ALB\_processed\_bytes](#output\_ALB\_processed\_bytes) | id for monitor ALB\_processed\_bytes |
| <a name="output_ALB_request_count_id"></a> [ALB\_request\_count\_id](#output\_ALB\_request\_count\_id) | id for monitor ALB\_request\_count |
