## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | ~> 0.13.6 |
| <a name="requirement_datadog"></a> [datadog](#requirement\_datadog) | ~> 3.7.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_datadog"></a> [datadog](#provider\_datadog) | ~> 3.7.0 |
| <a name="provider_template"></a> [template](#provider\_template) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_filter-tags"></a> [filter-tags](#module\_filter-tags) | ../../../common/filter-tags |  |

## Resources

| Name | Type |
|------|------|
| [datadog_dashboard_json.dashboard_dynamodb](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/dashboard_json) | resource |
| [datadog_monitor.dynamodb_consumed_read_capacity](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.dynamodb_consumed_write_capacity](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.dynamodb_provisioned_read_capacity](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.dynamodb_provisioned_write_capacity](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.dynamodb_successful_request_latency](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.dynamodb_system_errors](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [template_file.dynamodb_dashboard](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |
| [template_file.dynamodb_widgets](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_dynamodb_consumed_read_capacity_aggregator"></a> [dynamodb\_consumed\_read\_capacity\_aggregator](#input\_dynamodb\_consumed\_read\_capacity\_aggregator) | Monitor aggregator for DynamoDB Consumed Read Capacity [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_dynamodb_consumed_read_capacity_enabled"></a> [dynamodb\_consumed\_read\_capacity\_enabled](#input\_dynamodb\_consumed\_read\_capacity\_enabled) | Flag to enable DynamoDB Consumed Read Capacity monitor | `string` | `"true"` | no |
| <a name="input_dynamodb_consumed_read_capacity_extra_tags"></a> [dynamodb\_consumed\_read\_capacity\_extra\_tags](#input\_dynamodb\_consumed\_read\_capacity\_extra\_tags) | Extra tags for DynamoDB Consumed Read Capacity monitor | `list(string)` | `[]` | no |
| <a name="input_dynamodb_consumed_read_capacity_message"></a> [dynamodb\_consumed\_read\_capacity\_message](#input\_dynamodb\_consumed\_read\_capacity\_message) | Custom message for DynamoDB Consumed Read Capacity | `string` | `""` | no |
| <a name="input_dynamodb_consumed_read_capacity_no_data_timeframe"></a> [dynamodb\_consumed\_read\_capacity\_no\_data\_timeframe](#input\_dynamodb\_consumed\_read\_capacity\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_dynamodb_consumed_read_capacity_notify_no_data"></a> [dynamodb\_consumed\_read\_capacity\_notify\_no\_data](#input\_dynamodb\_consumed\_read\_capacity\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_dynamodb_consumed_read_capacity_threshold_critical"></a> [dynamodb\_consumed\_read\_capacity\_threshold\_critical](#input\_dynamodb\_consumed\_read\_capacity\_threshold\_critical) | DynamoDB Consumed Read Capacity critical threshold | `number` | `30` | no |
| <a name="input_dynamodb_consumed_read_capacity_threshold_warning"></a> [dynamodb\_consumed\_read\_capacity\_threshold\_warning](#input\_dynamodb\_consumed\_read\_capacity\_threshold\_warning) | DynamoDB Consumed Read Capacity warning threshold | `number` | `15` | no |
| <a name="input_dynamodb_consumed_read_capacity_timeframe"></a> [dynamodb\_consumed\_read\_capacity\_timeframe](#input\_dynamodb\_consumed\_read\_capacity\_timeframe) | Monitor timeframe for DynamoDB Consumed Read Capacity [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_dynamodb_consumed_write_capacity_aggregator"></a> [dynamodb\_consumed\_write\_capacity\_aggregator](#input\_dynamodb\_consumed\_write\_capacity\_aggregator) | Monitor aggregator for DynamoDB Consumed Write Capacity [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_dynamodb_consumed_write_capacity_enabled"></a> [dynamodb\_consumed\_write\_capacity\_enabled](#input\_dynamodb\_consumed\_write\_capacity\_enabled) | Flag to enable DynamoDB Consumed Write Capacity monitor | `string` | `"true"` | no |
| <a name="input_dynamodb_consumed_write_capacity_extra_tags"></a> [dynamodb\_consumed\_write\_capacity\_extra\_tags](#input\_dynamodb\_consumed\_write\_capacity\_extra\_tags) | Extra tags for DynamoDB Consumed Write Capacity monitor | `list(string)` | `[]` | no |
| <a name="input_dynamodb_consumed_write_capacity_message"></a> [dynamodb\_consumed\_write\_capacity\_message](#input\_dynamodb\_consumed\_write\_capacity\_message) | Custom message for DynamoDB Consumed Write Capacity | `string` | `""` | no |
| <a name="input_dynamodb_consumed_write_capacity_no_data_timeframe"></a> [dynamodb\_consumed\_write\_capacity\_no\_data\_timeframe](#input\_dynamodb\_consumed\_write\_capacity\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_dynamodb_consumed_write_capacity_notify_no_data"></a> [dynamodb\_consumed\_write\_capacity\_notify\_no\_data](#input\_dynamodb\_consumed\_write\_capacity\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_dynamodb_consumed_write_capacity_threshold_critical"></a> [dynamodb\_consumed\_write\_capacity\_threshold\_critical](#input\_dynamodb\_consumed\_write\_capacity\_threshold\_critical) | DynamoDB Consumed Write Capacity critical threshold | `number` | `30` | no |
| <a name="input_dynamodb_consumed_write_capacity_threshold_warning"></a> [dynamodb\_consumed\_write\_capacity\_threshold\_warning](#input\_dynamodb\_consumed\_write\_capacity\_threshold\_warning) | DynamoDB Consumed Write Capacity warning threshold | `number` | `15` | no |
| <a name="input_dynamodb_consumed_write_capacity_timeframe"></a> [dynamodb\_consumed\_write\_capacity\_timeframe](#input\_dynamodb\_consumed\_write\_capacity\_timeframe) | Monitor timeframe for DynamoDB Consumed Write Capacity [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_dynamodb_dashboard_tags"></a> [dynamodb\_dashboard\_tags](#input\_dynamodb\_dashboard\_tags) | Dashboard Tags | `list(string)` | `[]` | no |
| <a name="input_dynamodb_metrics_panel_height"></a> [dynamodb\_metrics\_panel\_height](#input\_dynamodb\_metrics\_panel\_height) | Height of the panel | `number` | `21` | no |
| <a name="input_dynamodb_metrics_panel_width"></a> [dynamodb\_metrics\_panel\_width](#input\_dynamodb\_metrics\_panel\_width) | Width of the panel | `number` | `33` | no |
| <a name="input_dynamodb_monitor_tags"></a> [dynamodb\_monitor\_tags](#input\_dynamodb\_monitor\_tags) | Monitor Tags | `list(string)` | `[]` | no |
| <a name="input_dynamodb_provisioned_read_capacity_aggregator"></a> [dynamodb\_provisioned\_read\_capacity\_aggregator](#input\_dynamodb\_provisioned\_read\_capacity\_aggregator) | Monitor aggregator for DynamoDB Provisioned Read Capacity [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_dynamodb_provisioned_read_capacity_enabled"></a> [dynamodb\_provisioned\_read\_capacity\_enabled](#input\_dynamodb\_provisioned\_read\_capacity\_enabled) | Flag to enable DynamoDB Provisioned Read Capacity monitor | `string` | `"true"` | no |
| <a name="input_dynamodb_provisioned_read_capacity_extra_tags"></a> [dynamodb\_provisioned\_read\_capacity\_extra\_tags](#input\_dynamodb\_provisioned\_read\_capacity\_extra\_tags) | Extra tags for DynamoDB Provisioned Read Capacity monitor | `list(string)` | `[]` | no |
| <a name="input_dynamodb_provisioned_read_capacity_message"></a> [dynamodb\_provisioned\_read\_capacity\_message](#input\_dynamodb\_provisioned\_read\_capacity\_message) | Custom message for DynamoDB Provisioned Read Capacity | `string` | `""` | no |
| <a name="input_dynamodb_provisioned_read_capacity_no_data_timeframe"></a> [dynamodb\_provisioned\_read\_capacity\_no\_data\_timeframe](#input\_dynamodb\_provisioned\_read\_capacity\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_dynamodb_provisioned_read_capacity_notify_no_data"></a> [dynamodb\_provisioned\_read\_capacity\_notify\_no\_data](#input\_dynamodb\_provisioned\_read\_capacity\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_dynamodb_provisioned_read_capacity_threshold_critical"></a> [dynamodb\_provisioned\_read\_capacity\_threshold\_critical](#input\_dynamodb\_provisioned\_read\_capacity\_threshold\_critical) | DynamoDB Provisioned Read Capacity critical threshold | `number` | `30` | no |
| <a name="input_dynamodb_provisioned_read_capacity_threshold_warning"></a> [dynamodb\_provisioned\_read\_capacity\_threshold\_warning](#input\_dynamodb\_provisioned\_read\_capacity\_threshold\_warning) | DynamoDB Provisioned Read Capacity warning threshold | `number` | `15` | no |
| <a name="input_dynamodb_provisioned_read_capacity_timeframe"></a> [dynamodb\_provisioned\_read\_capacity\_timeframe](#input\_dynamodb\_provisioned\_read\_capacity\_timeframe) | Monitor timeframe for DynamoDB Provisioned Read Capacity [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_dynamodb_provisioned_write_capacity_aggregator"></a> [dynamodb\_provisioned\_write\_capacity\_aggregator](#input\_dynamodb\_provisioned\_write\_capacity\_aggregator) | Monitor aggregator for DynamoDB Provisioned Write Capacity [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_dynamodb_provisioned_write_capacity_enabled"></a> [dynamodb\_provisioned\_write\_capacity\_enabled](#input\_dynamodb\_provisioned\_write\_capacity\_enabled) | Flag to enable DynamoDB Provisioned Write Capacity monitor | `string` | `"true"` | no |
| <a name="input_dynamodb_provisioned_write_capacity_extra_tags"></a> [dynamodb\_provisioned\_write\_capacity\_extra\_tags](#input\_dynamodb\_provisioned\_write\_capacity\_extra\_tags) | Extra tags for DynamoDB Provisioned Write Capacity monitor | `list(string)` | `[]` | no |
| <a name="input_dynamodb_provisioned_write_capacity_message"></a> [dynamodb\_provisioned\_write\_capacity\_message](#input\_dynamodb\_provisioned\_write\_capacity\_message) | Custom message for DynamoDB Provisioned Write Capacity | `string` | `""` | no |
| <a name="input_dynamodb_provisioned_write_capacity_no_data_timeframe"></a> [dynamodb\_provisioned\_write\_capacity\_no\_data\_timeframe](#input\_dynamodb\_provisioned\_write\_capacity\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_dynamodb_provisioned_write_capacity_notify_no_data"></a> [dynamodb\_provisioned\_write\_capacity\_notify\_no\_data](#input\_dynamodb\_provisioned\_write\_capacity\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_dynamodb_provisioned_write_capacity_threshold_critical"></a> [dynamodb\_provisioned\_write\_capacity\_threshold\_critical](#input\_dynamodb\_provisioned\_write\_capacity\_threshold\_critical) | DynamoDB Provisioned Write Capacity critical threshold | `number` | `30` | no |
| <a name="input_dynamodb_provisioned_write_capacity_threshold_warning"></a> [dynamodb\_provisioned\_write\_capacity\_threshold\_warning](#input\_dynamodb\_provisioned\_write\_capacity\_threshold\_warning) | DynamoDB Provisioned Write Capacity warning threshold | `number` | `15` | no |
| <a name="input_dynamodb_provisioned_write_capacity_timeframe"></a> [dynamodb\_provisioned\_write\_capacity\_timeframe](#input\_dynamodb\_provisioned\_write\_capacity\_timeframe) | Monitor timeframe for DynamoDB Provisioned Write Capacity [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_dynamodb_resource_panel_height"></a> [dynamodb\_resource\_panel\_height](#input\_dynamodb\_resource\_panel\_height) | Height of the panel | `number` | `7` | no |
| <a name="input_dynamodb_resource_panel_width"></a> [dynamodb\_resource\_panel\_width](#input\_dynamodb\_resource\_panel\_width) | Width Of the Panel | `number` | `33` | no |
| <a name="input_dynamodb_successful_request_latency_aggregator"></a> [dynamodb\_successful\_request\_latency\_aggregator](#input\_dynamodb\_successful\_request\_latency\_aggregator) | Monitor aggregator for DynamoDB Successful Request Latency [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_dynamodb_successful_request_latency_enabled"></a> [dynamodb\_successful\_request\_latency\_enabled](#input\_dynamodb\_successful\_request\_latency\_enabled) | Flag to enable DynamoDB Successful Request Latency monitor | `string` | `"true"` | no |
| <a name="input_dynamodb_successful_request_latency_extra_tags"></a> [dynamodb\_successful\_request\_latency\_extra\_tags](#input\_dynamodb\_successful\_request\_latency\_extra\_tags) | Extra tags for DynamoDB Successful Request Latency monitor | `list(string)` | `[]` | no |
| <a name="input_dynamodb_successful_request_latency_message"></a> [dynamodb\_successful\_request\_latency\_message](#input\_dynamodb\_successful\_request\_latency\_message) | Custom message for DynamoDB Successful Request Latency | `string` | `""` | no |
| <a name="input_dynamodb_successful_request_latency_no_data_timeframe"></a> [dynamodb\_successful\_request\_latency\_no\_data\_timeframe](#input\_dynamodb\_successful\_request\_latency\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_dynamodb_successful_request_latency_notify_no_data"></a> [dynamodb\_successful\_request\_latency\_notify\_no\_data](#input\_dynamodb\_successful\_request\_latency\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_dynamodb_successful_request_latency_threshold_critical"></a> [dynamodb\_successful\_request\_latency\_threshold\_critical](#input\_dynamodb\_successful\_request\_latency\_threshold\_critical) | DynamoDB Successful Request Latency critical threshold | `number` | `200` | no |
| <a name="input_dynamodb_successful_request_latency_threshold_warning"></a> [dynamodb\_successful\_request\_latency\_threshold\_warning](#input\_dynamodb\_successful\_request\_latency\_threshold\_warning) | DynamoDB Successful Request Latency warning threshold | `number` | `150` | no |
| <a name="input_dynamodb_successful_request_latency_timeframe"></a> [dynamodb\_successful\_request\_latency\_timeframe](#input\_dynamodb\_successful\_request\_latency\_timeframe) | Monitor timeframe for DynamoDB Successful Request Latency [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_15m"` | no |
| <a name="input_dynamodb_system_errors_aggregator"></a> [dynamodb\_system\_errors\_aggregator](#input\_dynamodb\_system\_errors\_aggregator) | Monitor aggregator for DynamoDB System Errors [available values: min, max or avg] | `string` | `"sum"` | no |
| <a name="input_dynamodb_system_errors_enabled"></a> [dynamodb\_system\_errors\_enabled](#input\_dynamodb\_system\_errors\_enabled) | Flag to enable DynamoDB System Errors monitor | `string` | `"true"` | no |
| <a name="input_dynamodb_system_errors_extra_tags"></a> [dynamodb\_system\_errors\_extra\_tags](#input\_dynamodb\_system\_errors\_extra\_tags) | Extra tags for DynamoDB System Errors monitor | `list(string)` | `[]` | no |
| <a name="input_dynamodb_system_errors_message"></a> [dynamodb\_system\_errors\_message](#input\_dynamodb\_system\_errors\_message) | Custom message for DynamoDB System Errors | `string` | `""` | no |
| <a name="input_dynamodb_system_errors_no_data_timeframe"></a> [dynamodb\_system\_errors\_no\_data\_timeframe](#input\_dynamodb\_system\_errors\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_dynamodb_system_errors_notify_no_data"></a> [dynamodb\_system\_errors\_notify\_no\_data](#input\_dynamodb\_system\_errors\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_dynamodb_system_errors_threshold_critical"></a> [dynamodb\_system\_errors\_threshold\_critical](#input\_dynamodb\_system\_errors\_threshold\_critical) | DynamoDB System Errors critical threshold | `number` | `50` | no |
| <a name="input_dynamodb_system_errors_threshold_warning"></a> [dynamodb\_system\_errors\_threshold\_warning](#input\_dynamodb\_system\_errors\_threshold\_warning) | DynamoDB System Errors warning threshold | `number` | `40` | no |
| <a name="input_dynamodb_system_errors_timeframe"></a> [dynamodb\_system\_errors\_timeframe](#input\_dynamodb\_system\_errors\_timeframe) | Monitor timeframe for DynamoDB System Errors [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_dynamodb_x"></a> [dynamodb\_x](#input\_dynamodb\_x) | Values of X-axis | `list(number)` | <pre>[<br>  14,<br>  49,<br>  84,<br>  119,<br>  154,<br>  189,<br>  224,<br>  259,<br>  294,<br>  329<br>]</pre> | no |
| <a name="input_dynamodb_x_axis_intial_value"></a> [dynamodb\_x\_axis\_intial\_value](#input\_dynamodb\_x\_axis\_intial\_value) | Intial value of X-axis | `number` | `0` | no |
| <a name="input_dynamodb_y"></a> [dynamodb\_y](#input\_dynamodb\_y) | Values of Y-axis | `list(number)` | <pre>[<br>  9,<br>  32,<br>  55,<br>  78,<br>  101,<br>  124,<br>  147,<br>  170,<br>  193,<br>  216<br>]</pre> | no |
| <a name="input_dynamodb_y_axis_intial_value"></a> [dynamodb\_y\_axis\_intial\_value](#input\_dynamodb\_y\_axis\_intial\_value) | Intial value of Y-axis | `number` | `0` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | Architecture environment | `string` | n/a | yes |
| <a name="input_evaluation_delay"></a> [evaluation\_delay](#input\_evaluation\_delay) | Delay in seconds for the metric evaluation | `number` | `900` | no |
| <a name="input_filter_tags_custom"></a> [filter\_tags\_custom](#input\_filter\_tags\_custom) | Tags used for custom filtering when filter\_tags\_use\_defaults is false | `string` | `"*"` | no |
| <a name="input_filter_tags_custom_excluded"></a> [filter\_tags\_custom\_excluded](#input\_filter\_tags\_custom\_excluded) | Tags excluded for custom filtering when filter\_tags\_use\_defaults is false | `string` | `""` | no |
| <a name="input_filter_tags_use_defaults"></a> [filter\_tags\_use\_defaults](#input\_filter\_tags\_use\_defaults) | Use default filter tags convention | `string` | `"true"` | no |
| <a name="input_message"></a> [message](#input\_message) | Message sent when a monitor is triggered | `any` | n/a | yes |
| <a name="input_new_host_delay"></a> [new\_host\_delay](#input\_new\_host\_delay) | Delay in seconds before monitor new resource | `number` | `300` | no |
| <a name="input_prefix_slug"></a> [prefix\_slug](#input\_prefix\_slug) | Prefix string to prepend between brackets on every monitors names | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_dynamodb_consumed_read_capacity_id"></a> [dynamodb\_consumed\_read\_capacity\_id](#output\_dynamodb\_consumed\_read\_capacity\_id) | id for monitor dynamodb consumed read capacity |
| <a name="output_dynamodb_consumed_write_capacity_id"></a> [dynamodb\_consumed\_write\_capacity\_id](#output\_dynamodb\_consumed\_write\_capacity\_id) | id for monitor dynamodb consumed write capacity |
| <a name="output_dynamodb_provisioned_read_capacity_id"></a> [dynamodb\_provisioned\_read\_capacity\_id](#output\_dynamodb\_provisioned\_read\_capacity\_id) | id for monitor dynamodb provisioned read capacity |
| <a name="output_dynamodb_provisioned_write_capacity_id"></a> [dynamodb\_provisioned\_write\_capacity\_id](#output\_dynamodb\_provisioned\_write\_capacity\_id) | id for monitor dynamodb provisioned write capacity |
| <a name="output_dynamodb_successful_request_latency_id"></a> [dynamodb\_successful\_request\_latency\_id](#output\_dynamodb\_successful\_request\_latency\_id) | id for monitor dynamodb successful request latency |
| <a name="output_dynamodb_system_errors_id"></a> [dynamodb\_system\_errors\_id](#output\_dynamodb\_system\_errors\_id) | id for monitor dynamodb system errors |
