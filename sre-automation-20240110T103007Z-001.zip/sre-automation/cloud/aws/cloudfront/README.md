## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | ~> 0.13.6 |
| <a name="requirement_datadog"></a> [datadog](#requirement\_datadog) | ~> 3.7.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_datadog"></a> [datadog](#provider\_datadog) | ~> 3.7.0 |
| <a name="provider_template"></a> [template](#provider\_template) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_filter-tags"></a> [filter-tags](#module\_filter-tags) | ../../../common/filter-tags |  |

## Resources

| Name | Type |
|------|------|
| [datadog_dashboard_json.dashboard_cloudfront](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/dashboard_json) | resource |
| [datadog_monitor.cloudfront_4xx_error_rate](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.cloudfront_5xx_error_rate](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.cloudfront_requests](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.cloudfront_total_error_rate](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [template_file.cloudfront_dashboard](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |
| [template_file.cloudfront_widgets](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cloudfront_4xx_error_rate_aggregator"></a> [cloudfront\_4xx\_error\_rate\_aggregator](#input\_cloudfront\_4xx\_error\_rate\_aggregator) | Monitor aggregator for CloudFront 4xxError Rate [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_cloudfront_4xx_error_rate_enabled"></a> [cloudfront\_4xx\_error\_rate\_enabled](#input\_cloudfront\_4xx\_error\_rate\_enabled) | Flag to enable CloudFront 4xxError Rate monitor | `string` | `"true"` | no |
| <a name="input_cloudfront_4xx_error_rate_extra_tags"></a> [cloudfront\_4xx\_error\_rate\_extra\_tags](#input\_cloudfront\_4xx\_error\_rate\_extra\_tags) | Extra tags for CloudFront 4xxError Rate monitor | `list(string)` | `[]` | no |
| <a name="input_cloudfront_4xx_error_rate_message"></a> [cloudfront\_4xx\_error\_rate\_message](#input\_cloudfront\_4xx\_error\_rate\_message) | Custom message for CloudFront 4xxError Rate | `string` | `""` | no |
| <a name="input_cloudfront_4xx_error_rate_no_data_timeframe"></a> [cloudfront\_4xx\_error\_rate\_no\_data\_timeframe](#input\_cloudfront\_4xx\_error\_rate\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_cloudfront_4xx_error_rate_notify_no_data"></a> [cloudfront\_4xx\_error\_rate\_notify\_no\_data](#input\_cloudfront\_4xx\_error\_rate\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_cloudfront_4xx_error_rate_threshold_critical"></a> [cloudfront\_4xx\_error\_rate\_threshold\_critical](#input\_cloudfront\_4xx\_error\_rate\_threshold\_critical) | CloudFront 4xxError Rate critical threshold | `number` | `50000` | no |
| <a name="input_cloudfront_4xx_error_rate_threshold_warning"></a> [cloudfront\_4xx\_error\_rate\_threshold\_warning](#input\_cloudfront\_4xx\_error\_rate\_threshold\_warning) | CloudFront 4xxError Rate warning threshold | `number` | `40000` | no |
| <a name="input_cloudfront_4xx_error_rate_timeframe"></a> [cloudfront\_4xx\_error\_rate\_timeframe](#input\_cloudfront\_4xx\_error\_rate\_timeframe) | Monitor timeframe for CloudFront 4xxError Rate [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_cloudfront_5xx_error_rate_aggregator"></a> [cloudfront\_5xx\_error\_rate\_aggregator](#input\_cloudfront\_5xx\_error\_rate\_aggregator) | Monitor aggregator for CloudFront 5xxError Rate [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_cloudfront_5xx_error_rate_enabled"></a> [cloudfront\_5xx\_error\_rate\_enabled](#input\_cloudfront\_5xx\_error\_rate\_enabled) | Flag to enable CloudFront 5xxError Rate monitor | `string` | `"true"` | no |
| <a name="input_cloudfront_5xx_error_rate_extra_tags"></a> [cloudfront\_5xx\_error\_rate\_extra\_tags](#input\_cloudfront\_5xx\_error\_rate\_extra\_tags) | Extra tags for CloudFront 5xxError Rate monitor | `list(string)` | `[]` | no |
| <a name="input_cloudfront_5xx_error_rate_message"></a> [cloudfront\_5xx\_error\_rate\_message](#input\_cloudfront\_5xx\_error\_rate\_message) | Custom message for CloudFront 5xxError Rate | `string` | `""` | no |
| <a name="input_cloudfront_5xx_error_rate_no_data_timeframe"></a> [cloudfront\_5xx\_error\_rate\_no\_data\_timeframe](#input\_cloudfront\_5xx\_error\_rate\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_cloudfront_5xx_error_rate_notify_no_data"></a> [cloudfront\_5xx\_error\_rate\_notify\_no\_data](#input\_cloudfront\_5xx\_error\_rate\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_cloudfront_5xx_error_rate_threshold_critical"></a> [cloudfront\_5xx\_error\_rate\_threshold\_critical](#input\_cloudfront\_5xx\_error\_rate\_threshold\_critical) | CloudFront 5xxError Rate critical threshold | `number` | `50000` | no |
| <a name="input_cloudfront_5xx_error_rate_threshold_warning"></a> [cloudfront\_5xx\_error\_rate\_threshold\_warning](#input\_cloudfront\_5xx\_error\_rate\_threshold\_warning) | CloudFront 5xxError Rate warning threshold | `number` | `40000` | no |
| <a name="input_cloudfront_5xx_error_rate_timeframe"></a> [cloudfront\_5xx\_error\_rate\_timeframe](#input\_cloudfront\_5xx\_error\_rate\_timeframe) | Monitor timeframe for CloudFront 5xxError Rate [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_cloudfront_dashboard_tags"></a> [cloudfront\_dashboard\_tags](#input\_cloudfront\_dashboard\_tags) | Dashboard Tags | `list(string)` | `[]` | no |
| <a name="input_cloudfront_metrics_panel_height"></a> [cloudfront\_metrics\_panel\_height](#input\_cloudfront\_metrics\_panel\_height) | Height of the panel | `number` | `21` | no |
| <a name="input_cloudfront_metrics_panel_width"></a> [cloudfront\_metrics\_panel\_width](#input\_cloudfront\_metrics\_panel\_width) | Width of the panel | `number` | `33` | no |
| <a name="input_cloudfront_monitor_tags"></a> [cloudfront\_monitor\_tags](#input\_cloudfront\_monitor\_tags) | Monitor Tags | `list(string)` | `[]` | no |
| <a name="input_cloudfront_requests_aggregator"></a> [cloudfront\_requests\_aggregator](#input\_cloudfront\_requests\_aggregator) | Monitor aggregator for CloudFront Requests [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_cloudfront_requests_enabled"></a> [cloudfront\_requests\_enabled](#input\_cloudfront\_requests\_enabled) | Flag to enable CloudFront Requests monitor | `string` | `"true"` | no |
| <a name="input_cloudfront_requests_extra_tags"></a> [cloudfront\_requests\_extra\_tags](#input\_cloudfront\_requests\_extra\_tags) | Extra tags for CloudFront Requests monitor | `list(string)` | `[]` | no |
| <a name="input_cloudfront_requests_message"></a> [cloudfront\_requests\_message](#input\_cloudfront\_requests\_message) | Custom message for CloudFront Requests | `string` | `""` | no |
| <a name="input_cloudfront_requests_no_data_timeframe"></a> [cloudfront\_requests\_no\_data\_timeframe](#input\_cloudfront\_requests\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_cloudfront_requests_notify_no_data"></a> [cloudfront\_requests\_notify\_no\_data](#input\_cloudfront\_requests\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_cloudfront_requests_threshold_critical"></a> [cloudfront\_requests\_threshold\_critical](#input\_cloudfront\_requests\_threshold\_critical) | CloudFront Requests critical threshold | `number` | `50000` | no |
| <a name="input_cloudfront_requests_threshold_warning"></a> [cloudfront\_requests\_threshold\_warning](#input\_cloudfront\_requests\_threshold\_warning) | CloudFront Requests warning threshold | `number` | `40000` | no |
| <a name="input_cloudfront_requests_timeframe"></a> [cloudfront\_requests\_timeframe](#input\_cloudfront\_requests\_timeframe) | Monitor timeframe for CloudFront Requests [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_cloudfront_resource_panel_height"></a> [cloudfront\_resource\_panel\_height](#input\_cloudfront\_resource\_panel\_height) | Height of the panel | `number` | `7` | no |
| <a name="input_cloudfront_resource_panel_width"></a> [cloudfront\_resource\_panel\_width](#input\_cloudfront\_resource\_panel\_width) | Width Of the Panel | `number` | `33` | no |
| <a name="input_cloudfront_total_error_rate_aggregator"></a> [cloudfront\_total\_error\_rate\_aggregator](#input\_cloudfront\_total\_error\_rate\_aggregator) | Monitor aggregator for CloudFront Total Error Rate [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_cloudfront_total_error_rate_enabled"></a> [cloudfront\_total\_error\_rate\_enabled](#input\_cloudfront\_total\_error\_rate\_enabled) | Flag to enable CloudFront Total Error Rate monitor | `string` | `"true"` | no |
| <a name="input_cloudfront_total_error_rate_extra_tags"></a> [cloudfront\_total\_error\_rate\_extra\_tags](#input\_cloudfront\_total\_error\_rate\_extra\_tags) | Extra tags for CloudFront Total Error Rate monitor | `list(string)` | `[]` | no |
| <a name="input_cloudfront_total_error_rate_message"></a> [cloudfront\_total\_error\_rate\_message](#input\_cloudfront\_total\_error\_rate\_message) | Custom message for CloudFront Total Error Rate | `string` | `""` | no |
| <a name="input_cloudfront_total_error_rate_no_data_timeframe"></a> [cloudfront\_total\_error\_rate\_no\_data\_timeframe](#input\_cloudfront\_total\_error\_rate\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_cloudfront_total_error_rate_notify_no_data"></a> [cloudfront\_total\_error\_rate\_notify\_no\_data](#input\_cloudfront\_total\_error\_rate\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_cloudfront_total_error_rate_threshold_critical"></a> [cloudfront\_total\_error\_rate\_threshold\_critical](#input\_cloudfront\_total\_error\_rate\_threshold\_critical) | CloudFront Total Error Rate critical threshold | `number` | `50000` | no |
| <a name="input_cloudfront_total_error_rate_threshold_warning"></a> [cloudfront\_total\_error\_rate\_threshold\_warning](#input\_cloudfront\_total\_error\_rate\_threshold\_warning) | CloudFront Total Error Rate warning threshold | `number` | `40000` | no |
| <a name="input_cloudfront_total_error_rate_timeframe"></a> [cloudfront\_total\_error\_rate\_timeframe](#input\_cloudfront\_total\_error\_rate\_timeframe) | Monitor timeframe for CloudFront Total Error Rate [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_cloudfront_x"></a> [cloudfront\_x](#input\_cloudfront\_x) | Values of X-axis | `list(number)` | <pre>[<br>  14,<br>  49,<br>  84,<br>  119,<br>  154,<br>  189,<br>  224,<br>  259,<br>  294,<br>  329<br>]</pre> | no |
| <a name="input_cloudfront_x_axis_intial_value"></a> [cloudfront\_x\_axis\_intial\_value](#input\_cloudfront\_x\_axis\_intial\_value) | Intial value of X-axis | `number` | `0` | no |
| <a name="input_cloudfront_y"></a> [cloudfront\_y](#input\_cloudfront\_y) | Values of Y-axis | `list(number)` | <pre>[<br>  9,<br>  32,<br>  55,<br>  78,<br>  101,<br>  124,<br>  147,<br>  170,<br>  193,<br>  216<br>]</pre> | no |
| <a name="input_cloudfront_y_axis_intial_value"></a> [cloudfront\_y\_axis\_intial\_value](#input\_cloudfront\_y\_axis\_intial\_value) | Intial value of Y-axis | `number` | `0` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | Architecture environment | `string` | n/a | yes |
| <a name="input_evaluation_delay"></a> [evaluation\_delay](#input\_evaluation\_delay) | Delay in seconds for the metric evaluation | `number` | `900` | no |
| <a name="input_filter_tags_custom"></a> [filter\_tags\_custom](#input\_filter\_tags\_custom) | Tags used for custom filtering when filter\_tags\_use\_defaults is false | `string` | `"*"` | no |
| <a name="input_filter_tags_custom_excluded"></a> [filter\_tags\_custom\_excluded](#input\_filter\_tags\_custom\_excluded) | Tags excluded for custom filtering when filter\_tags\_use\_defaults is false | `string` | `""` | no |
| <a name="input_filter_tags_use_defaults"></a> [filter\_tags\_use\_defaults](#input\_filter\_tags\_use\_defaults) | Use default filter tags convention | `string` | `"true"` | no |
| <a name="input_message"></a> [message](#input\_message) | Message sent when a monitor is triggered | `any` | n/a | yes |
| <a name="input_new_host_delay"></a> [new\_host\_delay](#input\_new\_host\_delay) | Delay in seconds before monitor new resource | `number` | `300` | no |
| <a name="input_prefix_slug"></a> [prefix\_slug](#input\_prefix\_slug) | Prefix string to prepend between brackets on every monitors names | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cloudfront_4xx_error_rate_id"></a> [cloudfront\_4xx\_error\_rate\_id](#output\_cloudfront\_4xx\_error\_rate\_id) | id for monitor CloudFront 4xxError Rate |
| <a name="output_cloudfront_5xx_error_rate_id"></a> [cloudfront\_5xx\_error\_rate\_id](#output\_cloudfront\_5xx\_error\_rate\_id) | id for monitor CloudFront 5xxError Rate |
| <a name="output_cloudfront_requests_id"></a> [cloudfront\_requests\_id](#output\_cloudfront\_requests\_id) | id for monitor CloudFront Requests |
| <a name="output_cloudfront_total_error_rate_id"></a> [cloudfront\_total\_error\_rate\_id](#output\_cloudfront\_total\_error\_rate\_id) | id for monitor CloudFront Total Error Rate |
