## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | ~> 0.13.6 |
| <a name="requirement_datadog"></a> [datadog](#requirement\_datadog) | ~> 3.7.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_datadog"></a> [datadog](#provider\_datadog) | ~> 3.7.0 |
| <a name="provider_template"></a> [template](#provider\_template) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_filter-tags"></a> [filter-tags](#module\_filter-tags) | ../../../common/filter-tags |  |

## Resources

| Name | Type |
|------|------|
| [datadog_dashboard_json.dashboard_ec2](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/dashboard_json) | resource |
| [datadog_monitor.EC2_disk_usage](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.EC2_disk_write_ops](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.EC2_host_status](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.EC2_network_in_throughput](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.EC2_status_check_failed](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.EC2_usable_memory](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [template_file.ec2_dashboard](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |
| [template_file.ec2_widgets](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_ec2_dashboard_tags"></a> [ec2\_dashboard\_tags](#input\_ec2\_dashboard\_tags) | Dashboard Tags | `list(string)` | `[]` | no |
| <a name="input_ec2_disk_usage_aggregator"></a> [ec2\_disk\_usage\_aggregator](#input\_ec2\_disk\_usage\_aggregator) | Monitor aggregator for EC2 Disk Usage [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_ec2_disk_usage_enabled"></a> [ec2\_disk\_usage\_enabled](#input\_ec2\_disk\_usage\_enabled) | Flag to enable EC2 Disk Usage monitor | `string` | `"true"` | no |
| <a name="input_ec2_disk_usage_extra_tags"></a> [ec2\_disk\_usage\_extra\_tags](#input\_ec2\_disk\_usage\_extra\_tags) | Extra tags for EC2 Disk Usage monitor | `list(string)` | `[]` | no |
| <a name="input_ec2_disk_usage_message"></a> [ec2\_disk\_usage\_message](#input\_ec2\_disk\_usage\_message) | Custom message for EC2 Disk Usage | `string` | `""` | no |
| <a name="input_ec2_disk_usage_no_data_timeframe"></a> [ec2\_disk\_usage\_no\_data\_timeframe](#input\_ec2\_disk\_usage\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_ec2_disk_usage_notify_no_data"></a> [ec2\_disk\_usage\_notify\_no\_data](#input\_ec2\_disk\_usage\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_ec2_disk_usage_threshold_critical"></a> [ec2\_disk\_usage\_threshold\_critical](#input\_ec2\_disk\_usage\_threshold\_critical) | EC2 Disk Usage critical threshold in seconds | `number` | `90` | no |
| <a name="input_ec2_disk_usage_threshold_warning"></a> [ec2\_disk\_usage\_threshold\_warning](#input\_ec2\_disk\_usage\_threshold\_warning) | EC2 Disk Usage warning threshold in seconds | `number` | `75` | no |
| <a name="input_ec2_disk_usage_timeframe"></a> [ec2\_disk\_usage\_timeframe](#input\_ec2\_disk\_usage\_timeframe) | Monitor timeframe for EC2 Disk Usage [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_15m"` | no |
| <a name="input_ec2_disk_write_ops_letency_enabled"></a> [ec2\_disk\_write\_ops\_letency\_enabled](#input\_ec2\_disk\_write\_ops\_letency\_enabled) | Flag to enable EC2 disk write latency monitor | `string` | `"true"` | no |
| <a name="input_ec2_disk_write_ops_message"></a> [ec2\_disk\_write\_ops\_message](#input\_ec2\_disk\_write\_ops\_message) | Custom message for EC2 Disk Write Operation | `string` | `""` | no |
| <a name="input_ec2_disk_write_ops_no_data_timeframe"></a> [ec2\_disk\_write\_ops\_no\_data\_timeframe](#input\_ec2\_disk\_write\_ops\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_ec2_disk_write_ops_notify_no_data"></a> [ec2\_disk\_write\_ops\_notify\_no\_data](#input\_ec2\_disk\_write\_ops\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_ec2_diskwriteops_extra_tags"></a> [ec2\_diskwriteops\_extra\_tags](#input\_ec2\_diskwriteops\_extra\_tags) | Extra tags for EC2 Disk Write Operation monitor | `list(string)` | `[]` | no |
| <a name="input_ec2_diskwriteops_threshold_critical"></a> [ec2\_diskwriteops\_threshold\_critical](#input\_ec2\_diskwriteops\_threshold\_critical) | Disk Write Operation critical threshold | `number` | `150` | no |
| <a name="input_ec2_diskwriteops_threshold_warning"></a> [ec2\_diskwriteops\_threshold\_warning](#input\_ec2\_diskwriteops\_threshold\_warning) | Disk Write Operation warning threshold | `number` | `100` | no |
| <a name="input_ec2_diskwriteops_time_aggregator"></a> [ec2\_diskwriteops\_time\_aggregator](#input\_ec2\_diskwriteops\_time\_aggregator) | Monitor aggregator for EC2 Disk Write Operation [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_ec2_diskwriteops_timeframe"></a> [ec2\_diskwriteops\_timeframe](#input\_ec2\_diskwriteops\_timeframe) | Monitor timeframe for EC2 Disk Write Operation [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_ec2_host_ok_aggregator"></a> [ec2\_host\_ok\_aggregator](#input\_ec2\_host\_ok\_aggregator) | Monitor aggregator for EC2 Host Status Check [available values: min, max or avg] | `string` | `"max"` | no |
| <a name="input_ec2_host_ok_enabled"></a> [ec2\_host\_ok\_enabled](#input\_ec2\_host\_ok\_enabled) | Flag to enable EC2 Host Status Check monitor | `string` | `"true"` | no |
| <a name="input_ec2_host_ok_extra_tags"></a> [ec2\_host\_ok\_extra\_tags](#input\_ec2\_host\_ok\_extra\_tags) | Extra tags for EC2 Host Status Check monitor | `list(string)` | `[]` | no |
| <a name="input_ec2_host_ok_message"></a> [ec2\_host\_ok\_message](#input\_ec2\_host\_ok\_message) | Custom message for EC2 Host Status Check | `string` | `""` | no |
| <a name="input_ec2_host_ok_no_data_timeframe"></a> [ec2\_host\_ok\_no\_data\_timeframe](#input\_ec2\_host\_ok\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_ec2_host_ok_notify_no_data"></a> [ec2\_host\_ok\_notify\_no\_data](#input\_ec2\_host\_ok\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_ec2_host_ok_threshold_critical"></a> [ec2\_host\_ok\_threshold\_critical](#input\_ec2\_host\_ok\_threshold\_critical) | Host Status Check critical threshold | `number` | `0` | no |
| <a name="input_ec2_host_ok_threshold_warning"></a> [ec2\_host\_ok\_threshold\_warning](#input\_ec2\_host\_ok\_threshold\_warning) | Host Status Check warning threshold | `string` | `""` | no |
| <a name="input_ec2_host_ok_timeframe"></a> [ec2\_host\_ok\_timeframe](#input\_ec2\_host\_ok\_timeframe) | Monitor timeframe for EC2 Host Status Check [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_15m"` | no |
| <a name="input_ec2_monitor_tags"></a> [ec2\_monitor\_tags](#input\_ec2\_monitor\_tags) | Monitor Tags | `list(string)` | `[]` | no |
| <a name="input_ec2_network_in_extra_tags"></a> [ec2\_network\_in\_extra\_tags](#input\_ec2\_network\_in\_extra\_tags) | Extra tags for EC2 Network In Throughput monitor | `list(string)` | `[]` | no |
| <a name="input_ec2_network_in_no_data_timeframe"></a> [ec2\_network\_in\_no\_data\_timeframe](#input\_ec2\_network\_in\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_ec2_network_in_notify_no_data"></a> [ec2\_network\_in\_notify\_no\_data](#input\_ec2\_network\_in\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_ec2_network_in_threshold_critical"></a> [ec2\_network\_in\_threshold\_critical](#input\_ec2\_network\_in\_threshold\_critical) | Network In Throughput critical threshold | `number` | `2500000000` | no |
| <a name="input_ec2_network_in_threshold_warning"></a> [ec2\_network\_in\_threshold\_warning](#input\_ec2\_network\_in\_threshold\_warning) | Network In Throughput warning threshold in seconds | `number` | `2000000000` | no |
| <a name="input_ec2_network_in_throughput_enabled"></a> [ec2\_network\_in\_throughput\_enabled](#input\_ec2\_network\_in\_throughput\_enabled) | Flag to enable EC2 Network-In Throughput monitor | `string` | `"true"` | no |
| <a name="input_ec2_network_in_throughput_message"></a> [ec2\_network\_in\_throughput\_message](#input\_ec2\_network\_in\_throughput\_message) | Custom message for EC2 Network-In Throughput | `string` | `""` | no |
| <a name="input_ec2_network_in_time_aggregator"></a> [ec2\_network\_in\_time\_aggregator](#input\_ec2\_network\_in\_time\_aggregator) | Monitor aggregator for EC2 Network-In Throughput [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_ec2_network_in_timeframe"></a> [ec2\_network\_in\_timeframe](#input\_ec2\_network\_in\_timeframe) | Monitor timeframe for EC2 Network-In Throughput [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_15m"` | no |
| <a name="input_ec2_status_check_failed_enabled"></a> [ec2\_status\_check\_failed\_enabled](#input\_ec2\_status\_check\_failed\_enabled) | Flag to enable EC2 Status Check Failed monitor | `string` | `"true"` | no |
| <a name="input_ec2_status_check_failed_extra_tags"></a> [ec2\_status\_check\_failed\_extra\_tags](#input\_ec2\_status\_check\_failed\_extra\_tags) | Extra tags for EC2 Status Check Failed monitor | `list(string)` | `[]` | no |
| <a name="input_ec2_status_check_failed_message"></a> [ec2\_status\_check\_failed\_message](#input\_ec2\_status\_check\_failed\_message) | Custom message for EC2 Status Check Failed | `string` | `""` | no |
| <a name="input_ec2_status_check_failed_no_data_timeframe"></a> [ec2\_status\_check\_failed\_no\_data\_timeframe](#input\_ec2\_status\_check\_failed\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_ec2_status_check_failed_notify_no_data"></a> [ec2\_status\_check\_failed\_notify\_no\_data](#input\_ec2\_status\_check\_failed\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_ec2_status_check_failed_threshold_critical"></a> [ec2\_status\_check\_failed\_threshold\_critical](#input\_ec2\_status\_check\_failed\_threshold\_critical) | Status Check Failed critical threshold | `number` | `1` | no |
| <a name="input_ec2_status_check_failed_threshold_warning"></a> [ec2\_status\_check\_failed\_threshold\_warning](#input\_ec2\_status\_check\_failed\_threshold\_warning) | Status Check Failed warning threshold | `string` | `""` | no |
| <a name="input_ec2_status_check_failed_time_aggregator"></a> [ec2\_status\_check\_failed\_time\_aggregator](#input\_ec2\_status\_check\_failed\_time\_aggregator) | Monitor aggregator for EC2 Status Check Failed [available values: min, max or avg] | `string` | `"min"` | no |
| <a name="input_ec2_status_check_failed_timeframe"></a> [ec2\_status\_check\_failed\_timeframe](#input\_ec2\_status\_check\_failed\_timeframe) | Monitor timeframe for EC2 Status Check Failed [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_15m"` | no |
| <a name="input_ec2_usable_mem_aggregator"></a> [ec2\_usable\_mem\_aggregator](#input\_ec2\_usable\_mem\_aggregator) | Monitor aggregator for EC2 Usable Memory [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_ec2_usable_mem_enabled"></a> [ec2\_usable\_mem\_enabled](#input\_ec2\_usable\_mem\_enabled) | Flag to enable EC2 Usable Memory monitor | `string` | `"true"` | no |
| <a name="input_ec2_usable_mem_extra_tags"></a> [ec2\_usable\_mem\_extra\_tags](#input\_ec2\_usable\_mem\_extra\_tags) | Extra tags for EC2 Usable Memory monitor | `list(string)` | `[]` | no |
| <a name="input_ec2_usable_mem_message"></a> [ec2\_usable\_mem\_message](#input\_ec2\_usable\_mem\_message) | Custom message for EC2 Usable Memory | `string` | `""` | no |
| <a name="input_ec2_usable_mem_no_data_timeframe"></a> [ec2\_usable\_mem\_no\_data\_timeframe](#input\_ec2\_usable\_mem\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_ec2_usable_mem_notify_no_data"></a> [ec2\_usable\_mem\_notify\_no\_data](#input\_ec2\_usable\_mem\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_ec2_usable_mem_threshold_critical"></a> [ec2\_usable\_mem\_threshold\_critical](#input\_ec2\_usable\_mem\_threshold\_critical) | EC2 Usable Memory critical threshold | `number` | `10` | no |
| <a name="input_ec2_usable_mem_threshold_warning"></a> [ec2\_usable\_mem\_threshold\_warning](#input\_ec2\_usable\_mem\_threshold\_warning) | EC2 Usable Memory warning threshold in seconds | `number` | `30` | no |
| <a name="input_ec2_usable_mem_timeframe"></a> [ec2\_usable\_mem\_timeframe](#input\_ec2\_usable\_mem\_timeframe) | Monitor timeframe for EC2 Usable Memory [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_15m"` | no |
| <a name="input_ec2_y"></a> [ec2\_y](#input\_ec2\_y) | Values of Y-axis | `list(number)` | <pre>[<br>  9,<br>  32,<br>  55,<br>  78,<br>  101,<br>  124,<br>  147,<br>  170,<br>  193,<br>  216<br>]</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | Architecture environment | `string` | n/a | yes |
| <a name="input_evaluation_delay"></a> [evaluation\_delay](#input\_evaluation\_delay) | Delay in seconds for the metric evaluation | `number` | `900` | no |
| <a name="input_filter_tags_custom"></a> [filter\_tags\_custom](#input\_filter\_tags\_custom) | Tags used for custom filtering when filter\_tags\_use\_defaults is false | `string` | `"*"` | no |
| <a name="input_filter_tags_custom_excluded"></a> [filter\_tags\_custom\_excluded](#input\_filter\_tags\_custom\_excluded) | Tags excluded for custom filtering when filter\_tags\_use\_defaults is false | `string` | `""` | no |
| <a name="input_filter_tags_use_defaults"></a> [filter\_tags\_use\_defaults](#input\_filter\_tags\_use\_defaults) | Use default filter tags convention | `string` | `"true"` | no |
| <a name="input_message"></a> [message](#input\_message) | Message sent when a monitor is triggered | `any` | n/a | yes |
| <a name="input_metrics_panel_height"></a> [metrics\_panel\_height](#input\_metrics\_panel\_height) | Height of the panel | `number` | `21` | no |
| <a name="input_metrics_panel_width"></a> [metrics\_panel\_width](#input\_metrics\_panel\_width) | Width of the panel | `number` | `33` | no |
| <a name="input_new_host_delay"></a> [new\_host\_delay](#input\_new\_host\_delay) | Delay in seconds before monitor new resource | `number` | `300` | no |
| <a name="input_prefix_slug"></a> [prefix\_slug](#input\_prefix\_slug) | Prefix string to prepend between brackets on every monitors names | `string` | `""` | no |
| <a name="input_resource_panel_height"></a> [resource\_panel\_height](#input\_resource\_panel\_height) | Height of the panel | `number` | `7` | no |
| <a name="input_resource_panel_width"></a> [resource\_panel\_width](#input\_resource\_panel\_width) | Width Of the Panel | `number` | `33` | no |
| <a name="input_x"></a> [x](#input\_x) | Values of X-axis | `list(number)` | <pre>[<br>  14,<br>  49,<br>  84,<br>  119,<br>  154,<br>  189,<br>  224,<br>  259,<br>  294,<br>  329<br>]</pre> | no |
| <a name="input_x_axis_intial_value"></a> [x\_axis\_intial\_value](#input\_x\_axis\_intial\_value) | Intial value of X-axis | `number` | `0` | no |
| <a name="input_y_axis_intial_value"></a> [y\_axis\_intial\_value](#input\_y\_axis\_intial\_value) | Intial value of Y-axis | `number` | `0` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_EC2_dashboard_id"></a> [EC2\_dashboard\_id](#output\_EC2\_dashboard\_id) | id for EC2 Dashboard |
| <a name="output_EC2_disk_usage_id"></a> [EC2\_disk\_usage\_id](#output\_EC2\_disk\_usage\_id) | id for monitor EC2 Disk Usage |
| <a name="output_EC2_disk_write_ops_id"></a> [EC2\_disk\_write\_ops\_id](#output\_EC2\_disk\_write\_ops\_id) | id for monitor EC2 Disk Write Operations |
| <a name="output_EC2_host_status_id"></a> [EC2\_host\_status\_id](#output\_EC2\_host\_status\_id) | id for monitor EC2 Host Status |
| <a name="output_EC2_network_in_throughput_id"></a> [EC2\_network\_in\_throughput\_id](#output\_EC2\_network\_in\_throughput\_id) | id for monitor EC2 Network In Throughput |
| <a name="output_EC2_status_check_failed_id"></a> [EC2\_status\_check\_failed\_id](#output\_EC2\_status\_check\_failed\_id) | id for monitor EC2 Status Check Failed |
| <a name="output_EC2_usable_memory_id"></a> [EC2\_usable\_memory\_id](#output\_EC2\_usable\_memory\_id) | id for monitor EC2 Usable Memory |
