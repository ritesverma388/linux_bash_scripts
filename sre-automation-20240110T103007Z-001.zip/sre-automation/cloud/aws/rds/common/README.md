# CLOUD AWS RDS COMMON DataDog monitors

## How to use this module

```hcl
module "datadog-monitors-cloud-aws-rds-common" {
  source      = "../../cloud/aws/rds/common"
  version     = "{revision}"

  environment = var.environment
  message     = module.datadog-message-alerting.alerting-message
}

```

## Purpose

Creates DataDog monitors with the following checks:

- RDS instance CPU high
- RDS instance free space
- RDS replica lag

## Requirements

| Name | Version |
|------|---------|
| terraform | >= 0.12.26 |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| cpu\_enabled | Flag to enable RDS CPU usage monitor | `string` | `"true"` | no |
| cpu\_extra\_tags | Extra tags for RDS CPU usage monitor | `list(string)` | `[]` | no |
| cpu\_message | Custom message for RDS CPU usage monitor | `string` | `""` | no |
| cpu\_threshold\_critical | CPU usage in percent (critical threshold) | `string` | `"90"` | no |
| cpu\_threshold\_warning | CPU usage in percent (warning threshold) | `string` | `"80"` | no |
| cpu\_time\_aggregator | Monitor aggregator for RDS CPU usage [available values: min, max or avg] | `string` | `"min"` | no |
| cpu\_timeframe | Monitor timeframe for RDS CPU usage [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_15m"` | no |
| diskspace\_enabled | Flag to enable RDS free diskspace monitor | `string` | `"true"` | no |
| diskspace\_extra\_tags | Extra tags for RDS free diskspace monitor | `list(string)` | `[]` | no |
| diskspace\_message | Custom message for RDS free diskspace monitor | `string` | `""` | no |
| diskspace\_threshold\_critical | Disk free space in percent (critical threshold) | `string` | `"10"` | no |
| diskspace\_threshold\_warning | Disk free space in percent (warning threshold) | `string` | `"20"` | no |
| diskspace\_time\_aggregator | Monitor aggregator for RDS free diskspace [available values: min, max or avg] | `string` | `"min"` | no |
| diskspace\_timeframe | Monitor timeframe for RDS free diskspace [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_15m"` | no |
| environment | Architecture Environment | `string` | n/a | yes |
| evaluation\_delay | Delay in seconds for the metric evaluation | `number` | `900` | no |
| filter\_tags\_custom | Tags used for custom filtering when filter\_tags\_use\_defaults is false | `string` | `"*"` | no |
| filter\_tags\_custom\_excluded | Tags excluded for custom filtering when filter\_tags\_use\_defaults is false | `string` | `""` | no |
| filter\_tags\_use\_defaults | Use default filter tags convention | `string` | `"true"` | no |
| message | Message sent when an alert is triggered | `any` | n/a | yes |
| new\_host\_delay | Delay in seconds before monitor new resource | `number` | `300` | no |
| notify\_no\_data | Will raise no data alert if set to true | `bool` | `true` | no |
| prefix\_slug | Prefix string to prepend between brackets on every monitors names | `string` | `""` | no |
| rds\_free\_space\_low\_no\_data\_timeframe | Number of minutes before reporting no data | `string` | `30` | no |
| replicalag\_enabled | Flag to enable RDS replica lag monitor | `string` | `"true"` | no |
| replicalag\_extra\_tags | Extra tags for RDS replica lag monitor | `list(string)` | `[]` | no |
| replicalag\_message | Custom message for RDS replica lag monitor | `string` | `""` | no |
| replicalag\_threshold\_critical | replica lag in seconds (critical threshold) | `string` | `"300"` | no |
| replicalag\_threshold\_warning | replica lag in seconds (warning threshold) | `string` | `"200"` | no |
| replicalag\_time\_aggregator | Monitor aggregator for RDS replica lag [available values: min, max or avg] | `string` | `"min"` | no |
| replicalag\_timeframe | Monitor timeframe for RDS replica lag monitor [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_5m"` | no |

## Outputs

| Name | Description |
|------|-------------|
| rds\_cpu\_90\_15min\_id | id for monitor rds\_cpu\_90\_15min |
| rds\_free\_space\_low\_id | id for monitor rds\_free\_space\_low |
| rds\_replica\_lag\_id | id for monitor rds\_replica\_lag |

## Related documentation

DataDog documentation: [https://docs.datadoghq.com/integrations/amazon_rds/](https://docs.datadoghq.com/integrations/amazon_rds/)

AWS RDS Instance metrics documentation: [https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/MonitoringOverview.html#monitoring-cloudwatch](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/MonitoringOverview.html#monitoring-cloudwatch)
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | ~> 0.13.6 |
| <a name="requirement_datadog"></a> [datadog](#requirement\_datadog) | ~> 3.7.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_datadog"></a> [datadog](#provider\_datadog) | ~> 3.7.0 |
| <a name="provider_template"></a> [template](#provider\_template) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_filter-tags"></a> [filter-tags](#module\_filter-tags) | ../../../../common/filter-tags |  |

## Resources

| Name | Type |
|------|------|
| [datadog_dashboard_json.dashboard_rds](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/dashboard_json) | resource |
| [datadog_monitor.rds_burst_balance](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.rds_cpu_90_15min](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.rds_database_connections](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.rds_free_space_low](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.rds_freeable_memory](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.rds_read_iops](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.rds_read_latency](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.rds_write_iops](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.rds_write_latency](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [template_file.rds_dashboard](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |
| [template_file.rds_widgets](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cpu_enabled"></a> [cpu\_enabled](#input\_cpu\_enabled) | Flag to enable RDS CPU usage monitor | `string` | `"true"` | no |
| <a name="input_cpu_extra_tags"></a> [cpu\_extra\_tags](#input\_cpu\_extra\_tags) | Extra tags for RDS CPU usage monitor | `list(string)` | `[]` | no |
| <a name="input_cpu_message"></a> [cpu\_message](#input\_cpu\_message) | Custom message for RDS CPU usage monitor | `string` | `""` | no |
| <a name="input_cpu_notify_no_data"></a> [cpu\_notify\_no\_data](#input\_cpu\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_cpu_threshold_critical"></a> [cpu\_threshold\_critical](#input\_cpu\_threshold\_critical) | CPU usage in percent (critical threshold) | `string` | `"90"` | no |
| <a name="input_cpu_threshold_warning"></a> [cpu\_threshold\_warning](#input\_cpu\_threshold\_warning) | CPU usage in percent (warning threshold) | `string` | `"80"` | no |
| <a name="input_cpu_time_aggregator"></a> [cpu\_time\_aggregator](#input\_cpu\_time\_aggregator) | Monitor aggregator for RDS CPU usage [available values: min, max or avg] | `string` | `"min"` | no |
| <a name="input_cpu_timeframe"></a> [cpu\_timeframe](#input\_cpu\_timeframe) | Monitor timeframe for RDS CPU usage [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_15m"` | no |
| <a name="input_diskspace_enabled"></a> [diskspace\_enabled](#input\_diskspace\_enabled) | Flag to enable RDS free diskspace monitor | `string` | `"true"` | no |
| <a name="input_diskspace_extra_tags"></a> [diskspace\_extra\_tags](#input\_diskspace\_extra\_tags) | Extra tags for RDS free diskspace monitor | `list(string)` | `[]` | no |
| <a name="input_diskspace_message"></a> [diskspace\_message](#input\_diskspace\_message) | Custom message for RDS free diskspace monitor | `string` | `""` | no |
| <a name="input_diskspace_no_data_timeframe"></a> [diskspace\_no\_data\_timeframe](#input\_diskspace\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `30` | no |
| <a name="input_diskspace_notify_no_data"></a> [diskspace\_notify\_no\_data](#input\_diskspace\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_diskspace_threshold_critical"></a> [diskspace\_threshold\_critical](#input\_diskspace\_threshold\_critical) | Disk free space in percent (critical threshold) | `string` | `"10"` | no |
| <a name="input_diskspace_threshold_warning"></a> [diskspace\_threshold\_warning](#input\_diskspace\_threshold\_warning) | Disk free space in percent (warning threshold) | `string` | `"20"` | no |
| <a name="input_diskspace_time_aggregator"></a> [diskspace\_time\_aggregator](#input\_diskspace\_time\_aggregator) | Monitor aggregator for RDS free diskspace [available values: min, max or avg] | `string` | `"min"` | no |
| <a name="input_diskspace_timeframe"></a> [diskspace\_timeframe](#input\_diskspace\_timeframe) | Monitor timeframe for RDS free diskspace [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_15m"` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | Architecture Environment | `string` | n/a | yes |
| <a name="input_evaluation_delay"></a> [evaluation\_delay](#input\_evaluation\_delay) | Delay in seconds for the metric evaluation | `number` | `900` | no |
| <a name="input_filter_tags_custom"></a> [filter\_tags\_custom](#input\_filter\_tags\_custom) | Tags used for custom filtering when filter\_tags\_use\_defaults is false | `string` | `"*"` | no |
| <a name="input_filter_tags_custom_excluded"></a> [filter\_tags\_custom\_excluded](#input\_filter\_tags\_custom\_excluded) | Tags excluded for custom filtering when filter\_tags\_use\_defaults is false | `string` | `""` | no |
| <a name="input_filter_tags_use_defaults"></a> [filter\_tags\_use\_defaults](#input\_filter\_tags\_use\_defaults) | Use default filter tags convention | `string` | `"true"` | no |
| <a name="input_message"></a> [message](#input\_message) | Message sent when an alert is triggered | `any` | n/a | yes |
| <a name="input_new_host_delay"></a> [new\_host\_delay](#input\_new\_host\_delay) | Delay in seconds before monitor new resource | `number` | `300` | no |
| <a name="input_prefix_slug"></a> [prefix\_slug](#input\_prefix\_slug) | Prefix string to prepend between brackets on every monitors names | `string` | `""` | no |
| <a name="input_rds_burst_balance_enabled"></a> [rds\_burst\_balance\_enabled](#input\_rds\_burst\_balance\_enabled) | Flag to enable RDS Instance burst balance monitor | `string` | `"true"` | no |
| <a name="input_rds_burst_balance_extra_tags"></a> [rds\_burst\_balance\_extra\_tags](#input\_rds\_burst\_balance\_extra\_tags) | Extra tags for RDS Instance burst balance monitor | `list(string)` | `[]` | no |
| <a name="input_rds_burst_balance_message"></a> [rds\_burst\_balance\_message](#input\_rds\_burst\_balance\_message) | Custom message for RDS Instance burst balance | `string` | `""` | no |
| <a name="input_rds_burst_balance_no_data_timeframe"></a> [rds\_burst\_balance\_no\_data\_timeframe](#input\_rds\_burst\_balance\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_rds_burst_balance_notify_no_data"></a> [rds\_burst\_balance\_notify\_no\_data](#input\_rds\_burst\_balance\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_rds_burst_balance_threshold_critical"></a> [rds\_burst\_balance\_threshold\_critical](#input\_rds\_burst\_balance\_threshold\_critical) | RDS Instance burst balance critical threshold in percentage | `number` | `25` | no |
| <a name="input_rds_burst_balance_threshold_warning"></a> [rds\_burst\_balance\_threshold\_warning](#input\_rds\_burst\_balance\_threshold\_warning) | RDS Instance burst balance warning threshold in percentage | `number` | `30` | no |
| <a name="input_rds_burst_balance_time_aggregator"></a> [rds\_burst\_balance\_time\_aggregator](#input\_rds\_burst\_balance\_time\_aggregator) | Monitor aggregator for RDS Instance burst balance [available values: min, max or avg] | `string` | `"max"` | no |
| <a name="input_rds_burst_balance_timeframe"></a> [rds\_burst\_balance\_timeframe](#input\_rds\_burst\_balance\_timeframe) | Monitor timeframe for RDS Instance burst balance [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_rds_dashboard_tags"></a> [rds\_dashboard\_tags](#input\_rds\_dashboard\_tags) | Dashboard Tags | `list(string)` | `[]` | no |
| <a name="input_rds_database_connections_enabled"></a> [rds\_database\_connections\_enabled](#input\_rds\_database\_connections\_enabled) | Flag to enable RDS Instance database connections monitor | `string` | `"true"` | no |
| <a name="input_rds_database_connections_extra_tags"></a> [rds\_database\_connections\_extra\_tags](#input\_rds\_database\_connections\_extra\_tags) | Extra tags for RDS Instance database connections monitor | `list(string)` | `[]` | no |
| <a name="input_rds_database_connections_message"></a> [rds\_database\_connections\_message](#input\_rds\_database\_connections\_message) | Custom message for RDS Instance database connections | `string` | `""` | no |
| <a name="input_rds_database_connections_no_data_timeframe"></a> [rds\_database\_connections\_no\_data\_timeframe](#input\_rds\_database\_connections\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_rds_database_connections_notify_no_data"></a> [rds\_database\_connections\_notify\_no\_data](#input\_rds\_database\_connections\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_rds_database_connections_threshold_critical"></a> [rds\_database\_connections\_threshold\_critical](#input\_rds\_database\_connections\_threshold\_critical) | RDS Instance database connections critical threshold in seconds | `number` | `90` | no |
| <a name="input_rds_database_connections_threshold_warning"></a> [rds\_database\_connections\_threshold\_warning](#input\_rds\_database\_connections\_threshold\_warning) | RDS Instance database connections warning threshold in seconds | `number` | `80` | no |
| <a name="input_rds_database_connections_time_aggregator"></a> [rds\_database\_connections\_time\_aggregator](#input\_rds\_database\_connections\_time\_aggregator) | Monitor aggregator for RDS Instance database connections [available values: min, max or avg] | `string` | `"min"` | no |
| <a name="input_rds_database_connections_timeframe"></a> [rds\_database\_connections\_timeframe](#input\_rds\_database\_connections\_timeframe) | Monitor timeframe for RDS Instance database connections [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_rds_freeable_memory_enabled"></a> [rds\_freeable\_memory\_enabled](#input\_rds\_freeable\_memory\_enabled) | Flag to enable RDS Instance freeable memory monitor | `string` | `"true"` | no |
| <a name="input_rds_freeable_memory_extra_tags"></a> [rds\_freeable\_memory\_extra\_tags](#input\_rds\_freeable\_memory\_extra\_tags) | Extra tags for RDS Instance freeable memory monitor | `list(string)` | `[]` | no |
| <a name="input_rds_freeable_memory_message"></a> [rds\_freeable\_memory\_message](#input\_rds\_freeable\_memory\_message) | Custom message for RDS Instance freeable memory | `string` | `""` | no |
| <a name="input_rds_freeable_memory_no_data_timeframe"></a> [rds\_freeable\_memory\_no\_data\_timeframe](#input\_rds\_freeable\_memory\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_rds_freeable_memory_notify_no_data"></a> [rds\_freeable\_memory\_notify\_no\_data](#input\_rds\_freeable\_memory\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_rds_freeable_memory_threshold_critical"></a> [rds\_freeable\_memory\_threshold\_critical](#input\_rds\_freeable\_memory\_threshold\_critical) | RDS Instance freeable memory critical threshold in seconds | `number` | `1000000000` | no |
| <a name="input_rds_freeable_memory_threshold_warning"></a> [rds\_freeable\_memory\_threshold\_warning](#input\_rds\_freeable\_memory\_threshold\_warning) | RDS Instance freeable memory warning threshold in seconds | `number` | `1300000000` | no |
| <a name="input_rds_freeable_memory_time_aggregator"></a> [rds\_freeable\_memory\_time\_aggregator](#input\_rds\_freeable\_memory\_time\_aggregator) | Monitor aggregator for RDS Instance freeable memory [available values: min, max or avg] | `string` | `"max"` | no |
| <a name="input_rds_freeable_memory_timeframe"></a> [rds\_freeable\_memory\_timeframe](#input\_rds\_freeable\_memory\_timeframe) | Monitor timeframe for RDS Instance freeable memory [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_rds_metrics_panel_height"></a> [rds\_metrics\_panel\_height](#input\_rds\_metrics\_panel\_height) | Height of the panel | `number` | `21` | no |
| <a name="input_rds_metrics_panel_width"></a> [rds\_metrics\_panel\_width](#input\_rds\_metrics\_panel\_width) | Width of the panel | `number` | `33` | no |
| <a name="input_rds_monitor_tags"></a> [rds\_monitor\_tags](#input\_rds\_monitor\_tags) | Monitor Tags | `list(string)` | `[]` | no |
| <a name="input_rds_read_iops_enabled"></a> [rds\_read\_iops\_enabled](#input\_rds\_read\_iops\_enabled) | Flag to enable RDS Instance Read iops monitor | `string` | `"true"` | no |
| <a name="input_rds_read_iops_extra_tags"></a> [rds\_read\_iops\_extra\_tags](#input\_rds\_read\_iops\_extra\_tags) | Extra tags for RDS Instance Read iops monitor | `list(string)` | `[]` | no |
| <a name="input_rds_read_iops_message"></a> [rds\_read\_iops\_message](#input\_rds\_read\_iops\_message) | Custom message for RDS Instance Read iops | `string` | `""` | no |
| <a name="input_rds_read_iops_no_data_timeframe"></a> [rds\_read\_iops\_no\_data\_timeframe](#input\_rds\_read\_iops\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_rds_read_iops_notify_no_data"></a> [rds\_read\_iops\_notify\_no\_data](#input\_rds\_read\_iops\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_rds_read_iops_threshold_critical"></a> [rds\_read\_iops\_threshold\_critical](#input\_rds\_read\_iops\_threshold\_critical) | RDS Instance Read iops critical threshold in seconds | `number` | `3000` | no |
| <a name="input_rds_read_iops_threshold_warning"></a> [rds\_read\_iops\_threshold\_warning](#input\_rds\_read\_iops\_threshold\_warning) | RDS Instance Read iops warning threshold in seconds | `number` | `2500` | no |
| <a name="input_rds_read_iops_time_aggregator"></a> [rds\_read\_iops\_time\_aggregator](#input\_rds\_read\_iops\_time\_aggregator) | Monitor aggregator for RDS Instance Read iops [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_rds_read_iops_timeframe"></a> [rds\_read\_iops\_timeframe](#input\_rds\_read\_iops\_timeframe) | Monitor timeframe for RDS Instance Read iops [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_rds_read_latency_enabled"></a> [rds\_read\_latency\_enabled](#input\_rds\_read\_latency\_enabled) | Flag to enable RDS Instance Read Latency monitor | `string` | `"true"` | no |
| <a name="input_rds_read_latency_extra_tags"></a> [rds\_read\_latency\_extra\_tags](#input\_rds\_read\_latency\_extra\_tags) | Extra tags for RDS Instance Read Latency monitor | `list(string)` | `[]` | no |
| <a name="input_rds_read_latency_message"></a> [rds\_read\_latency\_message](#input\_rds\_read\_latency\_message) | Custom message for RDS Instance Read Latency | `string` | `""` | no |
| <a name="input_rds_read_latency_no_data_timeframe"></a> [rds\_read\_latency\_no\_data\_timeframe](#input\_rds\_read\_latency\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_rds_read_latency_notify_no_data"></a> [rds\_read\_latency\_notify\_no\_data](#input\_rds\_read\_latency\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_rds_read_latency_threshold_critical"></a> [rds\_read\_latency\_threshold\_critical](#input\_rds\_read\_latency\_threshold\_critical) | RDS Instance Read Latency critical threshold in seconds | `number` | `1` | no |
| <a name="input_rds_read_latency_threshold_warning"></a> [rds\_read\_latency\_threshold\_warning](#input\_rds\_read\_latency\_threshold\_warning) | RDS Instance Read Latency warning threshold in seconds | `string` | `""` | no |
| <a name="input_rds_read_latency_time_aggregator"></a> [rds\_read\_latency\_time\_aggregator](#input\_rds\_read\_latency\_time\_aggregator) | Monitor aggregator for RDS Instance Read Latency [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_rds_read_latency_timeframe"></a> [rds\_read\_latency\_timeframe](#input\_rds\_read\_latency\_timeframe) | Monitor timeframe for RDS Instance Read Latency [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_rds_resource_panel_height"></a> [rds\_resource\_panel\_height](#input\_rds\_resource\_panel\_height) | Height of the panel | `number` | `7` | no |
| <a name="input_rds_resource_panel_width"></a> [rds\_resource\_panel\_width](#input\_rds\_resource\_panel\_width) | Width Of the Panel | `number` | `33` | no |
| <a name="input_rds_write_iops_enabled"></a> [rds\_write\_iops\_enabled](#input\_rds\_write\_iops\_enabled) | Flag to enable RDS Instance write iops monitor | `string` | `"true"` | no |
| <a name="input_rds_write_iops_extra_tags"></a> [rds\_write\_iops\_extra\_tags](#input\_rds\_write\_iops\_extra\_tags) | Extra tags for RDS Instance write iops monitor | `list(string)` | `[]` | no |
| <a name="input_rds_write_iops_message"></a> [rds\_write\_iops\_message](#input\_rds\_write\_iops\_message) | Custom message for RDS Instance write iops | `string` | `""` | no |
| <a name="input_rds_write_iops_no_data_timeframe"></a> [rds\_write\_iops\_no\_data\_timeframe](#input\_rds\_write\_iops\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_rds_write_iops_notify_no_data"></a> [rds\_write\_iops\_notify\_no\_data](#input\_rds\_write\_iops\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_rds_write_iops_threshold_critical"></a> [rds\_write\_iops\_threshold\_critical](#input\_rds\_write\_iops\_threshold\_critical) | RDS Instance write iops critical threshold in ops/sec | `number` | `3000` | no |
| <a name="input_rds_write_iops_threshold_warning"></a> [rds\_write\_iops\_threshold\_warning](#input\_rds\_write\_iops\_threshold\_warning) | RDS Instance write iops warning threshold in ops/sec | `number` | `2500` | no |
| <a name="input_rds_write_iops_time_aggregator"></a> [rds\_write\_iops\_time\_aggregator](#input\_rds\_write\_iops\_time\_aggregator) | Monitor aggregator for RDS Instance write iops [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_rds_write_iops_timeframe"></a> [rds\_write\_iops\_timeframe](#input\_rds\_write\_iops\_timeframe) | Monitor timeframe for RDS Instance write iops [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_rds_write_latency_enabled"></a> [rds\_write\_latency\_enabled](#input\_rds\_write\_latency\_enabled) | Flag to enable RDS Instance write Latency monitor | `string` | `"true"` | no |
| <a name="input_rds_write_latency_extra_tags"></a> [rds\_write\_latency\_extra\_tags](#input\_rds\_write\_latency\_extra\_tags) | Extra tags for RDS Instance write Latency monitor | `list(string)` | `[]` | no |
| <a name="input_rds_write_latency_message"></a> [rds\_write\_latency\_message](#input\_rds\_write\_latency\_message) | Custom message for RDS Instance write Latency | `string` | `""` | no |
| <a name="input_rds_write_latency_no_data_timeframe"></a> [rds\_write\_latency\_no\_data\_timeframe](#input\_rds\_write\_latency\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_rds_write_latency_notify_no_data"></a> [rds\_write\_latency\_notify\_no\_data](#input\_rds\_write\_latency\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_rds_write_latency_threshold_critical"></a> [rds\_write\_latency\_threshold\_critical](#input\_rds\_write\_latency\_threshold\_critical) | RDS Instance write Latency critical threshold in seconds | `number` | `1` | no |
| <a name="input_rds_write_latency_threshold_warning"></a> [rds\_write\_latency\_threshold\_warning](#input\_rds\_write\_latency\_threshold\_warning) | RDS Instance write Latency warning threshold in seconds | `string` | `""` | no |
| <a name="input_rds_write_latency_time_aggregator"></a> [rds\_write\_latency\_time\_aggregator](#input\_rds\_write\_latency\_time\_aggregator) | Monitor aggregator for RDS Instance write Latency [available values: min, max or avg] | `string` | `"max"` | no |
| <a name="input_rds_write_latency_timeframe"></a> [rds\_write\_latency\_timeframe](#input\_rds\_write\_latency\_timeframe) | Monitor timeframe for RDS Instance write Latency [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_1h"` | no |
| <a name="input_rds_x"></a> [rds\_x](#input\_rds\_x) | Values of X-axis | `list(number)` | <pre>[<br>  14,<br>  49,<br>  84,<br>  119,<br>  154,<br>  189,<br>  224,<br>  259,<br>  294,<br>  329<br>]</pre> | no |
| <a name="input_rds_x_axis_intial_value"></a> [rds\_x\_axis\_intial\_value](#input\_rds\_x\_axis\_intial\_value) | Intial value of X-axis | `number` | `0` | no |
| <a name="input_rds_y"></a> [rds\_y](#input\_rds\_y) | Values of Y-axis | `list(number)` | <pre>[<br>  9,<br>  32,<br>  55,<br>  78,<br>  101,<br>  124,<br>  147,<br>  170,<br>  193,<br>  216<br>]</pre> | no |
| <a name="input_rds_y_axis_intial_value"></a> [rds\_y\_axis\_intial\_value](#input\_rds\_y\_axis\_intial\_value) | Intial value of Y-axis | `number` | `0` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_rds_burst_balance_id"></a> [rds\_burst\_balance\_id](#output\_rds\_burst\_balance\_id) | id for monitor RDS instance burst balance |
| <a name="output_rds_cpu_90_15min_id"></a> [rds\_cpu\_90\_15min\_id](#output\_rds\_cpu\_90\_15min\_id) | id for monitor rds\_cpu\_90\_15min |
| <a name="output_rds_database_connections_id"></a> [rds\_database\_connections\_id](#output\_rds\_database\_connections\_id) | id for monitor RDS instance database connections |
| <a name="output_rds_free_space_low_id"></a> [rds\_free\_space\_low\_id](#output\_rds\_free\_space\_low\_id) | id for monitor rds\_free\_space\_low |
| <a name="output_rds_freeable_memory_id"></a> [rds\_freeable\_memory\_id](#output\_rds\_freeable\_memory\_id) | id for monitor RDS instance freeable memory |
| <a name="output_rds_read_iops_id"></a> [rds\_read\_iops\_id](#output\_rds\_read\_iops\_id) | id for monitor RDS instance read I/O operations |
| <a name="output_rds_read_latency_id"></a> [rds\_read\_latency\_id](#output\_rds\_read\_latency\_id) | id for monitor RDS instance read latency |
| <a name="output_rds_write_iops_id"></a> [rds\_write\_iops\_id](#output\_rds\_write\_iops\_id) | id for monitor RDS instance write I/O operations |
| <a name="output_rds_write_latency_id"></a> [rds\_write\_latency\_id](#output\_rds\_write\_latency\_id) | id for monitor RDS instance write latency |
