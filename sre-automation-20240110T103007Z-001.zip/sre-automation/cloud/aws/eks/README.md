## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | ~> 0.13.6 |
| <a name="requirement_datadog"></a> [datadog](#requirement\_datadog) | ~> 3.7.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_datadog"></a> [datadog](#provider\_datadog) | ~> 3.7.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_filter-tags"></a> [filter-tags](#module\_filter-tags) | ../../../common/filter-tags |  |
| <a name="module_filter-tags-with-az"></a> [filter-tags-with-az](#module\_filter-tags-with-az) | ../../../common/filter-tags |  |

## Resources

| Name | Type |
|------|------|
| [datadog_monitor.EKS_cpu_request](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.EKS_cpu_usage](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.EKS_filesystem_usage](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.EKS_kubelet_logs](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.EKS_memory_request](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |
| [datadog_monitor.EKS_memory_usage](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/resources/monitor) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_eks_cpu_request_aggregator"></a> [eks\_cpu\_request\_aggregator](#input\_eks\_cpu\_request\_aggregator) | Monitor aggregator for EKS CPU Request [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_eks_cpu_request_enabled"></a> [eks\_cpu\_request\_enabled](#input\_eks\_cpu\_request\_enabled) | Flag to enable EKS CPU Request monitor | `string` | `"true"` | no |
| <a name="input_eks_cpu_request_extra_tags"></a> [eks\_cpu\_request\_extra\_tags](#input\_eks\_cpu\_request\_extra\_tags) | Extra tags for EKS CPU Request monitor | `list(string)` | `[]` | no |
| <a name="input_eks_cpu_request_message"></a> [eks\_cpu\_request\_message](#input\_eks\_cpu\_request\_message) | Custom message for EKS CPU Request | `string` | `""` | no |
| <a name="input_eks_cpu_request_no_data_timeframe"></a> [eks\_cpu\_request\_no\_data\_timeframe](#input\_eks\_cpu\_request\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_eks_cpu_request_notify_no_data"></a> [eks\_cpu\_request\_notify\_no\_data](#input\_eks\_cpu\_request\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_eks_cpu_request_threshold_critical"></a> [eks\_cpu\_request\_threshold\_critical](#input\_eks\_cpu\_request\_threshold\_critical) | EKS CPU Request critical threshold | `number` | `500000000` | no |
| <a name="input_eks_cpu_request_threshold_warning"></a> [eks\_cpu\_request\_threshold\_warning](#input\_eks\_cpu\_request\_threshold\_warning) | EKS CPU Request warning threshold | `number` | `475000000` | no |
| <a name="input_eks_cpu_request_timeframe"></a> [eks\_cpu\_request\_timeframe](#input\_eks\_cpu\_request\_timeframe) | Monitor timeframe for EKS CPU Request [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_15m"` | no |
| <a name="input_eks_cpu_usage_aggregator"></a> [eks\_cpu\_usage\_aggregator](#input\_eks\_cpu\_usage\_aggregator) | Monitor aggregator for EKS CPU Usage [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_eks_cpu_usage_enabled"></a> [eks\_cpu\_usage\_enabled](#input\_eks\_cpu\_usage\_enabled) | Flag to enable EKS CPU Usage monitor | `string` | `"true"` | no |
| <a name="input_eks_cpu_usage_extra_tags"></a> [eks\_cpu\_usage\_extra\_tags](#input\_eks\_cpu\_usage\_extra\_tags) | Extra tags for EKS CPU Usage monitor | `list(string)` | `[]` | no |
| <a name="input_eks_cpu_usage_message"></a> [eks\_cpu\_usage\_message](#input\_eks\_cpu\_usage\_message) | Custom message for EKS CPU Usage | `string` | `""` | no |
| <a name="input_eks_cpu_usage_no_data_timeframe"></a> [eks\_cpu\_usage\_no\_data\_timeframe](#input\_eks\_cpu\_usage\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_eks_cpu_usage_notify_no_data"></a> [eks\_cpu\_usage\_notify\_no\_data](#input\_eks\_cpu\_usage\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_eks_cpu_usage_threshold_critical"></a> [eks\_cpu\_usage\_threshold\_critical](#input\_eks\_cpu\_usage\_threshold\_critical) | EKS CPU Usage critical threshold | `number` | `50000000` | no |
| <a name="input_eks_cpu_usage_threshold_warning"></a> [eks\_cpu\_usage\_threshold\_warning](#input\_eks\_cpu\_usage\_threshold\_warning) | EKS CPU Usage warning threshold | `number` | `47500000` | no |
| <a name="input_eks_cpu_usage_timeframe"></a> [eks\_cpu\_usage\_timeframe](#input\_eks\_cpu\_usage\_timeframe) | Monitor timeframe for EKS CPU Usage [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_15m"` | no |
| <a name="input_eks_filesystem_usage_aggregator"></a> [eks\_filesystem\_usage\_aggregator](#input\_eks\_filesystem\_usage\_aggregator) | Monitor aggregator for EKS filesystem Usage [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_eks_filesystem_usage_enabled"></a> [eks\_filesystem\_usage\_enabled](#input\_eks\_filesystem\_usage\_enabled) | Flag to enable EKS filesystem Usage monitor | `string` | `"true"` | no |
| <a name="input_eks_filesystem_usage_extra_tags"></a> [eks\_filesystem\_usage\_extra\_tags](#input\_eks\_filesystem\_usage\_extra\_tags) | Extra tags for EKS filesystem Usage monitor | `list(string)` | `[]` | no |
| <a name="input_eks_filesystem_usage_message"></a> [eks\_filesystem\_usage\_message](#input\_eks\_filesystem\_usage\_message) | Custom message for EKS filesystem Usage | `string` | `""` | no |
| <a name="input_eks_filesystem_usage_no_data_timeframe"></a> [eks\_filesystem\_usage\_no\_data\_timeframe](#input\_eks\_filesystem\_usage\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_eks_filesystem_usage_notify_no_data"></a> [eks\_filesystem\_usage\_notify\_no\_data](#input\_eks\_filesystem\_usage\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_eks_filesystem_usage_threshold_critical"></a> [eks\_filesystem\_usage\_threshold\_critical](#input\_eks\_filesystem\_usage\_threshold\_critical) | EKS filesystem Usage critical threshold | `number` | `85` | no |
| <a name="input_eks_filesystem_usage_threshold_warning"></a> [eks\_filesystem\_usage\_threshold\_warning](#input\_eks\_filesystem\_usage\_threshold\_warning) | EKS filesystem Usage warning threshold | `number` | `75` | no |
| <a name="input_eks_filesystem_usage_timeframe"></a> [eks\_filesystem\_usage\_timeframe](#input\_eks\_filesystem\_usage\_timeframe) | Monitor timeframe for EKS filesystem Usage [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_15m"` | no |
| <a name="input_eks_kubelet_logs_aggregator"></a> [eks\_kubelet\_logs\_aggregator](#input\_eks\_kubelet\_logs\_aggregator) | Monitor aggregator for EKS Kubelet Container Logs [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_eks_kubelet_logs_enabled"></a> [eks\_kubelet\_logs\_enabled](#input\_eks\_kubelet\_logs\_enabled) | Flag to enable EKS Kubelet Container Logs monitor | `string` | `"true"` | no |
| <a name="input_eks_kubelet_logs_extra_tags"></a> [eks\_kubelet\_logs\_extra\_tags](#input\_eks\_kubelet\_logs\_extra\_tags) | Extra tags for EKS Kubelet Container Logs monitor | `list(string)` | `[]` | no |
| <a name="input_eks_kubelet_logs_message"></a> [eks\_kubelet\_logs\_message](#input\_eks\_kubelet\_logs\_message) | Custom message for EKS Kubelet Container Logs | `string` | `""` | no |
| <a name="input_eks_kubelet_logs_no_data_timeframe"></a> [eks\_kubelet\_logs\_no\_data\_timeframe](#input\_eks\_kubelet\_logs\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_eks_kubelet_logs_notify_no_data"></a> [eks\_kubelet\_logs\_notify\_no\_data](#input\_eks\_kubelet\_logs\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_eks_kubelet_logs_threshold_critical"></a> [eks\_kubelet\_logs\_threshold\_critical](#input\_eks\_kubelet\_logs\_threshold\_critical) | EKS Kubelet Container Logs critical threshold | `number` | `7000000000` | no |
| <a name="input_eks_kubelet_logs_threshold_warning"></a> [eks\_kubelet\_logs\_threshold\_warning](#input\_eks\_kubelet\_logs\_threshold\_warning) | EKS Kubelet Container Logs warning threshold | `number` | `5000000000` | no |
| <a name="input_eks_kubelet_logs_timeframe"></a> [eks\_kubelet\_logs\_timeframe](#input\_eks\_kubelet\_logs\_timeframe) | Monitor timeframe for EKS Kubelet Container Logs [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_15m"` | no |
| <a name="input_eks_memory_request_aggregator"></a> [eks\_memory\_request\_aggregator](#input\_eks\_memory\_request\_aggregator) | Monitor aggregator for EKS memory Request [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_eks_memory_request_enabled"></a> [eks\_memory\_request\_enabled](#input\_eks\_memory\_request\_enabled) | Flag to enable EKS memory Request monitor | `string` | `"true"` | no |
| <a name="input_eks_memory_request_extra_tags"></a> [eks\_memory\_request\_extra\_tags](#input\_eks\_memory\_request\_extra\_tags) | Extra tags for EKS memory Request monitor | `list(string)` | `[]` | no |
| <a name="input_eks_memory_request_message"></a> [eks\_memory\_request\_message](#input\_eks\_memory\_request\_message) | Custom message for EKS memory Request | `string` | `""` | no |
| <a name="input_eks_memory_request_no_data_timeframe"></a> [eks\_memory\_request\_no\_data\_timeframe](#input\_eks\_memory\_request\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_eks_memory_request_notify_no_data"></a> [eks\_memory\_request\_notify\_no\_data](#input\_eks\_memory\_request\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_eks_memory_request_threshold_critical"></a> [eks\_memory\_request\_threshold\_critical](#input\_eks\_memory\_request\_threshold\_critical) | EKS memory Request critical threshold | `number` | `6000000000` | no |
| <a name="input_eks_memory_request_threshold_warning"></a> [eks\_memory\_request\_threshold\_warning](#input\_eks\_memory\_request\_threshold\_warning) | EKS memory Request warning threshold | `number` | `5000000000` | no |
| <a name="input_eks_memory_request_timeframe"></a> [eks\_memory\_request\_timeframe](#input\_eks\_memory\_request\_timeframe) | Monitor timeframe for EKS memory Request [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_15m"` | no |
| <a name="input_eks_memory_usage_aggregator"></a> [eks\_memory\_usage\_aggregator](#input\_eks\_memory\_usage\_aggregator) | Monitor aggregator for EKS memory Usage [available values: min, max or avg] | `string` | `"avg"` | no |
| <a name="input_eks_memory_usage_enabled"></a> [eks\_memory\_usage\_enabled](#input\_eks\_memory\_usage\_enabled) | Flag to enable EKS memory Usage monitor | `string` | `"true"` | no |
| <a name="input_eks_memory_usage_extra_tags"></a> [eks\_memory\_usage\_extra\_tags](#input\_eks\_memory\_usage\_extra\_tags) | Extra tags for EKS memory Usage monitor | `list(string)` | `[]` | no |
| <a name="input_eks_memory_usage_message"></a> [eks\_memory\_usage\_message](#input\_eks\_memory\_usage\_message) | Custom message for EKS memory Usage | `string` | `""` | no |
| <a name="input_eks_memory_usage_no_data_timeframe"></a> [eks\_memory\_usage\_no\_data\_timeframe](#input\_eks\_memory\_usage\_no\_data\_timeframe) | Number of minutes before reporting no data | `string` | `10` | no |
| <a name="input_eks_memory_usage_notify_no_data"></a> [eks\_memory\_usage\_notify\_no\_data](#input\_eks\_memory\_usage\_notify\_no\_data) | Will raise no data alert if set to true | `bool` | `false` | no |
| <a name="input_eks_memory_usage_threshold_critical"></a> [eks\_memory\_usage\_threshold\_critical](#input\_eks\_memory\_usage\_threshold\_critical) | EKS memory Usage critical threshold | `number` | `90` | no |
| <a name="input_eks_memory_usage_threshold_warning"></a> [eks\_memory\_usage\_threshold\_warning](#input\_eks\_memory\_usage\_threshold\_warning) | EKS memory Usage warning threshold | `number` | `80` | no |
| <a name="input_eks_memory_usage_timeframe"></a> [eks\_memory\_usage\_timeframe](#input\_eks\_memory\_usage\_timeframe) | Monitor timeframe for EKS memory Usage [available values: `last_#m` (1, 5, 10, 15, or 30), `last_#h` (1, 2, or 4), or `last_1d`] | `string` | `"last_15m"` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | Architecture environment | `string` | n/a | yes |
| <a name="input_evaluation_delay"></a> [evaluation\_delay](#input\_evaluation\_delay) | Delay in seconds for the metric evaluation | `number` | `900` | no |
| <a name="input_filter_tags_custom"></a> [filter\_tags\_custom](#input\_filter\_tags\_custom) | Tags used for custom filtering when filter\_tags\_use\_defaults is false | `string` | `"*"` | no |
| <a name="input_filter_tags_custom_excluded"></a> [filter\_tags\_custom\_excluded](#input\_filter\_tags\_custom\_excluded) | Tags excluded for custom filtering when filter\_tags\_use\_defaults is false | `string` | `""` | no |
| <a name="input_filter_tags_use_defaults"></a> [filter\_tags\_use\_defaults](#input\_filter\_tags\_use\_defaults) | Use default filter tags convention | `string` | `"true"` | no |
| <a name="input_message"></a> [message](#input\_message) | Message sent when a monitor is triggered | `any` | n/a | yes |
| <a name="input_new_host_delay"></a> [new\_host\_delay](#input\_new\_host\_delay) | Delay in seconds before monitor new resource | `number` | `300` | no |
| <a name="input_prefix_slug"></a> [prefix\_slug](#input\_prefix\_slug) | Prefix string to prepend between brackets on every monitors names | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_EKS_cpu_request_id"></a> [EKS\_cpu\_request\_id](#output\_EKS\_cpu\_request\_id) | id for monitor EKS CPU Request |
| <a name="output_EKS_cpu_usage_id"></a> [EKS\_cpu\_usage\_id](#output\_EKS\_cpu\_usage\_id) | id for monitor EKS CPU Usage |
| <a name="output_EKS_filesystem_usage_id"></a> [EKS\_filesystem\_usage\_id](#output\_EKS\_filesystem\_usage\_id) | id for monitor EKS File System Usage |
| <a name="output_EKS_kubelet_logs_id"></a> [EKS\_kubelet\_logs\_id](#output\_EKS\_kubelet\_logs\_id) | id for monitor EKS Kubelet Logs |
| <a name="output_EKS_memory_request_id"></a> [EKS\_memory\_request\_id](#output\_EKS\_memory\_request\_id) | id for monitor EKS Memory Status |
| <a name="output_EKS_memory_usage_id"></a> [EKS\_memory\_usage\_id](#output\_EKS\_memory\_usage\_id) | id for monitor EKS Memory Usage |
